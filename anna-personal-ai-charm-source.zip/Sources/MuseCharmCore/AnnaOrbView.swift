import SwiftUI

/// Shared pixel-orb character used by the phone and watch. The app icon remains orb-only.
public struct AnnaOrbView: View {
    public let expression: CharmExpression
    public let showsFace: Bool
    public let animationEnabled: Bool

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var floating = false

    public init(
        expression: CharmExpression = .calm,
        showsFace: Bool = true,
        animationEnabled: Bool = true
    ) {
        self.expression = expression
        self.showsFace = showsFace
        self.animationEnabled = animationEnabled
    }

    public var body: some View {
        Image(artworkName)
            .resizable()
            .interpolation(.none)
            .scaledToFit()
            .offset(y: motionAllowed ? (floating ? -2.5 : 2.5) : 0)
            .animation(.easeInOut(duration: expression == .sleepy ? 3.4 : 1.8).repeatForever(autoreverses: true), value: floating)
            .onAppear { floating = motionAllowed }
            .accessibilityLabel(accessibilityDescription)
            .accessibilityAddTraits(.isImage)
    }

    private var artworkName: String {
        guard showsFace else { return "AnnaOrb" }

        switch expression {
        case .sleepy, .tiredProud:
            return "AnnaOrbSleepy"
        case .bashful:
            return "AnnaOrbLoving"
        case .excited:
            return "AnnaOrbExcited"
        default:
            return "AnnaOrbHappy"
        }
    }

    private var motionAllowed: Bool {
        animationEnabled && !reduceMotion
    }

    private var accessibilityDescription: String {
        let mood: String
        switch expression {
        case .calm: mood = "calm"
        case .curious: mood = "curious"
        case .sleepy: mood = "sleeping"
        case .happy, .bashful: mood = "happy"
        case .concerned: mood = "concerned"
        case .listening: mood = "listening"
        case .thinking: mood = "thinking"
        case .excited: mood = "excited"
        case .proud: mood = "proud"
        case .tiredProud: mood = "resting after an effort"
        case .focused: mood = "focused"
        case .confused: mood = "unsure"
        }
        return showsFace ? "Anna, pink pixel orb, \(mood)" : "Anna, resting pink pixel orb"
    }
}
