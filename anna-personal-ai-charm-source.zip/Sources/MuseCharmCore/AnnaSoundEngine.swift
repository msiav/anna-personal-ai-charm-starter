import AVFoundation
import Foundation

public enum AnnaSoundCue: Sendable {
    case boot
    case tap
    case listening
    case sent
    case reply
    case sleep
    case wake
    case error
    case wind(Double)
}

@MainActor
public final class AnnaSoundEngine {
    private struct Tone {
        let frequency: Double
        let start: Double
        let duration: Double
        let gain: Double
    }

    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private let sampleRate = 44_100.0
    private let format: AVAudioFormat?
    private var lastWindCue = Date.distantPast

    public init() {
        format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)
        engine.attach(player)
        if let format {
            engine.connect(player, to: engine.mainMixerNode, format: format)
        }
    }

    public func play(
        _ cue: AnnaSoundCue,
        enabled: Bool = true,
        quietMode: Bool = false,
        intensity: Double = 0.5
    ) {
        guard enabled, !quietMode else { return }
        if case .wind = cue {
            guard Date().timeIntervalSince(lastWindCue) >= 0.12 else { return }
            lastWindCue = Date()
        }

        #if os(iOS) || os(watchOS)
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.ambient, mode: .default, options: [])
            try session.setActive(true)
        } catch {
            return
        }
        #endif

        guard let buffer = makeBuffer(for: cue, intensity: intensity) else { return }
        do {
            if !engine.isRunning { try engine.start() }
        } catch {
            return
        }
        player.stop()
        player.scheduleBuffer(buffer)
        player.play()
    }

    private func makeBuffer(for cue: AnnaSoundCue, intensity: Double) -> AVAudioPCMBuffer? {
        let tones = pattern(for: cue, intensity: intensity)
        guard let endTime = tones.map({ $0.start + $0.duration }).max(), endTime > 0 else { return nil }
        guard let format else { return nil }
        let frameCount = AVAudioFrameCount(endTime * sampleRate)
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount),
              let samples = buffer.floatChannelData?.pointee else { return nil }
        buffer.frameLength = frameCount
        let level = min(max(intensity, 0.05), 1)

        for frame in 0..<Int(frameCount) {
            let time = Double(frame) / sampleRate
            var sample = 0.0
            for tone in tones where time >= tone.start && time < tone.start + tone.duration {
                let localTime = time - tone.start
                let phase = 2 * Double.pi * tone.frequency * localTime
                let sine = sin(phase)
                let triangle = asin(sine) * (2 / Double.pi)
                let attack = min(1, localTime / 0.018)
                let release = min(1, (tone.duration - localTime) / 0.045)
                let envelope = attack * max(0, release) * exp(-2.6 * localTime / tone.duration)
                sample += (sine * 0.72 + triangle * 0.28) * envelope * tone.gain * level
            }
            samples[frame] = Float(max(-0.72, min(0.72, sample)))
        }
        return buffer
    }

    private func pattern(for cue: AnnaSoundCue, intensity: Double) -> [Tone] {
        switch cue {
        case .boot:
            return [Tone(frequency: 523, start: 0, duration: 0.22, gain: 0.28),
                    Tone(frequency: 659, start: 0.16, duration: 0.24, gain: 0.26),
                    Tone(frequency: 784, start: 0.33, duration: 0.42, gain: 0.24)]
        case .tap:
            return [Tone(frequency: 740, start: 0, duration: 0.10, gain: 0.16)]
        case .listening:
            return [Tone(frequency: 420, start: 0, duration: 0.12, gain: 0.12),
                    Tone(frequency: 560, start: 0.08, duration: 0.20, gain: 0.10)]
        case .sent:
            return [Tone(frequency: 330, start: 0, duration: 0.12, gain: 0.20)]
        case .reply:
            return [Tone(frequency: 660, start: 0, duration: 0.16, gain: 0.20),
                    Tone(frequency: 880, start: 0.12, duration: 0.24, gain: 0.17)]
        case .sleep:
            return [Tone(frequency: 523, start: 0, duration: 0.18, gain: 0.18),
                    Tone(frequency: 392, start: 0.12, duration: 0.30, gain: 0.15)]
        case .wake:
            return [Tone(frequency: 392, start: 0, duration: 0.15, gain: 0.16),
                    Tone(frequency: 587, start: 0.12, duration: 0.18, gain: 0.18),
                    Tone(frequency: 784, start: 0.25, duration: 0.24, gain: 0.20)]
        case .error:
            return [Tone(frequency: 246, start: 0, duration: 0.20, gain: 0.16)]
        case let .wind(amount):
            let pitch = 420 + min(abs(amount), 8) * 58
            return [Tone(frequency: pitch, start: 0, duration: 0.11, gain: 0.10)]
        }
    }
}
