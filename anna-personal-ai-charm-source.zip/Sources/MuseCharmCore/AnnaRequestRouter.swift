import Foundation

public enum AnnaRequestIntent: Equatable, Sendable {
    case instantAnswer(String)
    case startTimer(seconds: Int)
    case timerClarification
    case liveSearch(String)
    case signInBoundary
    case capabilities
    case healthQuestion
    case conversation
}

/// Small deterministic routing for requests Anna can answer or act on without
/// asking a language model to guess what the user meant.
public enum AnnaRequestRouter {
    public static func route(_ text: String) -> AnnaRequestIntent {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let value = trimmed.lowercased()

        if let query = searchQuery(in: trimmed, normalized: value) {
            return .liveSearch(query)
        }
        if isSignInRequest(value) {
            return .signInBoundary
        }
        if isCapabilitiesQuestion(value) {
            return .capabilities
        }
        if let timerIntent = timerRequest(in: value) {
            return timerIntent
        }
        if isHealthQuestion(value) {
            return .healthQuestion
        }
        if let answer = AnnaLocalAnswerRouter.answer(for: trimmed) {
            return .instantAnswer(answer)
        }
        return .conversation
    }

    private static func searchQuery(in text: String, normalized value: String) -> String? {
        let prefixes = [
            "search the web for ", "can you search the web for ",
            "can you search the internet for ", "can you search for ",
            "search the internet for ", "search web for ", "search online for ",
            "look up on the web ", "look up online ", "look up ",
            "find me ", "search for "
        ]
        if let prefix = prefixes.first(where: { value.hasPrefix($0) }) {
            let query = String(text.dropFirst(prefix.count)).trimmingCharacters(in: .whitespacesAndNewlines)
            return query.isEmpty ? nil : String(query.prefix(500))
        }

        let currentInformationPhrases = [
            "what's happening", "whats happening", "what is happening",
            "who won last night", "who won today", "latest news", "current news", "news today",
            "is it going to rain", "will it rain", "what's the weather", "whats the weather",
            "weather in ", "weather today", "weather tomorrow", "weather right now", "forecast for", "forecast in ",
            "latest update", "what happened today", "what's the latest", "whats the latest",
            "events near me", "what's on in ", "whats on in ",
            "nba games", "nba score", "nba schedule", "nhl games", "nhl score", "nfl games", "nfl score",
            "mlb games", "mlb score", "wnba games", "sports scores", "games today", "games tonight",
            "scores today", "scores tonight", "schedule today", "schedule tonight", "final score"
        ]
        let datedEventsRequest = value.contains("events in ")
            && ["today", "tonight", "tomorrow", "this week", "this weekend"].contains(where: value.contains)
        guard currentInformationPhrases.contains(where: value.contains) || datedEventsRequest else { return nil }
        return String(text.prefix(500))
    }

    private static func isSignInRequest(_ value: String) -> Bool {
        value.contains("log in") || value.contains("login") || value.contains("sign in") || value.contains("sign into")
            || ((value.contains("vm") || value.contains("linux")) && value.contains("open"))
    }

    private static func isCapabilitiesQuestion(_ value: String) -> Bool {
        let exactPhrases = [
            "what can you do", "what can anna do", "what are you able to do", "what are your capabilities",
            "your capabilities", "can you search the web", "can you search the internet", "can you browse",
            "can you open apps", "can you open things", "search the web", "search the internet"
        ]
        if exactPhrases.contains(where: value.contains) { return true }
        let questionLead = ["can you ", "could you ", "are you able to ", "do you ", "does anna "]
            .contains(where: value.hasPrefix)
        let featureTerms = ["search", "browse", "web", "internet", "open", "apps", "vm", "linux"]
        return questionLead && featureTerms.contains(where: value.contains)
    }

    private static func isHealthQuestion(_ value: String) -> Bool {
        let topics = ["health", "steps", "sleep", "workout", "workouts", "activity", "walk", "walking"]
        guard topics.contains(where: value.contains) else { return false }
        let questionSignals = [
            "how many", "how much", "what was", "what's my", "whats my", "what is my", "show me",
            "tell me", "summary", "progress", "average", "did i", "have i", "last night", "today",
            "this week", "how did i", "my steps", "my sleep", "my workouts", "my activity"
        ]
        return value.contains("?") || questionSignals.contains(where: value.contains)
    }

    private static func timerRequest(in value: String) -> AnnaRequestIntent? {
        var request = value
        let politePrefixes = ["anna, ", "anna ", "please ", "can you ", "could you ", "would you "]
        while let prefix = politePrefixes.first(where: { request.hasPrefix($0) }) {
            request = String(request.dropFirst(prefix.count))
        }
        let startsTimer = ["set a timer", "set timer", "start a timer", "start timer", "timer for", "countdown for"]
            .contains(where: request.hasPrefix)
        guard startsTimer else { return nil }
        let pattern = #"(?:set|start)?\s*(?:an?\s+)?(?:anna\s+)?timer(?:\s+for)?\s+(\d{1,4})\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\b"#
        guard let match = firstMatch(pattern, in: request),
              let amount = Int(match[1]) else { return .timerClarification }
        let unit = match[2]
        let multiplier = unit.hasPrefix("hour") || unit.hasPrefix("hr") ? 3_600
            : (unit.hasPrefix("min") ? 60 : 1)
        let seconds = amount.multipliedReportingOverflow(by: multiplier)
        guard !seconds.overflow, (1...86_400).contains(seconds.partialValue) else { return .timerClarification }
        return .startTimer(seconds: seconds.partialValue)
    }

    private static func firstMatch(_ pattern: String, in value: String) -> [String]? {
        guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = expression.firstMatch(in: value, range: NSRange(value.startIndex..., in: value)) else { return nil }
        return (0..<match.numberOfRanges).map { index in
            guard let range = Range(match.range(at: index), in: value) else { return "" }
            return String(value[range])
        }
    }
}

/// Answers unambiguous requests locally so simple tools do not wait for model inference.
public enum AnnaLocalAnswerRouter {
    private struct Unit {
        let canonicalName: String
        let family: String
        let scaleToBase: Double
    }

    private static let units: [String: Unit] = [
        "m": Unit(canonicalName: "meters", family: "length", scaleToBase: 1),
        "meter": Unit(canonicalName: "meters", family: "length", scaleToBase: 1),
        "meters": Unit(canonicalName: "meters", family: "length", scaleToBase: 1),
        "km": Unit(canonicalName: "kilometers", family: "length", scaleToBase: 1_000),
        "kilometer": Unit(canonicalName: "kilometers", family: "length", scaleToBase: 1_000),
        "kilometers": Unit(canonicalName: "kilometers", family: "length", scaleToBase: 1_000),
        "mi": Unit(canonicalName: "miles", family: "length", scaleToBase: 1_609.344),
        "mile": Unit(canonicalName: "miles", family: "length", scaleToBase: 1_609.344),
        "miles": Unit(canonicalName: "miles", family: "length", scaleToBase: 1_609.344),
        "ft": Unit(canonicalName: "feet", family: "length", scaleToBase: 0.3048),
        "foot": Unit(canonicalName: "feet", family: "length", scaleToBase: 0.3048),
        "feet": Unit(canonicalName: "feet", family: "length", scaleToBase: 0.3048),
        "cm": Unit(canonicalName: "centimeters", family: "length", scaleToBase: 0.01),
        "centimeter": Unit(canonicalName: "centimeters", family: "length", scaleToBase: 0.01),
        "centimeters": Unit(canonicalName: "centimeters", family: "length", scaleToBase: 0.01),
        "in": Unit(canonicalName: "inches", family: "length", scaleToBase: 0.0254),
        "inch": Unit(canonicalName: "inches", family: "length", scaleToBase: 0.0254),
        "inches": Unit(canonicalName: "inches", family: "length", scaleToBase: 0.0254),
        "g": Unit(canonicalName: "grams", family: "mass", scaleToBase: 1),
        "gram": Unit(canonicalName: "grams", family: "mass", scaleToBase: 1),
        "grams": Unit(canonicalName: "grams", family: "mass", scaleToBase: 1),
        "kg": Unit(canonicalName: "kilograms", family: "mass", scaleToBase: 1_000),
        "kilogram": Unit(canonicalName: "kilograms", family: "mass", scaleToBase: 1_000),
        "kilograms": Unit(canonicalName: "kilograms", family: "mass", scaleToBase: 1_000),
        "lb": Unit(canonicalName: "pounds", family: "mass", scaleToBase: 453.59237),
        "lbs": Unit(canonicalName: "pounds", family: "mass", scaleToBase: 453.59237),
        "pound": Unit(canonicalName: "pounds", family: "mass", scaleToBase: 453.59237),
        "pounds": Unit(canonicalName: "pounds", family: "mass", scaleToBase: 453.59237),
        "oz": Unit(canonicalName: "ounces", family: "mass", scaleToBase: 28.349523125),
        "ounce": Unit(canonicalName: "ounces", family: "mass", scaleToBase: 28.349523125),
        "ounces": Unit(canonicalName: "ounces", family: "mass", scaleToBase: 28.349523125)
    ]

    public static func answer(for text: String, now: Date = Date()) -> String? {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !value.isEmpty else { return nil }

        if ["what time is it", "what's the time", "whats the time", "current time", "tell me the time"]
            .contains(where: { value == $0 || value == $0 + "?" }) {
            return "It’s \(now.formatted(date: .omitted, time: .shortened))."
        }
        if ["what's today's date", "whats today's date", "what is today's date", "what day is it", "what's the date"]
            .contains(where: { value == $0 || value == $0 + "?" }) {
            return "Today is \(now.formatted(date: .complete, time: .omitted))."
        }
        if value.contains("flip a coin") || value.contains("toss a coin") {
            return Bool.random() ? "It’s heads." : "It’s tails."
        }
        if let answer = diceAnswer(in: value) { return answer }
        if let answer = choiceAnswer(in: value) { return answer }
        if let answer = conversionAnswer(in: value) { return answer }
        return arithmeticAnswer(in: value)
    }

    private static func arithmeticAnswer(in value: String) -> String? {
        var expression = value
        for prefix in ["what is ", "what's ", "whats ", "calculate ", "compute ", "solve "] where expression.hasPrefix(prefix) {
            expression = String(expression.dropFirst(prefix.count))
            break
        }
        expression = expression.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines.union(CharacterSet(charactersIn: "?")))
        let pattern = #"^(-?\d+(?:\.\d+)?)\s*([+\-×x*/÷%])\s*(-?\d+(?:\.\d+)?)$"#
        guard let match = firstMatch(pattern, in: expression),
              let lhs = Double(match[1]), let rhs = Double(match[3]) else { return nil }
        let operation = match[2]
        let result: Double
        switch operation {
        case "+": result = lhs + rhs
        case "-": result = lhs - rhs
        case "×", "x", "*": result = lhs * rhs
        case "/", "÷":
            guard rhs != 0 else { return "Division by zero isn’t defined." }
            result = lhs / rhs
        case "%":
            guard rhs != 0 else { return "A remainder by zero isn’t defined." }
            result = lhs.truncatingRemainder(dividingBy: rhs)
        default: return nil
        }
        guard result.isFinite else { return nil }
        return "\(format(lhs)) \(operation) \(format(rhs)) is \(format(result))."
    }

    private static func conversionAnswer(in value: String) -> String? {
        let pattern = #"^(?:convert\s+)?(-?\d+(?:\.\d+)?)\s*([a-z]+)\s+(?:to|in)\s+([a-z]+)\??$"#
        guard let match = firstMatch(pattern, in: value),
              let amount = Double(match[1]) else { return nil }
        let sourceName = match[2]
        let targetName = match[3]

        if isTemperature(sourceName), isTemperature(targetName) {
            let celsius: Double
            switch sourceName {
            case "c", "°c", "celsius": celsius = amount
            case "f", "°f", "fahrenheit": celsius = (amount - 32) * 5 / 9
            case "k", "kelvin": celsius = amount - 273.15
            default: return nil
            }
            let result: Double
            let targetLabel: String
            switch targetName {
            case "c", "°c", "celsius": result = celsius; targetLabel = "°C"
            case "f", "°f", "fahrenheit": result = celsius * 9 / 5 + 32; targetLabel = "°F"
            case "k", "kelvin": result = celsius + 273.15; targetLabel = "K"
            default: return nil
            }
            return "\(format(amount))° \(sourceName.capitalized) is \(format(result)) \(targetLabel)."
        }

        guard let source = units[sourceName], let target = units[targetName], source.family == target.family else { return nil }
        let converted = amount * source.scaleToBase / target.scaleToBase
        return "\(format(amount)) \(source.canonicalName) is \(format(converted)) \(target.canonicalName)."
    }

    private static func isTemperature(_ unit: String) -> Bool {
        ["c", "°c", "celsius", "f", "°f", "fahrenheit", "k", "kelvin"].contains(unit)
    }

    private static func diceAnswer(in value: String) -> String? {
        let pattern = #"(?:roll|throw)\s+(?:(\d{1,2})\s*)?d(\d{1,3})\b"#
        guard let match = firstMatch(pattern, in: value),
              let sides = Int(match[2]), (2...1_000).contains(sides) else { return nil }
        let count = max(1, min(20, Int(match[1]) ?? 1))
        let rolls = (0..<count).map { _ in Int.random(in: 1...sides) }
        if count == 1 { return "You rolled a \(rolls[0]) on a d\(sides)." }
        return "Your \(count)d\(sides) rolls are \(rolls.map(String.init).joined(separator: ", ")), totaling \(rolls.reduce(0, +))."
    }

    private static func choiceAnswer(in value: String) -> String? {
        let pattern = #"^(?:please\s+)?choose between\s+(.+?)\s+(?:or|and)\s+(.+?)[?.!]*$"#
        guard let match = firstMatch(pattern, in: value) else { return nil }
        let choices = [match[1], match[2]].map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        guard choices.allSatisfy({ !$0.isEmpty && $0.count <= 80 }) else { return nil }
        return "I pick \(choices.randomElement()!)."
    }

    private static func firstMatch(_ pattern: String, in value: String) -> [String]? {
        guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = expression.firstMatch(in: value, range: NSRange(value.startIndex..., in: value)) else { return nil }
        return (0..<match.numberOfRanges).map { index in
            guard let range = Range(match.range(at: index), in: value) else { return "" }
            return String(value[range])
        }
    }

    private static func format(_ number: Double) -> String {
        String(format: "%.10g", number)
    }
}

public enum AnnaSpeechChunker {
    /// Keeps displayed emoji out of spoken output instead of reading their names aloud.
    public static func speechText(_ text: String) -> String {
        let withoutEmoji = String(text.filter { character in
            !character.unicodeScalars.contains { scalar in
                guard scalar.properties.isEmoji else { return false }
                if scalar.properties.generalCategory == .decimalNumber || scalar.value == 0x23 || scalar.value == 0x2A {
                    return false
                }
                return true
            }
        })
        let normalized = CompanionResponseValidator.withoutLongDashes(withoutEmoji)
            .split(whereSeparator: \.isWhitespace)
            .joined(separator: " ")
        return normalized.replacingOccurrences(
            of: #"\s+([,!.?;:])"#,
            with: "$1",
            options: .regularExpression
        )
    }

    /// Splits already-validated reply text into natural speech units without
    /// changing its wording or breaking decimal numbers at their full stop.
    public static func sentenceChunks(_ text: String, maximumCharacters: Int = 180) -> [String] {
        let cleaned = speechText(text)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return [] }
        let characters = Array(cleaned)
        let maximum = max(40, maximumCharacters)
        var buffer = ""
        var chunks: [String] = []

        func appendBuffer() {
            let chunk = buffer.trimmingCharacters(in: .whitespacesAndNewlines)
            if !chunk.isEmpty { chunks.append(chunk) }
            buffer = ""
        }

        for (index, character) in characters.enumerated() {
            buffer.append(character)
            let next = index + 1 < characters.count ? characters[index + 1] : nil
            let endsSentence = [".", "!", "?"].contains(String(character))
                && (next == nil || next?.isWhitespace == true)
            if endsSentence || (buffer.count >= maximum && character.isWhitespace) {
                appendBuffer()
            }
        }
        appendBuffer()
        return chunks
    }
}
