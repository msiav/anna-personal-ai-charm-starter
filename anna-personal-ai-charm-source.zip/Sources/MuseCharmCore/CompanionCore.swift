import Foundation

public enum CharmExpression: String, Codable, CaseIterable, Sendable {
    case calm
    case curious
    case sleepy
    case happy
    case concerned
    case listening
    case thinking
    case excited
    case proud
    case tiredProud
    case focused
    case bashful
    case confused
}

public enum CharmHaptic: String, Codable, CaseIterable, Sendable {
    case soft
    case double
    case success
    case warning
}

public enum CharmStatus: String, Codable, CaseIterable, Sendable {
    case idle
    case replying
    case offline
}

public enum CompanionMode: String, Codable, CaseIterable, Sendable {
    case awakeIdle
    case engaged
    case listening
    case thinking
    case workoutActive
    case workoutRecovering
    case windingDown
    case sleeping
    case waking
    case focusQuiet
    case offline
    case permissionLimited
}

public enum CompanionIntent: String, Codable, CaseIterable, Sendable {
    case greeting
    case status
    case comfort
    case workoutEncouragement
    case sleep
    case wake
    case quiet
    case acknowledgement
    case repeatLast = "repeat"
    case answer
    case clarify
    case celebrate
    case refuse
}

public enum CompanionSeriousness: String, Codable, CaseIterable, Sendable {
    case casual
    case normal
    case sensitive
}

public enum CharmGesture: String, Codable, CaseIterable, Sendable {
    case nod
    case tilt
    case bounce
    case settle
    case none
}

public enum CompanionAttentionTarget: String, Codable, CaseIterable, Sendable {
    case user
    case conversation
    case ambient
    case none
}

/// A complete, validated performance proposal. Views and platform services consume this plan;
/// response providers do not control sensors, haptics, or persisted state directly.
public struct CompanionReplyPlan: Codable, Equatable, Sendable {
    public let responseID: String
    public let spokenText: String
    public let displayText: String?
    public let intent: CompanionIntent
    public let emotion: CharmExpression
    public let valence: Double
    public let arousal: Double
    public let intensity: Double
    public let seriousness: CompanionSeriousness
    public let confidence: Double
    public let gesture: CharmGesture
    public let haptic: CharmHaptic?
    public let followUp: String?
    public let requiresUserConfirmation: Bool
    public let safetyTags: [String]

    public init(
        responseID: String,
        spokenText: String,
        displayText: String? = nil,
        intent: CompanionIntent,
        emotion: CharmExpression,
        valence: Double = 0.2,
        arousal: Double = 0.25,
        intensity: Double = 0.25,
        seriousness: CompanionSeriousness = .normal,
        confidence: Double = 1,
        gesture: CharmGesture = .none,
        haptic: CharmHaptic? = nil,
        followUp: String? = nil,
        requiresUserConfirmation: Bool = false,
        safetyTags: [String] = []
    ) {
        self.responseID = responseID
        self.spokenText = spokenText
        self.displayText = displayText
        self.intent = intent
        self.emotion = emotion
        self.valence = Self.clamp(valence, lower: -1, upper: 1)
        self.arousal = Self.clamp(arousal, lower: 0, upper: 1)
        self.intensity = Self.clamp(intensity, lower: 0, upper: 1)
        self.seriousness = seriousness
        self.confidence = Self.clamp(confidence, lower: 0, upper: 1)
        self.gesture = gesture
        self.haptic = seriousness == .sensitive ? nil : haptic
        self.followUp = followUp
        self.requiresUserConfirmation = requiresUserConfirmation
        self.safetyTags = safetyTags
    }

    fileprivate static func clamp(_ value: Double, lower: Double, upper: Double) -> Double {
        min(max(value.isFinite ? value : lower, lower), upper)
    }
}

public protocol CompanionResponseProvider: Sendable {
    func response(for input: String, state: CompanionState) -> CompanionReplyPlan
}

/// Local, deterministic replies keep Anna useful with the language model unloaded or offline.
public struct DeterministicCompanionResponseProvider: CompanionResponseProvider {
    public init() {}

    public func response(for input: String, state: CompanionState) -> CompanionReplyPlan {
        let normalized = input.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let words = Set(normalized.split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init))

        if normalized.contains("what's your name") || normalized.contains("what is your name") || normalized.contains("who are you") {
            return plan("identity.anna", "I’m Anna, a little voice by your side.", .status, .happy)
        }

        if normalized.contains("2+2") || normalized.contains("2 + 2") || normalized.contains("two plus two") {
            return plan("math.two-plus-two", "2 + 2 is 4.", .answer, .proud)
        }

        if normalized.contains("how are you") || normalized.contains("how do you feel") || normalized.contains("you okay") {
            return choose([
                plan("status.ready.1", "I’m here and ready to listen.", .status, .calm),
                plan("status.ready.2", "Calm, curious, and right here with you.", .status, .curious),
                plan("status.ready.3", "I’m doing my favorite thing: paying attention.", .status, .happy)
            ], state: state)
        }

        if words.contains("hello") || words.contains("hey") || words.contains("hi") || words.contains("morning") {
            return choose([
                plan("greeting.1", "Hey. I’m glad you stopped by.", .greeting, .happy, haptic: .soft),
                plan("greeting.2", "Hi there. What’s on your mind?", .greeting, .curious),
                plan("greeting.3", "A little hello, right back to you.", .greeting, .bashful, haptic: .soft)
            ], state: state)
        }

        if normalized.contains("thank") || words.contains("thanks") || words.contains("okay") || words.contains("ok") || words.contains("got it") {
            return choose([
                plan("acknowledgement.1", "Anytime.", .acknowledgement, .calm),
                plan("acknowledgement.2", "Got you.", .acknowledgement, .happy, haptic: .soft),
                plan("acknowledgement.3", "We’re good.", .acknowledgement, .bashful)
            ], state: state)
        }

        if normalized.contains("sad") || normalized.contains("bad day") || normalized.contains("stressed") || normalized.contains("scared") {
            return plan(
                "comfort.here",
                "I’m here with you. We can take this one small step at a time.",
                .comfort,
                .concerned,
                valence: 0.05,
                seriousness: .sensitive,
                gesture: .settle,
                safetyTags: ["supportive", "non-diagnostic"]
            )
        }

        if normalized.contains("tired") || normalized.contains("sleepy") {
            return choose([
                plan("comfort.tired.1", "We can slow things down. Want a quiet moment?", .comfort, .sleepy, valence: 0.12, arousal: 0.08, gesture: .settle),
                plan("comfort.tired.2", "No rush. I’ll keep things gentle.", .comfort, .tiredProud, valence: 0.16, arousal: 0.07, gesture: .settle),
                plan("comfort.tired.3", "A softer pace sounds good. I’m here.", .comfort, .sleepy, valence: 0.12, arousal: 0.08, gesture: .settle)
            ], state: state)
        }

        if normalized.contains("workout") || normalized.contains("exercise") || words.contains("run") || words.contains("gym") {
            return choose([
                plan("workout.encourage.1", "Want a little workout energy? I’m cheering for you.", .workoutEncouragement, .proud, haptic: .soft),
                plan("workout.encourage.2", "One step at a time. You’ve got this.", .workoutEncouragement, .focused),
                plan("workout.encourage.3", "I can bring the tiny hype. You bring the pace.", .workoutEncouragement, .excited, haptic: .double)
            ], state: state)
        }

        if normalized.contains("repeat") || normalized.contains("say that again") {
            return plan("repeat.unavailable", "I don’t have a previous spoken line queued to repeat yet.", .repeatLast, .confused)
        }

        return plan(
            "clarify.unsupported",
            "I don’t know that yet, but I can still listen and think it through with you.",
            .clarify,
            .curious,
            confidence: 0.55,
            gesture: .tilt
        )
    }

    private func choose(_ candidates: [CompanionReplyPlan], state: CompanionState) -> CompanionReplyPlan {
        if let fresh = candidates.first(where: { !state.recentResponseIDs.contains($0.responseID) }) {
            return fresh
        }
        let extraLines = [
            "A little light for this moment.",
            "I’m here, in my own small way.",
            "There you are. I like this moment.",
            "A quiet hello from your pocket-sized friend.",
            "I’m glad we found this little pause.",
            "Still here, keeping you company.",
            "One soft sparkle, no rush.",
            "A gentle hello, right on time.",
            "I’ll stay close while you take a breath.",
            "Here’s a tiny bit of brightness."
        ]
        let index = max(0, state.interactionCount - 1) % extraLines.count
        return plan(
            "\(candidates[0].intent.rawValue).extra.\(state.interactionCount)",
            extraLines[index],
            candidates[0].intent,
            .bashful
        )
    }

    private func plan(
        _ id: String,
        _ text: String,
        _ intent: CompanionIntent,
        _ emotion: CharmExpression,
        valence: Double = 0.25,
        arousal: Double = 0.28,
        intensity: Double = 0.2,
        seriousness: CompanionSeriousness = .normal,
        confidence: Double = 1,
        gesture: CharmGesture = .none,
        haptic: CharmHaptic? = nil,
        safetyTags: [String] = []
    ) -> CompanionReplyPlan {
        CompanionReplyPlan(
            responseID: id,
            spokenText: text,
            intent: intent,
            emotion: emotion,
            valence: valence,
            arousal: arousal,
            intensity: intensity,
            seriousness: seriousness,
            confidence: confidence,
            gesture: gesture,
            haptic: haptic,
            safetyTags: safetyTags
        )
    }
}

/// Converts untrusted model text into a bounded, locally classified reaction plan.
public enum CompanionResponseValidator {
    public static func proposal(
        from text: String,
        inResponseTo input: String,
        state: CompanionState
    ) -> CompanionReplyPlan? {
        let cleaned = withoutLongDashes(text).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty, cleaned.count <= 1_200 else { return nil }

        let boundedText = bounded(cleaned, limit: 420)
        let lowerInput = input.lowercased()
        let sensitiveTerms = ["hurt", "harm", "panic", "anxious", "depressed", "grief", "medical", "heart rate", "diagnos"]
        let isSensitive = sensitiveTerms.contains(where: lowerInput.contains)
        let isGreeting = ["hello", "hi", "hey"].contains { lowerInput.split(whereSeparator: { !$0.isLetter }).contains(Substring($0)) }
        let emotion: CharmExpression = isSensitive ? .concerned : (isGreeting ? .happy : (boundedText.contains("?") ? .curious : .calm))
        let seriousness: CompanionSeriousness = isSensitive ? .sensitive : .normal
        let haptic: CharmHaptic? = isSensitive ? nil : (isGreeting ? .soft : nil)
        let responseID = "model-\(state.interactionCount)-\(boundedText.count)"

        let plan = CompanionReplyPlan(
            responseID: responseID,
            spokenText: boundedText,
            displayText: boundedText,
            intent: isSensitive ? .comfort : .answer,
            emotion: emotion,
            valence: isSensitive ? 0.05 : 0.2,
            arousal: isSensitive ? 0.12 : 0.24,
            intensity: isSensitive ? 0.08 : 0.2,
            seriousness: seriousness,
            confidence: isSensitive ? 0.5 : 0.7,
            gesture: isSensitive ? .settle : (emotion == .happy ? .bounce : .none),
            haptic: haptic,
            safetyTags: isSensitive ? ["supportive", "non-diagnostic"] : []
        )

        return validate(plan)
    }

    /// Keeps generated chat copy free of typographic long dashes, including while streaming.
    public static func withoutLongDashes(_ text: String) -> String {
        text.replacingOccurrences(of: "—", with: "-")
            .replacingOccurrences(of: "–", with: "-")
    }

    public static func validate(_ proposal: CompanionReplyPlan?) -> CompanionReplyPlan? {
        guard let proposal else { return nil }
        let text = withoutLongDashes(proposal.spokenText).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 420, !proposal.responseID.isEmpty else { return nil }

        return CompanionReplyPlan(
            responseID: String(proposal.responseID.prefix(80)),
            spokenText: text,
            displayText: proposal.displayText.map { bounded(withoutLongDashes($0), limit: 420) },
            intent: proposal.intent,
            emotion: proposal.emotion,
            valence: proposal.valence,
            arousal: proposal.arousal,
            intensity: proposal.intensity,
            seriousness: proposal.seriousness,
            confidence: proposal.confidence,
            gesture: proposal.gesture,
            haptic: proposal.haptic,
            followUp: proposal.followUp.map { bounded(withoutLongDashes($0), limit: 120) },
            requiresUserConfirmation: proposal.requiresUserConfirmation,
            safetyTags: Array(proposal.safetyTags.prefix(8))
        )
    }

    private static func bounded(_ text: String, limit: Int) -> String {
        guard text.count > limit else { return text }
        let prefix = String(text.prefix(limit))
        guard let lastSpace = prefix.lastIndex(where: \.isWhitespace) else { return prefix + "…" }
        return String(prefix[..<lastSpace]) + "…"
    }
}

public struct CompanionState: Codable, Equatable, Sendable {
    public fileprivate(set) var mood: Int
    public fileprivate(set) var energy: Int
    public fileprivate(set) var interactionCount: Int
    public fileprivate(set) var expression: CharmExpression
    public fileprivate(set) var status: CharmStatus
    public fileprivate(set) var mode: CompanionMode
    public fileprivate(set) var valence: Double
    public fileprivate(set) var arousal: Double
    public fileprivate(set) var socialOpenness: Double
    public fileprivate(set) var curiosity: Double
    public fileprivate(set) var comfort: Double
    public fileprivate(set) var exertionMirroring: Double
    public fileprivate(set) var attentionTarget: CompanionAttentionTarget
    public fileprivate(set) var lastMeaningfulInteraction: Date?
    public fileprivate(set) var lastHapticAt: Date?
    public fileprivate(set) var recentResponseIDs: [String]
    public fileprivate(set) var quietMode: Bool
    public fileprivate(set) var hapticsEnabled: Bool

    public var energyLevel: Double { Double(energy) / 5 }

    public mutating func restoreRecentResponseIDs(_ identifiers: [String]) {
        recentResponseIDs = Array(identifiers.suffix(8))
    }

    public init(
        mood: Int = 0,
        energy: Int = 3,
        interactionCount: Int = 0,
        expression: CharmExpression = .calm,
        status: CharmStatus = .idle,
        mode: CompanionMode = .awakeIdle,
        valence: Double? = nil,
        arousal: Double = 0.2,
        socialOpenness: Double = 0.35,
        curiosity: Double = 0.35,
        comfort: Double = 0.45,
        exertionMirroring: Double = 0,
        attentionTarget: CompanionAttentionTarget = .user,
        lastMeaningfulInteraction: Date? = nil,
        lastHapticAt: Date? = nil,
        recentResponseIDs: [String] = [],
        quietMode: Bool = false,
        hapticsEnabled: Bool = true
    ) {
        self.mood = Self.clamp(mood)
        self.energy = Self.clamp(energy, lower: 0, upper: 5)
        self.interactionCount = max(0, interactionCount)
        self.expression = expression
        self.status = mode == .sleeping ? .idle : status
        self.mode = mode
        self.valence = Self.clamp(valence ?? Double(Self.clamp(mood)) / 2, lower: -1, upper: 1)
        self.arousal = Self.clamp(arousal, lower: 0, upper: 1)
        self.socialOpenness = Self.clamp(socialOpenness, lower: 0, upper: 1)
        self.curiosity = Self.clamp(curiosity, lower: 0, upper: 1)
        self.comfort = Self.clamp(comfort, lower: 0, upper: 1)
        self.exertionMirroring = Self.clamp(exertionMirroring, lower: 0, upper: 1)
        self.attentionTarget = attentionTarget
        self.lastMeaningfulInteraction = lastMeaningfulInteraction
        self.lastHapticAt = lastHapticAt
        self.recentResponseIDs = Array(recentResponseIDs.suffix(8))
        self.quietMode = quietMode
        self.hapticsEnabled = hapticsEnabled
        if mode == .sleeping { self.expression = .sleepy }
    }

    fileprivate mutating func apply(
        moodDelta: Int = 0,
        energyDelta: Int = 0,
        valenceDelta: Double = 0,
        arousalDelta: Double = 0,
        socialDelta: Double = 0,
        curiosityDelta: Double = 0,
        comfortDelta: Double = 0
    ) {
        mood = Self.clamp(mood + moodDelta)
        energy = Self.clamp(energy + energyDelta, lower: 0, upper: 5)
        valence = Self.clamp(valence + valenceDelta, lower: -1, upper: 1)
        arousal = Self.clamp(arousal + arousalDelta, lower: 0, upper: 1)
        socialOpenness = Self.clamp(socialOpenness + socialDelta, lower: 0, upper: 1)
        curiosity = Self.clamp(curiosity + curiosityDelta, lower: 0, upper: 1)
        comfort = Self.clamp(comfort + comfortDelta, lower: 0, upper: 1)
    }

    fileprivate static func clamp(_ value: Int, lower: Int = -2, upper: Int = 2) -> Int {
        min(max(value, lower), upper)
    }

    fileprivate static func clamp(_ value: Double, lower: Double, upper: Double) -> Double {
        min(max(value.isFinite ? value : lower, lower), upper)
    }

    private enum CodingKeys: String, CodingKey {
        case mood, energy, interactionCount, expression, status, mode
        case valence, arousal, socialOpenness, curiosity, comfort, exertionMirroring
        case attentionTarget, lastMeaningfulInteraction, lastHapticAt, recentResponseIDs, quietMode, hapticsEnabled
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.init(
            mood: try values.decodeIfPresent(Int.self, forKey: .mood) ?? 0,
            energy: try values.decodeIfPresent(Int.self, forKey: .energy) ?? 3,
            interactionCount: try values.decodeIfPresent(Int.self, forKey: .interactionCount) ?? 0,
            expression: try values.decodeIfPresent(CharmExpression.self, forKey: .expression) ?? .calm,
            status: try values.decodeIfPresent(CharmStatus.self, forKey: .status) ?? .idle,
            mode: try values.decodeIfPresent(CompanionMode.self, forKey: .mode) ?? .awakeIdle,
            valence: try values.decodeIfPresent(Double.self, forKey: .valence),
            arousal: try values.decodeIfPresent(Double.self, forKey: .arousal) ?? 0.2,
            socialOpenness: try values.decodeIfPresent(Double.self, forKey: .socialOpenness) ?? 0.35,
            curiosity: try values.decodeIfPresent(Double.self, forKey: .curiosity) ?? 0.35,
            comfort: try values.decodeIfPresent(Double.self, forKey: .comfort) ?? 0.45,
            exertionMirroring: try values.decodeIfPresent(Double.self, forKey: .exertionMirroring) ?? 0,
            attentionTarget: try values.decodeIfPresent(CompanionAttentionTarget.self, forKey: .attentionTarget) ?? .user,
            lastMeaningfulInteraction: try values.decodeIfPresent(Date.self, forKey: .lastMeaningfulInteraction),
            lastHapticAt: try values.decodeIfPresent(Date.self, forKey: .lastHapticAt),
            recentResponseIDs: try values.decodeIfPresent([String].self, forKey: .recentResponseIDs) ?? [],
            quietMode: try values.decodeIfPresent(Bool.self, forKey: .quietMode) ?? false,
            hapticsEnabled: try values.decodeIfPresent(Bool.self, forKey: .hapticsEnabled) ?? true
        )
    }
}

public enum CompanionCommand: Equatable, Sendable {
    case tap
    case doubleTap
    case longPress
    case userInput(String)
    case beginListening
    case beginThinking
    case assistantReply(CompanionReplyPlan)
    case finishSpeaking
    case dismiss
    case rest
    case wake
    case setQuietMode(Bool)
    case setHapticsEnabled(Bool)
    case tick
}

public struct CompanionEvent: Codable, Equatable, Sendable {
    public enum Kind: String, Codable, Sendable {
        case status = "event.status"
        case mode = "event.mode"
        case reply = "event.reply"
        case expression = "event.expression"
        case reactionPlan = "event.reaction-plan"
        case haptic = "event.haptic"
    }

    public let kind: Kind
    public let text: String?
    public let status: CharmStatus?
    public let mode: CompanionMode?
    public let expression: CharmExpression?
    public let haptic: CharmHaptic?
    public let moodDelta: Int?
    public let reactionPlan: CompanionReplyPlan?
    public let source: String

    public init(
        kind: Kind,
        text: String? = nil,
        status: CharmStatus? = nil,
        mode: CompanionMode? = nil,
        expression: CharmExpression? = nil,
        haptic: CharmHaptic? = nil,
        moodDelta: Int? = nil,
        reactionPlan: CompanionReplyPlan? = nil,
        source: String = "local"
    ) {
        self.kind = kind
        self.text = text
        self.status = status
        self.mode = mode
        self.expression = expression
        self.haptic = haptic
        self.moodDelta = moodDelta
        self.reactionPlan = reactionPlan
        self.source = source
    }
}

/// Deterministic, offline-first behavior shared by the iPhone and watch shells.
public struct CompanionCore: Sendable {
    public private(set) var state: CompanionState
    private let provider: any CompanionResponseProvider

    public init(
        state: CompanionState = CompanionState(),
        provider: any CompanionResponseProvider = DeterministicCompanionResponseProvider()
    ) {
        self.state = state
        self.provider = provider
    }

    public mutating func handle(_ command: CompanionCommand, at now: Date = Date()) -> [CompanionEvent] {
        switch command {
        case .tap:
            state.interactionCount += 1
            state.lastMeaningfulInteraction = now
            if state.mode == .sleeping {
                state.expression = .sleepy
                return [
                    CompanionEvent(kind: .reply, text: "A tiny stir. I’m still resting."),
                    CompanionEvent(kind: .expression, expression: .sleepy),
                    CompanionEvent(kind: .mode, mode: .sleeping)
                ]
            }
            state.apply(valenceDelta: 0.08, arousalDelta: 0.03, socialDelta: 0.04, curiosityDelta: 0.06)
            let plan = select([
                reply("tap.hello.1", "A tiny sparkle, just for you.", .greeting, .curious, gesture: .bounce, haptic: .soft),
                reply("tap.hello.2", "I noticed that. Hi.", .greeting, .happy, gesture: .bounce, haptic: .soft),
                reply("tap.hello.3", "A little hello back.", .greeting, .bashful, haptic: .soft)
            ])
            return perform(plan, at: now)

        case .doubleTap:
            state.interactionCount += 1
            state.lastMeaningfulInteraction = now
            if state.mode == .sleeping {
                return [CompanionEvent(kind: .reply, text: "A tiny stir. Long-press or tap Wake when you’re ready."), CompanionEvent(kind: .expression, expression: .sleepy)]
            }
            state.apply(moodDelta: 1, valenceDelta: 0.14, arousalDelta: 0.18, socialDelta: 0.06)
            return perform(select([
                reply("tap.delight.1", "Oh! A double sparkle!", .celebrate, .excited, gesture: .bounce, haptic: .success),
                reply("tap.delight.2", "That was fun. Do it again sometime.", .celebrate, .happy, gesture: .bounce, haptic: .soft)
            ]), at: now)

        case .longPress:
            if state.mode == .sleeping { return handle(.wake, at: now) }
            state.interactionCount += 1
            state.lastMeaningfulInteraction = now
            state.apply(valenceDelta: 0.07, arousalDelta: -0.12, socialDelta: 0.05, comfortDelta: 0.16)
            return perform(reply("touch.comfort", "Mm. That’s a nice quiet moment.", .comfort, .happy, valence: 0.45, arousal: 0.12, gesture: .settle, haptic: .soft), at: now)

        case let .userInput(input):
            return resolve(input, at: now)

        case .beginListening:
            guard state.mode != .sleeping else { return handle(.tap, at: now) }
            state.mode = .listening
            state.status = .replying
            state.expression = .listening
            state.attentionTarget = .conversation
            return [
                CompanionEvent(kind: .mode, mode: .listening),
                CompanionEvent(kind: .status, status: .replying),
                CompanionEvent(kind: .expression, expression: .listening)
            ]

        case .beginThinking:
            guard state.mode != .sleeping else { return [] }
            state.mode = .thinking
            state.expression = .thinking
            return [
                CompanionEvent(kind: .mode, mode: .thinking),
                CompanionEvent(kind: .expression, expression: .thinking)
            ]

        case let .assistantReply(proposal):
            guard let plan = CompanionResponseValidator.validate(proposal) else {
                return perform(provider.response(for: "", state: state), at: now)
            }
            state.interactionCount += 1
            state.lastMeaningfulInteraction = now
            return perform(plan, at: now)

        case .finishSpeaking:
            state.status = .idle
            if state.mode != .sleeping && state.mode != .focusQuiet {
                state.mode = .awakeIdle
            }
            return [CompanionEvent(kind: .status, status: .idle), CompanionEvent(kind: .mode, mode: state.mode)]

        case .dismiss:
            state.status = .idle
            if state.mode != .sleeping && state.mode != .focusQuiet { state.mode = .awakeIdle }
            if state.mode != .sleeping { state.expression = .calm }
            return [
                CompanionEvent(kind: .status, status: .idle),
                CompanionEvent(kind: .mode, mode: state.mode),
                CompanionEvent(kind: .expression, expression: state.expression)
            ]

        case .rest:
            let haptic = reserveHaptic(.soft, at: now)
            state.mode = .windingDown
            state.expression = .sleepy
            state.status = .idle
            state.arousal = max(0, state.arousal - 0.2)
            state.mode = .sleeping
            return [
                CompanionEvent(kind: .mode, mode: .windingDown),
                CompanionEvent(kind: .expression, expression: .sleepy),
                CompanionEvent(kind: .mode, mode: .sleeping),
                CompanionEvent(kind: .reply, text: "I’m settling in for a quiet rest."),
                CompanionEvent(kind: .haptic, haptic: haptic)
            ]

        case .wake:
            let haptic = reserveHaptic(.soft, at: now)
            state.mode = .waking
            state.expression = .happy
            state.status = .idle
            state.lastMeaningfulInteraction = now
            return [
                CompanionEvent(kind: .mode, mode: .waking),
                CompanionEvent(kind: .reply, text: "I’m awake. Good to see you."),
                CompanionEvent(kind: .expression, expression: .happy),
                CompanionEvent(kind: .haptic, haptic: haptic)
            ]

        case let .setQuietMode(enabled):
            state.quietMode = enabled
            if enabled, state.mode != .sleeping {
                state.mode = .focusQuiet
            } else if !enabled, state.mode == .focusQuiet {
                state.mode = .awakeIdle
            }
            let line = enabled ? "Quiet mode is on. I’ll keep things calm." : "Quiet mode is off."
            return [CompanionEvent(kind: .mode, mode: state.mode), CompanionEvent(kind: .reply, text: line)]

        case let .setHapticsEnabled(enabled):
            state.hapticsEnabled = enabled
            return []

        case .tick:
            if state.mode == .sleeping {
                state.energy = CompanionState.clamp(state.energy + 1, lower: 0, upper: 5)
                state.arousal = max(0.04, state.arousal - 0.04)
                state.expression = .sleepy
                return [CompanionEvent(kind: .expression, expression: .sleepy), CompanionEvent(kind: .mode, mode: .sleeping)]
            }
            state.valence += (0.2 - state.valence) * 0.08
            state.arousal += (0.2 - state.arousal) * 0.12
            if state.mode == .engaged || state.mode == .waking || state.mode == .workoutRecovering {
                state.mode = state.quietMode ? .focusQuiet : .awakeIdle
                state.status = .idle
            }
            return [CompanionEvent(kind: .mode, mode: state.mode)]
        }
    }

    public mutating func recordInteraction(at date: Date) {
        state.lastMeaningfulInteraction = date
    }

    private mutating func resolve(_ input: String, at now: Date) -> [CompanionEvent] {
        let normalized = input.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !normalized.isEmpty else { return handle(.tap, at: now) }

        if normalized == "wake" || normalized.contains("wake up") || normalized.contains("wake anna") {
            return handle(.wake, at: now)
        }
        if normalized == "sleep" || normalized.contains("go to sleep") || normalized == "rest" {
            return handle(.rest, at: now)
        }
        if normalized.contains("quiet mode off") || normalized.contains("turn off quiet") {
            return handle(.setQuietMode(false), at: now)
        }
        if normalized.contains("quiet mode") || normalized.contains("focus mode") {
            return handle(.setQuietMode(true), at: now)
        }

        if state.mode == .sleeping {
            return handle(.tap, at: now)
        }

        state.interactionCount += 1
        state.lastMeaningfulInteraction = now
        state.mode = .listening
        state.status = .replying
        state.expression = .listening
        state.attentionTarget = .conversation
        var events = [
            CompanionEvent(kind: .mode, mode: .listening),
            CompanionEvent(kind: .expression, expression: .listening),
            CompanionEvent(kind: .mode, mode: .thinking),
            CompanionEvent(kind: .expression, expression: .thinking)
        ]
        state.mode = .thinking
        state.expression = .thinking

        let plan: CompanionReplyPlan
        if normalized.contains("time") {
            plan = reply("time.local", "It’s \(now.formatted(date: .omitted, time: .shortened)).", .answer, .calm, confidence: 1)
        } else if normalized.contains("date") || normalized.contains("day is it") {
            plan = reply("date.local", "Today is \(now.formatted(date: .complete, time: .omitted)).", .answer, .calm, confidence: 1)
        } else if normalized.contains("cancel") || normalized.contains("never mind") {
            state.mode = state.quietMode ? .focusQuiet : .awakeIdle
            state.status = .idle
            state.expression = .calm
            return events + [CompanionEvent(kind: .reply, text: "Canceled. I’m back with you."), CompanionEvent(kind: .expression, expression: .calm)]
        } else {
            plan = provider.response(for: input, state: state)
        }
        events += perform(plan, at: now)
        return events
    }

    private mutating func perform(_ plan: CompanionReplyPlan, at now: Date) -> [CompanionEvent] {
        state.mode = state.quietMode ? .focusQuiet : .engaged
        state.status = .idle
        state.expression = plan.emotion
        state.valence = CompanionState.clamp((state.valence * 0.65) + (plan.valence * 0.35), lower: -1, upper: 1)
        state.arousal = CompanionState.clamp((state.arousal * 0.55) + (plan.arousal * 0.45), lower: 0, upper: 1)
        if plan.valence > 0.35 { state.mood = CompanionState.clamp(state.mood + 1) }
        state.recentResponseIDs = Array((state.recentResponseIDs + [plan.responseID]).suffix(8))

        var events = [
            CompanionEvent(kind: .mode, mode: state.mode),
            CompanionEvent(kind: .reply, text: plan.displayText ?? plan.spokenText, reactionPlan: plan),
            CompanionEvent(kind: .expression, expression: plan.emotion, moodDelta: plan.valence > 0.35 ? 1 : 0),
            CompanionEvent(kind: .reactionPlan, reactionPlan: plan)
        ]
        if let requested = plan.haptic, plan.seriousness != .sensitive, let haptic = reserveHaptic(requested, at: now) {
            events.append(CompanionEvent(kind: .haptic, haptic: haptic, reactionPlan: plan))
        }
        return events
    }

    private mutating func reserveHaptic(_ haptic: CharmHaptic, at now: Date) -> CharmHaptic? {
        guard state.hapticsEnabled, !state.quietMode else { return nil }
        guard state.lastHapticAt.map({ now.timeIntervalSince($0) >= 1.5 }) ?? true else { return nil }
        state.lastHapticAt = now
        return haptic
    }

    private func select(_ candidates: [CompanionReplyPlan]) -> CompanionReplyPlan {
        if let fresh = candidates.first(where: { !state.recentResponseIDs.contains($0.responseID) }) {
            return fresh
        }
        let fallbackLines: [String]
        switch candidates.first?.intent {
        case .celebrate:
            fallbackLines = [
                "That was a sweet little surprise.",
                "You caught me smiling.",
                "A tiny celebration, just us.",
                "That made my pixels perk up.",
                "I’m keeping that happy moment.",
                "You brought a little sparkle with you.",
                "A lovely bit of silliness.",
                "That was fun. I’m still glowing.",
                "A small moment, a big smile.",
                "You made this moment brighter."
            ]
        default:
            fallbackLines = [
                "A little light for this moment.",
                "I’m here, in my own small way.",
                "There you are. I like this moment.",
                "A quiet hello from your pocket-sized friend.",
                "I’m glad we found this little pause.",
                "Still here, keeping you company.",
                "One soft sparkle, no rush.",
                "A gentle hello, right on time.",
                "I’ll stay close while you take a breath.",
                "Here’s a tiny bit of brightness."
            ]
        }
        let interaction = max(1, state.interactionCount)
        let line = fallbackLines[(interaction - 1) % fallbackLines.count]
        return CompanionReplyPlan(
            responseID: "\(candidates[0].intent.rawValue).extra.\(interaction)",
            spokenText: line,
            intent: candidates[0].intent,
            emotion: candidates[0].emotion,
            gesture: candidates[0].gesture,
            haptic: candidates[0].haptic
        )
    }

    private func reply(
        _ id: String,
        _ text: String,
        _ intent: CompanionIntent,
        _ emotion: CharmExpression,
        valence: Double = 0.25,
        arousal: Double = 0.24,
        intensity: Double = 0.18,
        seriousness: CompanionSeriousness = .normal,
        confidence: Double = 1,
        gesture: CharmGesture = .none,
        haptic: CharmHaptic? = nil,
        safetyTags: [String] = []
    ) -> CompanionReplyPlan {
        CompanionReplyPlan(
            responseID: id,
            spokenText: text,
            intent: intent,
            emotion: emotion,
            valence: valence,
            arousal: arousal,
            intensity: intensity,
            seriousness: seriousness,
            confidence: confidence,
            gesture: gesture,
            haptic: haptic,
            safetyTags: safetyTags
        )
    }
}
