#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT="$ROOT/AnnaCharmWatch.xcodeproj"
SCHEME="AnnaWatchContainer"
XCODE_DEFAULTS_DOMAIN="com.apple.dt.Xcode"
XCODE_PREBUILT_KEY="IDEPackageEnablePrebuilts"

if ! command -v xcodebuild >/dev/null 2>&1; then
    echo "Xcode command line tools were not found. Install Xcode, open it once, and try again." >&2
    exit 1
fi

if /usr/bin/pgrep -x Xcode >/dev/null 2>&1; then
    echo "Please quit Xcode, then run this script again. The SwiftSyntax workaround is read when Xcode starts." >&2
    exit 2
fi

if [[ ! -d "$PROJECT" ]]; then
    echo "Could not find AnnaCharmWatch.xcodeproj beside this script." >&2
    exit 1
fi

current_prebuilt_setting="$(defaults read "$XCODE_DEFAULTS_DOMAIN" "$XCODE_PREBUILT_KEY" 2>/dev/null || true)"
if [[ "$current_prebuilt_setting" != "0" && "$current_prebuilt_setting" != "false" ]]; then
    defaults write "$XCODE_DEFAULTS_DOMAIN" "$XCODE_PREBUILT_KEY" -bool NO
    echo "Disabled Xcode's SwiftSyntax macro prebuilts for this Mac, following Apple's Xcode 26 workaround."
fi

echo "Resolving Swift packages..."
xcodebuild \
    -resolvePackageDependencies \
    -project "$PROJECT" \
    -scheme "$SCHEME" \
    -derivedDataPath "$ROOT/.build/DerivedData"

echo "Building Anna for the iOS Simulator..."
xcodebuild \
    -project "$PROJECT" \
    -scheme "$SCHEME" \
    -destination "generic/platform=iOS Simulator" \
    -derivedDataPath "$ROOT/.build/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    build

echo "Build succeeded. Open AnnaCharmWatch.xcodeproj, choose the AnnaWatchContainer scheme, select an iPhone simulator, and press Run."
