import XCTest
@testable import MuseCharmCore

final class CompanionCoreTests: XCTestCase {
    func testRequestRouterHandlesDirectRequestsAndKeepsSmallTalkInChat() {
        let cases: [(String, AnnaRequestIntent)] = [
            ("Search for the latest iOS release", .liveSearch("the latest iOS release")),
            ("Look up online the train schedule", .liveSearch("the train schedule")),
            ("What's happening in Toronto today?", .liveSearch("What's happening in Toronto today?")),
            ("Who won last night?", .liveSearch("Who won last night?")),
            ("NBA games today", .liveSearch("NBA games today")),
            ("What are the NHL scores tonight?", .liveSearch("What are the NHL scores tonight?")),
            ("Is it going to rain tomorrow?", .liveSearch("Is it going to rain tomorrow?")),
            ("Find me a quiet cafe", .liveSearch("a quiet cafe")),
            ("Can you search the web for a recipe?", .liveSearch("a recipe?")),
            ("What can you do?", .capabilities),
            ("Can you browse the internet?", .capabilities),
            ("Can you open apps?", .capabilities),
            ("What are your capabilities?", .capabilities),
            ("Can you log in to my Linux VM?", .signInBoundary),
            ("Please sign into my account", .signInBoundary),
            ("Can you open my Linux VM?", .signInBoundary),
            ("How many steps did I take today?", .healthQuestion),
            ("How was my sleep last night?", .healthQuestion),
            ("Show me my workouts this week", .healthQuestion),
            ("What is my health summary?", .healthQuestion),
            ("What is 18 * 7?", .instantAnswer("18 * 7 is 126.")),
            ("Convert 5 km to miles", .instantAnswer("5 kilometers is 3.106855961 miles.")),
            ("Set a timer for 5 minutes", .startTimer(seconds: 300)),
            ("Can you set a timer for 5 minutes?", .startTimer(seconds: 300)),
            ("Anna, please start a timer for 1 hour", .startTimer(seconds: 3_600)),
            ("Timer for 30 seconds", .startTimer(seconds: 30)),
            ("Set a timer", .timerClarification),
            ("Start a timer for 2 days", .timerClarification),
            ("I feel tired after walking", .conversation),
            ("Hey Anna, how are you?", .conversation)
        ]

        for (message, expected) in cases {
            XCTAssertEqual(AnnaRequestRouter.route(message), expected, "Unexpected route for: \(message)")
        }
        if case .instantAnswer(let answer) = AnnaRequestRouter.route("What time is it?") {
            XCTAssertFalse(answer.isEmpty)
        } else {
            XCTFail("A direct current-time request should be handled locally")
        }
    }

    func testLocalAnswerRouterHandlesClearCalculationsAndUnitConversions() {
        XCTAssertEqual(AnnaLocalAnswerRouter.answer(for: "What is 2 + 2?"), "2 + 2 is 4.")
        XCTAssertEqual(AnnaLocalAnswerRouter.answer(for: "calculate 144 / 12"), "144 / 12 is 12.")
        XCTAssertEqual(AnnaLocalAnswerRouter.answer(for: "convert 5 km to miles"), "5 kilometers is 3.106855961 miles.")
        XCTAssertEqual(AnnaLocalAnswerRouter.answer(for: "convert 32 fahrenheit to celsius"), "32° Fahrenheit is 0 °C.")
        XCTAssertEqual(AnnaLocalAnswerRouter.answer(for: "What is 5 / 0?"), "Division by zero isn’t defined.")
        XCTAssertNil(AnnaLocalAnswerRouter.answer(for: "I have 2 apples and 2 oranges"))
    }

    func testSpeechChunkerKeepsSentencePunctuationAndDecimalNumbers() {
        XCTAssertEqual(
            AnnaSpeechChunker.sentenceChunks("You took 7.5 hours of sleep. Your steps look steady!"),
            ["You took 7.5 hours of sleep.", "Your steps look steady!"]
        )
        XCTAssertEqual(AnnaSpeechChunker.sentenceChunks("   "), [])
    }

    func testSpokenTextOmitsEmojiWithoutReadingTheirNames() {
        XCTAssertEqual(AnnaSpeechChunker.speechText("I’m happy 😊, really ❤️!"), "I’m happy, really!")
        XCTAssertEqual(AnnaSpeechChunker.speechText("I ran 5 km 🏃‍♀️ today."), "I ran 5 km today.")
        XCTAssertEqual(AnnaSpeechChunker.speechText("No em—dash, and no en–dash."), "No em-dash, and no en-dash.")
    }

    func testTapCreatesOneCoherentReactionPlanWithoutConsumingEnergy() {
        var core = CompanionCore()

        let events = core.handle(.tap, at: Date(timeIntervalSince1970: 100))

        XCTAssertEqual(core.state.interactionCount, 1)
        XCTAssertEqual(core.state.expression, .curious)
        XCTAssertEqual(core.state.mode, .engaged)
        XCTAssertEqual(core.state.energy, 3)
        XCTAssertEqual(events.first(where: { $0.kind == .reactionPlan })?.reactionPlan?.gesture, .bounce)
        XCTAssertEqual(events.first(where: { $0.kind == .haptic })?.haptic, .soft)
        XCTAssertEqual(events.first(where: { $0.kind == .reply })?.text, "A tiny sparkle, just for you.")
    }

    func testTiredInputGetsGentleDeterministicResponse() {
        var core = CompanionCore()

        let events = core.handle(.userInput("I feel tired"), at: Date(timeIntervalSince1970: 120))

        XCTAssertEqual(core.state.expression, .sleepy)
        XCTAssertEqual(events.first(where: { $0.kind == .reply })?.text, "We can slow things down. Want a quiet moment?")
        XCTAssertNil(events.first(where: { $0.kind == .haptic })?.haptic)
    }

    func testEmptyInputFallsBackToTap() {
        var core = CompanionCore()

        _ = core.handle(.userInput("   "), at: Date(timeIntervalSince1970: 140))

        XCTAssertEqual(core.state.interactionCount, 1)
        XCTAssertEqual(core.state.expression, .curious)
    }

    func testDismissReturnsToCalmIdleState() {
        var core = CompanionCore()
        _ = core.handle(.userInput("hello"))

        let events = core.handle(.dismiss)

        XCTAssertEqual(core.state.status, .idle)
        XCTAssertEqual(core.state.mode, .awakeIdle)
        XCTAssertEqual(core.state.expression, .calm)
        XCTAssertTrue(events.contains(where: { $0.kind == .mode }))
    }

    func testSleepRequiresDeliberateWakeAndRecoversEnergyGradually() {
        var core = CompanionCore(state: CompanionState(energy: 1))
        _ = core.handle(.rest)

        XCTAssertEqual(core.state.mode, .sleeping)
        _ = core.handle(.tick)
        XCTAssertEqual(core.state.energy, 2)
        _ = core.handle(.tap)
        XCTAssertEqual(core.state.mode, .sleeping)
        XCTAssertEqual(core.state.expression, .sleepy)

        _ = core.handle(.longPress)
        XCTAssertEqual(core.state.mode, .waking)
        XCTAssertEqual(core.state.expression, .happy)
    }

    func testVeryLowEnergyDoesNotLockInteractionOrForceSleep() {
        var core = CompanionCore(state: CompanionState(energy: 0))
        _ = core.handle(.tick)

        XCTAssertEqual(core.state.mode, .awakeIdle)
        _ = core.handle(.tap)
        XCTAssertEqual(core.state.interactionCount, 1)
        XCTAssertEqual(core.state.expression, .curious)
    }

    func testRecentResponsesAreNotRepeatedImmediately() {
        var core = CompanionCore()
        let first = core.handle(.userInput("hello")).first(where: { $0.kind == .reactionPlan })?.reactionPlan?.responseID
        let second = core.handle(.userInput("hello")).first(where: { $0.kind == .reactionPlan })?.reactionPlan?.responseID

        XCTAssertNotNil(first)
        XCTAssertNotNil(second)
        XCTAssertNotEqual(first, second)
    }

    func testAnnaAnswersHerNameWithoutLoadingTheLanguageModel() {
        let plan = DeterministicCompanionResponseProvider().response(
            for: "What's your name?",
            state: CompanionState()
        )

        XCTAssertEqual(plan.intent, .status)
        XCTAssertTrue(plan.spokenText.contains("Anna"))
    }

    func testAnnaAnswersSimpleArithmeticWithoutLoadingTheLanguageModel() {
        let plan = DeterministicCompanionResponseProvider().response(
            for: "What is 2 + 2?",
            state: CompanionState()
        )

        XCTAssertEqual(plan.intent, .answer)
        XCTAssertEqual(plan.spokenText, "2 + 2 is 4.")
    }

    func testRepeatedOrbTapsDoNotRepeatAGreetingInsideTheRecentWindow() {
        var core = CompanionCore()
        let lines = (0..<12).compactMap { _ in
            core.handle(.tap).first(where: { $0.kind == .reply })?.text
        }

        XCTAssertEqual(lines.count, 12)
        for endIndex in 8...lines.count {
            XCTAssertEqual(Set(lines[(endIndex - 8)..<endIndex]).count, 8)
        }
    }

    func testAcceptedModelReplyCountsAsAnInteraction() {
        var core = CompanionCore()
        let reply = CompanionReplyPlan(
            responseID: "test.model.reply",
            spokenText: "I’m Anna.",
            intent: .answer,
            emotion: .happy
        )

        _ = core.handle(.assistantReply(reply), at: Date(timeIntervalSince1970: 300))

        XCTAssertEqual(core.state.interactionCount, 1)
        XCTAssertEqual(core.state.lastMeaningfulInteraction, Date(timeIntervalSince1970: 300))
    }

    func testQuietModeSuppressesHapticButKeepsVisibleReaction() {
        var core = CompanionCore()
        _ = core.handle(.setQuietMode(true))

        let events = core.handle(.tap)

        XCTAssertTrue(core.state.quietMode)
        XCTAssertEqual(core.state.mode, .focusQuiet)
        XCTAssertTrue(events.contains(where: { $0.kind == .reply }))
        XCTAssertFalse(events.contains(where: { $0.kind == .haptic && $0.haptic != nil }))
    }

    func testHapticCooldownThrottlesRapidRepeatedInteractions() {
        var core = CompanionCore()
        let first = core.handle(.tap, at: Date(timeIntervalSince1970: 100))
        let second = core.handle(.tap, at: Date(timeIntervalSince1970: 101))

        XCTAssertTrue(first.contains(where: { $0.kind == .haptic && $0.haptic == .soft }))
        XCTAssertFalse(second.contains(where: { $0.kind == .haptic && $0.haptic != nil }))
    }

    func testModelProposalIsBoundedAndSeriousTopicsAreGentle() {
        let proposal = CompanionResponseValidator.proposal(
            from: String(repeating: "A thoughtful sentence. ", count: 30),
            inResponseTo: "I feel anxious about my health",
            state: CompanionState()
        )

        XCTAssertNotNil(proposal)
        XCTAssertLessThanOrEqual(proposal?.spokenText.count ?? 999, 420)
        XCTAssertEqual(proposal?.seriousness, .sensitive)
        XCTAssertEqual(proposal?.emotion, .concerned)
        XCTAssertNil(proposal?.haptic)
        XCTAssertNil(CompanionResponseValidator.proposal(from: "  ", inResponseTo: "hi", state: CompanionState()))
    }

    func testDisplayedReplyKeepsTheFullSpokenResponse() {
        let input = String(repeating: "A complete sentence for the user. ", count: 12)
        let proposal = CompanionResponseValidator.proposal(
            from: input,
            inResponseTo: "Tell me more",
            state: CompanionState()
        )

        XCTAssertNotNil(proposal)
        XCTAssertEqual(proposal?.displayText, proposal?.spokenText)
        XCTAssertLessThanOrEqual(proposal?.displayText?.count ?? 999, 420)
    }

    func testGeneratedCopyReplacesLongDashes() {
        let proposal = CompanionResponseValidator.proposal(
            from: "I can search that — give me a moment.",
            inResponseTo: "Search for this",
            state: CompanionState()
        )

        XCTAssertEqual(proposal?.spokenText, "I can search that - give me a moment.")
        XCTAssertFalse(proposal?.spokenText.contains("—") ?? true)
        XCTAssertFalse(proposal?.spokenText.contains("–") ?? true)
    }

    func testOldPersistedStateDecodesWithNewDefaults() throws {
        let data = #"{"mood":1,"energy":4,"interactionCount":2,"expression":"happy","status":"idle"}"#.data(using: .utf8)!

        let state = try JSONDecoder().decode(CompanionState.self, from: data)

        XCTAssertEqual(state.energy, 4)
        XCTAssertEqual(state.expression, .happy)
        XCTAssertEqual(state.mode, .awakeIdle)
        XCTAssertTrue(state.hapticsEnabled)
    }

    func testConversationCanRestoreOnlyItsRecentResponseIdentifiers() {
        var state = CompanionState()
        state.restoreRecentResponseIDs(["thread-a", "thread-b"])
        XCTAssertEqual(state.recentResponseIDs, ["thread-a", "thread-b"])

        state.restoreRecentResponseIDs((0..<12).map { String($0) })
        XCTAssertEqual(state.recentResponseIDs, (4..<12).map { String($0) })
    }
}
