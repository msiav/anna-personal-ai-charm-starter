import Foundation
import Combine
import WatchKit
import AVFoundation

private final class AnnaWatchSpeechOutputDelegate: NSObject, AVSpeechSynthesizerDelegate {
    var onSpeakingChanged: ((Bool) -> Void)?

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        onSpeakingChanged?(true)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        onSpeakingChanged?(synthesizer.isSpeaking)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        onSpeakingChanged?(false)
    }
}

@MainActor
private final class AnnaWatchAudioCapture {
    var onRecordingChanged: ((Bool, Bool) -> Void)?
    var onCompleted: ((URL?) -> Void)?
    var onError: ((String) -> Void)?

    private(set) var isPreparing = false
    private(set) var isRecording = false
    private var recorder: AVAudioRecorder?
    private var maximumDurationTask: Task<Void, Never>?
    private var quickTapTask: Task<Void, Never>?
    private var finishDelayAfterPermission: TimeInterval?
    private var cancelled = false
    private var interruptionObserver: NSObjectProtocol?

    init() {
        interruptionObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance(),
            queue: .main
        ) { [weak self] notification in
            guard let rawType = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  AVAudioSession.InterruptionType(rawValue: rawType) == .began else { return }
            Task { @MainActor [weak self] in self?.cancel() }
        }
    }

    deinit {
        if let interruptionObserver {
            NotificationCenter.default.removeObserver(interruptionObserver)
        }
    }

    func start(onCompleted: @escaping (URL?) -> Void) {
        guard !isPreparing, !isRecording else { return }
        cancelled = false
        isPreparing = true
        self.onCompleted = onCompleted
        onRecordingChanged?(false, true)

        switch AVAudioApplication.shared.recordPermission {
        case .granted:
            startRecorder()
        case .denied:
            fail("Microphone access is off. Allow Anna to use the microphone in Watch Settings.")
        case .undetermined:
            AVAudioApplication.requestRecordPermission { [weak self] isGranted in
                Task { @MainActor [weak self] in
                    guard let self, !self.cancelled else { return }
                    if isGranted {
                        self.startRecorder()
                    } else {
                        self.fail("Allow Anna to use the microphone on Apple Watch, then try Talk again.")
                    }
                }
            }
        @unknown default:
            fail("Anna couldn’t check the microphone permission. Please try again.")
        }
    }

    func finish(quickTap: Bool, stopWhenReady: Bool = false) {
        guard isPreparing || isRecording else { return }
        if isPreparing {
            finishDelayAfterPermission = stopWhenReady ? 0 : 5
            return
        }
        if quickTap {
            quickTapTask?.cancel()
            quickTapTask = Task { @MainActor [weak self] in
                try? await Task.sleep(for: .seconds(5))
                guard !Task.isCancelled else { return }
                self?.finishNow()
            }
        } else {
            finishNow()
        }
    }

    func cancel() {
        cancelled = true
        maximumDurationTask?.cancel()
        quickTapTask?.cancel()
        quickTapTask = nil
        let fileURL = recorder?.url
        recorder?.stop()
        recorder = nil
        isPreparing = false
        isRecording = false
        finishDelayAfterPermission = nil
        onCompleted = nil
        onRecordingChanged?(false, false)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        if let fileURL { try? FileManager.default.removeItem(at: fileURL) }
    }

    private func startRecorder() {
        guard !cancelled else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .default, options: [])
            try session.setActive(true)
            let fileURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("anna-watch-\(UUID().uuidString).m4a")
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 16_000,
                AVNumberOfChannelsKey: 1,
                AVEncoderBitRateKey: 32_000,
                AVEncoderAudioQualityKey: AVAudioQuality.low.rawValue
            ]
            let nextRecorder = try AVAudioRecorder(url: fileURL, settings: settings)
            guard nextRecorder.record() else {
                throw NSError(domain: "AnnaWatchAudioCapture", code: 1)
            }
            recorder = nextRecorder
            isPreparing = false
            isRecording = true
            onRecordingChanged?(true, false)
            maximumDurationTask = Task { @MainActor [weak self] in
                try? await Task.sleep(for: .seconds(20))
                guard !Task.isCancelled else { return }
                self?.finishNow()
            }
            if let finishDelayAfterPermission {
                self.finishDelayAfterPermission = nil
                quickTapTask = Task { @MainActor [weak self] in
                    try? await Task.sleep(for: .seconds(finishDelayAfterPermission))
                    guard !Task.isCancelled else { return }
                    self?.finishNow()
                }
            }
        } catch {
            fail("Anna couldn’t start recording. You can still type to her on your iPhone.")
        }
    }

    private func finishNow() {
        guard let recorder else { return }
        maximumDurationTask?.cancel()
        quickTapTask?.cancel()
        maximumDurationTask = nil
        quickTapTask = nil
        let fileURL = recorder.url
        recorder.stop()
        self.recorder = nil
        isRecording = false
        isPreparing = false
        onRecordingChanged?(false, false)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        let byteCount = (try? FileManager.default.attributesOfItem(atPath: fileURL.path)[.size] as? NSNumber)?.intValue ?? 0
        guard byteCount > 512 else {
            try? FileManager.default.removeItem(at: fileURL)
            onError?("Anna didn’t catch enough audio. Hold Talk and try once more.")
            onCompleted?(nil)
            onCompleted = nil
            return
        }
        onCompleted?(fileURL)
        onCompleted = nil
    }

    private func fail(_ message: String) {
        isPreparing = false
        isRecording = false
        onRecordingChanged?(false, false)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        onError?(message)
        onCompleted?(nil)
        onCompleted = nil
    }
}

struct AnnaWatchTurn: Identifiable, Codable, Equatable {
    enum Role: String, Codable {
        case anna
        case user
    }

    let id: UUID
    let role: Role
    let text: String

    init(id: UUID = UUID(), role: Role, text: String) {
        self.id = id
        self.role = role
        self.text = text
    }
}

@MainActor
final class CompanionViewModel: ObservableObject {
    @Published private(set) var state: CompanionState
    @Published private(set) var reply: String
    @Published private(set) var phoneReachable = false
    @Published private(set) var soundsEnabled = true
    @Published private(set) var recentTurns: [AnnaWatchTurn] = []
    @Published private(set) var isRecordingSpeech = false
    @Published private(set) var isPreparingSpeech = false
    @Published private(set) var isSpeakingReply = false
    @Published private(set) var speechWasStopped = false
    @Published private(set) var speechInputError: String?
    @Published private(set) var personalVoiceAvailable = false
    @Published private(set) var healthStepsToday: Int?
    @Published private(set) var dailyStepTarget: Int?
    @Published private(set) var healthUpdatedAt: Date?
    @Published private(set) var annaEditionNumber: String?
    @Published private(set) var focusEndsAt: Date?
    @Published private(set) var checkInDueAt: Date?
    @Published private(set) var checkInPending = false
    @Published private(set) var checkInStatus = ""
    @Published private(set) var personalityPackVersion: String?

    private var core: CompanionCore
    private let relay = AnnaWatchRelay()
    private let speechSynthesizer = AVSpeechSynthesizer()
    private let speechOutputDelegate = AnnaWatchSpeechOutputDelegate()
    private var personalVoiceIdentifier: String?
    private let soundEngine = AnnaSoundEngine()
    private let audioCapture = AnnaWatchAudioCapture()
    private let defaults = UserDefaults.standard
    private let stateKey = "museCharm.companionState.v1"
    private let replyKey = "museCharm.lastReply.v1"
    private var lastCrownHapticAt = Date.distantPast

    func stopTransientActivities() {
        audioCapture.cancel()
        speechSynthesizer.stopSpeaking(at: .immediate)
        isRecordingSpeech = false
        isPreparingSpeech = false
        isSpeakingReply = false
    }

    func confirmSafetyCheckIn() {
        guard checkInPending else { return }
        switch relay.acknowledgeSafetyCheckIn() {
        case .sent:
            checkInPending = false
            checkInStatus = "You’re okay. Anna sent that to your iPhone."
        case .queued:
            checkInPending = false
            checkInStatus = "You’re okay. It will sync when your iPhone wakes."
        case .unavailable:
            checkInStatus = "Anna can’t reach your iPhone right now. Open Anna on your iPhone to confirm."
        }
    }

    init() {
        let savedState: CompanionState?
        if let data = UserDefaults.standard.data(forKey: "museCharm.companionState.v1") {
            savedState = try? JSONDecoder().decode(CompanionState.self, from: data)
        } else {
            savedState = nil
        }

        let initialState = savedState ?? CompanionState()
        core = CompanionCore(state: initialState)
        state = initialState
        reply = UserDefaults.standard.string(forKey: "museCharm.lastReply.v1") ?? "Tap me when you need a tiny hello."
        soundsEnabled = defaults.object(forKey: "anna.soundsEnabled.v1") as? Bool ?? true
        speechOutputDelegate.onSpeakingChanged = { [weak self] speaking in
            Task { @MainActor [weak self] in self?.isSpeakingReply = speaking }
        }
        speechSynthesizer.delegate = speechOutputDelegate
        annaEditionNumber = defaults.string(forKey: "anna.edition.number.v1")
        recentTurns = defaults.data(forKey: "museCharm.recentTurns.v1")
            .flatMap { try? JSONDecoder().decode([AnnaWatchTurn].self, from: $0) } ?? []
        audioCapture.onRecordingChanged = { [weak self] recording, preparing in
            self?.isRecordingSpeech = recording
            self?.isPreparingSpeech = preparing
        }
        audioCapture.onError = { [weak self] message in
            self?.speechInputError = message
            self?.reply = message
            self?.persist()
        }
        relay.onReachabilityChanged = { [weak self] reachable in
            self?.phoneReachable = reachable
        }
        relay.onApplicationContextChanged = { [weak self] context in
            self?.applyPhoneContext(context)
        }
        relay.onRequestQueued = { [weak self] in
            self?.reply = "Sending when your iPhone wakes."
        }
        phoneReachable = relay.isReachable
        Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(450))
            guard let self else { return }
            self.soundEngine.play(.boot, enabled: self.soundsEnabled, quietMode: self.state.quietMode, intensity: 0.30)
        }
    }

    private func applyPhoneContext(_ context: [String: Any]) {
        guard context["type"] as? String == "anna.context",
              context["schemaVersion"] as? Int == 1 else { return }
        if let editionNumber = context["annaEditionNumber"] as? String,
           editionNumber.count == 15,
           editionNumber.allSatisfy(\.isNumber) {
            annaEditionNumber = editionNumber
            defaults.set(editionNumber, forKey: "anna.edition.number.v1")
        }
        if let timestamp = context["focusEndsAt"] as? TimeInterval, timestamp > 0 {
            focusEndsAt = Date(timeIntervalSince1970: timestamp)
        } else {
            focusEndsAt = nil
        }
        if let timestamp = context["checkInDueAt"] as? TimeInterval, timestamp > 0 {
            checkInDueAt = Date(timeIntervalSince1970: timestamp)
        } else {
            checkInDueAt = nil
        }
        checkInPending = context["checkInPending"] as? Bool ?? false
        if !checkInPending { checkInStatus = "" }
        personalityPackVersion = context["personalityPackVersion"] as? String
        if let data = context["companionState"] as? Data,
           let syncedState = try? JSONDecoder().decode(CompanionState.self, from: data) {
            state = syncedState
            core = CompanionCore(state: syncedState)
            if let encoded = try? JSONEncoder().encode(syncedState) {
                defaults.set(encoded, forKey: stateKey)
            }
        }
        if let syncedSoundsEnabled = context["soundsEnabled"] as? Bool {
            soundsEnabled = syncedSoundsEnabled
            defaults.set(syncedSoundsEnabled, forKey: "anna.soundsEnabled.v1")
        }
        let usePersonalVoice = context["personalVoiceEnabled"] as? Bool ?? false
        let voiceIdentifier = context["personalVoiceIdentifier"] as? String
        updatePersonalVoice(enabled: usePersonalVoice, identifier: voiceIdentifier)
        if let latestReply = context["lastReply"] as? String, !latestReply.isEmpty {
            reply = latestReply
            defaults.set(latestReply, forKey: replyKey)
        }
        if let rows = context["recentTurns"] as? [[String: String]] {
            recentTurns = rows.compactMap { row in
                guard let rawRole = row["role"], let role = AnnaWatchTurn.Role(rawValue: rawRole),
                      let text = row["text"], !text.isEmpty else { return nil }
                return AnnaWatchTurn(role: role, text: text)
            }
            persistTurns()
        }
        var snapshot = AnnaWidgetStateStore.read()
        snapshot.mode = state.mode.rawValue
        snapshot.expression = state.expression.rawValue
        snapshot.quiet = state.quietMode
        snapshot.stepsToday = context["healthStepsToday"] as? Int
        snapshot.dailyStepTarget = context["dailyStepTarget"] as? Int
        healthStepsToday = snapshot.stepsToday
        dailyStepTarget = snapshot.dailyStepTarget
        if let timestamp = context["healthUpdatedAt"] as? TimeInterval {
            healthUpdatedAt = Date(timeIntervalSince1970: timestamp)
        } else {
            healthUpdatedAt = nil
        }
        if let sleep = context["healthSleepHours"] as? Double, sleep >= 0 {
            snapshot.sleepHours = sleep
        } else {
            snapshot.sleepHours = nil
        }
        snapshot.workoutsThisWeek = context["healthWorkoutsThisWeek"] as? Int
        snapshot.updatedAt = Date()
        AnnaWidgetStateStore.write(snapshot)
    }

    func pet() {
        if isSpeakingReply {
            stopSpeechForUser()
            return
        }
        soundEngine.play(.tap, enabled: soundsEnabled, quietMode: state.quietMode)
        process(.tap)
    }

    func longPress() {
        if isSpeakingReply { stopSpeechForUser(); return }
        process(.longPress)
    }

    func doubleTap() {
        if isSpeakingReply { stopSpeechForUser(); return }
        process(.doubleTap)
    }

    func crownTurned() {
        crownTurned(amount: 1)
    }

    func crownTurned(amount: Double) {
        if isSpeakingReply {
            stopSpeechForUser()
            return
        }
        if state.hapticsEnabled && !state.quietMode {
            let now = Date()
            if now.timeIntervalSince(lastCrownHapticAt) >= 0.14 {
                lastCrownHapticAt = now
                WKInterfaceDevice.current().play(.click)
            }
        }
        soundEngine.play(.wind(amount), enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.14)
    }

    func crownSettled() {
        if state.hapticsEnabled && !state.quietMode {
            WKInterfaceDevice.current().play(.success)
        }
        soundEngine.play(.reply, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.25)
    }

    func startPushToTalk() {
        guard !isSpeakingReply else {
            stopSpeechForUser()
            return
        }
        speechWasStopped = false
        speechInputError = nil
        soundEngine.play(.listening, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.18)
        if state.hapticsEnabled && !state.quietMode { WKInterfaceDevice.current().play(.click) }
        audioCapture.start { [weak self] fileURL in
            guard let self, let fileURL else { return }
            self.sendVoiceNote(fileURL)
        }
    }

    func finishPushToTalk(quickTap: Bool = false, stopWhenReady: Bool = false) {
        audioCapture.finish(quickTap: quickTap, stopWhenReady: stopWhenReady)
    }

    func cancelPushToTalk() {
        audioCapture.cancel()
        if state.hapticsEnabled && !state.quietMode { WKInterfaceDevice.current().play(.click) }
    }

    func stopSpeechForUser() {
        guard speechSynthesizer.isSpeaking || isSpeakingReply else { return }
        speechWasStopped = true
        speechSynthesizer.stopSpeaking(at: .immediate)
        isSpeakingReply = false
        soundEngine.play(.listening, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.2)
        if state.hapticsEnabled && !state.quietMode { WKInterfaceDevice.current().play(.click) }
    }

    private func sendVoiceNote(_ fileURL: URL) {
        soundEngine.play(.sent, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.30)
        if state.hapticsEnabled && !state.quietMode { WKInterfaceDevice.current().play(.success) }
        let disposition = relay.sendAudioFile(fileURL) { [weak self] answer, shouldSpeak in
            self?.receivePhoneAnswer(answer, inResponseTo: "voice message", shouldSpeak: shouldSpeak)
        }
        switch disposition {
        case .queued:
            reply = "Sending your voice note to Anna’s iPhone."
        case .sent:
            reply = "Sending your voice note to Anna’s iPhone."
        case .unavailable:
            try? FileManager.default.removeItem(at: fileURL)
            reply = "Open Anna on your iPhone to send a voice note."
        }
        persist()
    }

    private func receivePhoneAnswer(_ answer: String, inResponseTo message: String, shouldSpeak: Bool) {
        let proposal = CompanionResponseValidator.proposal(
            from: answer,
            inResponseTo: message,
            state: core.state
        )
        let events = core.handle(.assistantReply(proposal ?? localFallback(for: message)))
        apply(events)
        reply = events.first(where: { $0.kind == .reply })?.text ?? answer
        if shouldSpeak { speak(proposal?.spokenText ?? reply) }
        persist()
    }

    func send(_ text: String) {
        let message = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !message.isEmpty else { return }
        appendTurn(.user, text: message)
        soundEngine.play(.sent, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.30)
        if state.hapticsEnabled && !state.quietMode { WKInterfaceDevice.current().play(.success) }

        let localPlan = DeterministicCompanionResponseProvider().response(for: message, state: core.state)
        if localPlan.intent != .clarify || isLocalCommand(message) {
            process(.userInput(message), speakReply: true)
            return
        }

        process(.beginListening)
        process(.beginThinking)
        reply = "Anna is thinking…"
        let disposition = relay.ask(message) { [weak self] answer, shouldSpeak in
            guard let self else { return }
            self.receivePhoneAnswer(answer, inResponseTo: message, shouldSpeak: shouldSpeak)
        }
        switch disposition {
        case .sent:
            persist()
            return
        case .queued:
            reply = "Sending when your iPhone wakes."
            persist()
            return
        case .unavailable:
            break
        }

        process(.userInput(message), speakReply: true)
        persist()
    }

    private func isLocalCommand(_ text: String) -> Bool {
        let normalized = text.lowercased()
        return ["time", "date", "sleep", "wake", "quiet mode", "focus mode", "cancel", "never mind"]
            .contains(where: normalized.contains)
    }

    func rest() {
        process(.rest)
        reply = "I’m settling in for a quiet rest."
        soundEngine.play(.sleep, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.22)
        persist()
    }

    func wake() {
        process(.wake, speakReply: true)
        soundEngine.play(.wake, enabled: soundsEnabled, quietMode: state.quietMode, intensity: 0.25)
    }

    func setQuietMode(_ enabled: Bool) {
        process(.setQuietMode(enabled))
        soundEngine.play(enabled ? .sleep : .wake, enabled: soundsEnabled, quietMode: enabled, intensity: 0.20)
        reply = enabled ? "Quiet mode is on. I’ll keep things calm." : "Quiet mode is off."
        persist()
    }

    private func process(_ command: CompanionCommand, speakReply: Bool = false) {
        let events = core.handle(command)
        apply(events, speakReply: speakReply)
    }

    private func apply(_ events: [CompanionEvent], speakReply: Bool = false) {
        state = core.state
        for event in events {
            if event.kind == .reply, let text = event.text {
                reply = text
                appendTurn(.anna, text: text)
                soundEngine.play(.reply, enabled: soundsEnabled, quietMode: state.quietMode, intensity: state.arousal)
                if speakReply {
                    speak(text)
                }
            }
            if event.kind == .haptic, let haptic = event.haptic {
                play(haptic)
            }
        }
        persist()
    }

    private func localFallback(for input: String) -> CompanionReplyPlan {
        DeterministicCompanionResponseProvider().response(for: input, state: core.state)
    }

    private func speak(_ text: String) {
        guard !state.quietMode else { return }
        speechSynthesizer.stopSpeaking(at: .immediate)
        let chunks = AnnaSpeechChunker.sentenceChunks(text)
        guard !chunks.isEmpty else { return }
        speechWasStopped = false
        isSpeakingReply = true
        let personalVoice = personalVoiceAvailable
            ? personalVoiceIdentifier.flatMap { AVSpeechSynthesisVoice(identifier: $0) }
            : nil
        let voice = personalVoice ?? AVSpeechSynthesisVoice(language: "en-CA")
            ?? AVSpeechSynthesisVoice(language: Locale.current.identifier)
        for chunk in chunks {
            let utterance = AVSpeechUtterance(string: chunk)
            utterance.voice = voice
            switch state.expression {
            case .sleepy, .tiredProud, .concerned:
                utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.9
                utterance.pitchMultiplier = 0.96
            case .excited, .happy, .proud:
                utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 1.04
                utterance.pitchMultiplier = 1.04
            default:
                utterance.rate = AVSpeechUtteranceDefaultSpeechRate
                utterance.pitchMultiplier = 1.0
            }
            utterance.volume = 0.9
            speechSynthesizer.speak(utterance)
        }
    }

    private func updatePersonalVoice(enabled: Bool, identifier: String?) {
        personalVoiceIdentifier = identifier
        guard enabled, identifier != nil else {
            personalVoiceAvailable = false
            return
        }
        guard #available(watchOS 10.0, *) else {
            personalVoiceAvailable = false
            return
        }

        switch AVSpeechSynthesizer.personalVoiceAuthorizationStatus {
        case .authorized:
            personalVoiceAvailable = AVSpeechSynthesisVoice.speechVoices().contains {
                $0.identifier == identifier && $0.voiceTraits.contains(.isPersonalVoice)
            }
        case .notDetermined:
            AVSpeechSynthesizer.requestPersonalVoiceAuthorization { [weak self] status in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.personalVoiceAvailable = status == .authorized
                        && AVSpeechSynthesisVoice.speechVoices().contains {
                            $0.identifier == identifier && $0.voiceTraits.contains(.isPersonalVoice)
                        }
                }
            }
        case .denied, .unsupported:
            personalVoiceAvailable = false
        @unknown default:
            personalVoiceAvailable = false
        }
    }

    private func play(_ haptic: CharmHaptic) {
        switch haptic {
        case .soft:
            WKInterfaceDevice.current().play(.click)
        case .double:
            WKInterfaceDevice.current().play(.click)
            Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(130))
                WKInterfaceDevice.current().play(.click)
            }
        case .success:
            WKInterfaceDevice.current().play(.success)
        case .warning:
            WKInterfaceDevice.current().play(.notification)
        }
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(state) {
            defaults.set(data, forKey: stateKey)
        }
        defaults.set(reply, forKey: replyKey)
        var snapshot = AnnaWidgetStateStore.read()
        snapshot.mode = state.mode.rawValue
        snapshot.expression = state.expression.rawValue
        snapshot.quiet = state.quietMode
        snapshot.updatedAt = Date()
        AnnaWidgetStateStore.write(snapshot)
        persistTurns()
    }

    private func appendTurn(_ role: AnnaWatchTurn.Role, text: String) {
        let normalized = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return }
        if let last = recentTurns.last, last.role == role,
           last.text.caseInsensitiveCompare(normalized) == .orderedSame { return }
        recentTurns.append(AnnaWatchTurn(role: role, text: normalized))
        if recentTurns.count > 20 { recentTurns.removeFirst(recentTurns.count - 20) }
        persistTurns()
    }

    private func persistTurns() {
        if let data = try? JSONEncoder().encode(recentTurns) {
            defaults.set(data, forKey: "museCharm.recentTurns.v1")
        }
    }
}
