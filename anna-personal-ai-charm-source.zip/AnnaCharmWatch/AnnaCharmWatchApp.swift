import SwiftUI

@main
struct AnnaCharmWatchApp: App {
    @StateObject private var companion = CompanionViewModel()

    var body: some Scene {
        WindowGroup {
            CompanionScreen(companion: companion)
        }
    }
}
