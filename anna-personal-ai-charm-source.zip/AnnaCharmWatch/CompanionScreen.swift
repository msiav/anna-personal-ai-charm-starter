import SwiftUI

struct CompanionScreen: View {
    @ObservedObject var companion: CompanionViewModel
    @State private var crownTurns = 0.0
    @State private var isHoldingTalk = false
    @State private var talkWasAlreadyRecording = false
    @State private var talkWasCancelled = false
    @State private var talkPressStartedAt: Date?
    @State private var crownStoppedSpeech = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        GeometryReader { geometry in
            let compact = geometry.size.height < 190
            let spacing = compact ? 2.0 : 4.0
            let orbSize = min(geometry.size.width * 0.46, max(48, geometry.size.height * 0.30))
            let replyHeight = max(28, geometry.size.height * 0.20)

            ZStack {
                RadialGradient(
                    colors: [Color(red: 0.36, green: 0.10, blue: 0.27), Color(red: 0.035, green: 0.025, blue: 0.075)],
                    center: .init(x: 0.5, y: 0.34),
                    startRadius: 4,
                    endRadius: geometry.size.height * 0.88
                )
                .ignoresSafeArea()

                VStack(spacing: spacing) {
                    header

                    AnnaOrbView(
                        expression: companion.isSpeakingReply ? .happy : (isHoldingTalk || companion.isRecordingSpeech || companion.isPreparingSpeech ? .listening : companion.state.expression),
                        showsFace: companion.isSpeakingReply || isHoldingTalk || companion.isRecordingSpeech || companion.isPreparingSpeech || companion.state.mode != .awakeIdle
                    )
                    .frame(width: orbSize, height: orbSize)
                    .rotationEffect(.degrees(reduceMotion ? 0 : crownTurns * 13))
                    .scaleEffect(reduceMotion ? 1 : 1 + min(abs(crownTurns) * 0.004, 0.045))
                    .animation(.spring(response: 0.24, dampingFraction: 0.72), value: crownTurns)
                    .contentShape(Circle())
                    .gesture(
                        ExclusiveGesture(
                            LongPressGesture(minimumDuration: 0.45),
                            TapGesture()
                        )
                        .onEnded { gesture in
                            switch gesture {
                            case .first(true): companion.longPress()
                            case .first(false): break
                            case .second(_): companion.pet()
                            }
                        }
                    )
                    .accessibilityAddTraits(.isButton)
                    .accessibilityLabel("Anna, your pink pixel companion")
                    .accessibilityHint(companion.isSpeakingReply
                        ? "Tap Anna or turn the Digital Crown to stop her speaking."
                        : "Tap to say hello. Touch and hold to wake or comfort Anna. Turn the Digital Crown to wind her up.")
                    .accessibilityAction { companion.pet() }
                    .accessibilityAction(named: Text("Comfort Anna")) { companion.longPress() }
                    .accessibilityAction(named: Text("Delight Anna")) { companion.doubleTap() }
                    .accessibilityAction(named: Text("Wind Anna")) {
                        if companion.isSpeakingReply {
                            companion.stopSpeechForUser()
                            return
                        }
                        let nextTurns = crownTurns == 0 ? 4.0 : 0.0
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.62)) {
                            crownTurns = nextTurns
                        }
                        companion.crownTurned(amount: nextTurns)
                        companion.crownSettled()
                    }

                    ScrollView(.vertical) {
                        Group {
                        if let focusEndsAt = companion.focusEndsAt {
                            Text("Focus until \(focusEndsAt.formatted(date: .omitted, time: .shortened))")
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(Color(red: 1, green: 0.72, blue: 0.82))
                        }
                        if companion.checkInPending, let checkInDueAt = companion.checkInDueAt {
                            Text("Check-in due \(checkInDueAt.formatted(date: .omitted, time: .shortened))")
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(Color(red: 1, green: 0.78, blue: 0.72))
                            Button("I’m okay") { companion.confirmSafetyCheckIn() }
                                .buttonStyle(.borderedProminent)
                        } else if !companion.checkInStatus.isEmpty {
                            Text(companion.checkInStatus)
                                .font(.caption2)
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        if companion.isSpeakingReply {
                            Text("Anna is speaking. Tap her or turn the Crown to stop.")
                                .font(.footnote.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        } else if let speechInputError = companion.speechInputError {
                            Text(speechInputError)
                                .font(.footnote.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        } else if isHoldingTalk {
                            Text("Let go to send your voice note.")
                                .font(.footnote.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        } else if companion.isPreparingSpeech {
                            Text("Waiting for microphone permission.")
                                .font(.footnote.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        } else if companion.isRecordingSpeech {
                            Text("Listening. Tap Talk to send, or Anna will send in a few seconds.")
                                .font(.footnote.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        } else if companion.recentTurns.isEmpty {
                            Text(companion.reply)
                                .font(.footnote.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        } else {
                            VStack(alignment: .leading, spacing: 4) {
                                ForEach(Array(companion.recentTurns.suffix(4))) { turn in
                                    Text(turn.text)
                                        .font(turn.role == .anna ? .footnote.weight(.medium) : .caption2)
                                        .multilineTextAlignment(turn.role == .anna ? .leading : .trailing)
                                        .fixedSize(horizontal: false, vertical: true)
                                        .foregroundStyle(turn.role == .anna ? .white.opacity(0.94) : Color(red: 1, green: 0.69, blue: 0.80))
                                        .frame(maxWidth: .infinity, alignment: turn.role == .anna ? .leading : .trailing)
                                        .accessibilityLabel("\(turn.role == .anna ? "Anna" : "You"): \(turn.text)")
                                }
                            }
                            .frame(maxWidth: .infinity)
                        }
                        if companion.speechWasStopped {
                            Text("Stopped. Hold Talk when you’re ready.")
                                .font(.caption2.weight(.medium))
                                .multilineTextAlignment(.center)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                        }
                        }
                        .padding(.horizontal, 4)
                        if let steps = companion.healthStepsToday {
                            let isCurrentDay = companion.healthUpdatedAt.map { Calendar.current.isDateInToday($0) } ?? false
                            let target = isCurrentDay ? companion.dailyStepTarget : nil
                            let title = isCurrentDay
                                ? "Steps today"
                                : "Steps saved \(companion.healthUpdatedAt?.formatted(date: .abbreviated, time: .omitted) ?? "earlier")"
                            let countText = target.map { "\(steps.formatted()) / \($0.formatted())" } ?? steps.formatted()
                            let percentText = target.flatMap { $0 > 0 ? Int(min(100, Double(steps) / Double($0) * 100).rounded()) : nil }
                                .map { " · \($0)%" } ?? ""
                            Text("\(title) · \(countText)\(percentText)")
                                .font(.system(size: 9, weight: .medium, design: .rounded).monospacedDigit())
                                .foregroundStyle(Color(red: 1, green: 0.72, blue: 0.82))
                                .lineLimit(1)
                                .minimumScaleFactor(0.75)
                                .frame(maxWidth: .infinity)
                                .accessibilityLabel("\(title): \(steps.formatted())\(target.map { ", against a goal of \($0.formatted())" } ?? "")")
                        }
                    }
                    .scrollIndicators(.hidden)
                    .frame(maxWidth: .infinity)
                    .frame(height: replyHeight)
                    .accessibilityLabel("Anna’s reply")

                    HStack(spacing: 6) {
                        Button {} label: {
                            Label(companion.isSpeakingReply ? "Stop Anna" : (companion.isRecordingSpeech ? "Listening" : "Talk"),
                                  systemImage: companion.isSpeakingReply ? "stop.fill" : (companion.isRecordingSpeech || isHoldingTalk ? "waveform" : "mic.fill"))
                                .font(.system(size: 11, weight: .semibold, design: .rounded))
                                .frame(maxWidth: .infinity)
                                .frame(minHeight: 44)
                        }
                        .tint(Color(red: 0.96, green: 0.37, blue: 0.66))
                        .simultaneousGesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    if !isHoldingTalk { beginMicrophonePress() }
                                    if !talkWasCancelled && isHoldingTalk && isOutsideTalkButton(value.location) {
                                        talkWasCancelled = true
                                        isHoldingTalk = false
                                        companion.cancelPushToTalk()
                                    }
                                }
                                .onEnded(finishMicrophonePress)
                        )
                        .accessibilityHint(companion.isSpeakingReply
                            ? "Stops Anna speaking. Tap her or turn the Digital Crown to stop too."
                            : "Press and hold to record, then let go to send. A quick tap listens briefly. Slide off the button to cancel.")

                        Button {
                            if companion.state.mode == .sleeping {
                                companion.wake()
                            } else {
                                companion.rest()
                            }
                        } label: {
                            Image(systemName: companion.state.mode == .sleeping ? "sun.max.fill" : "moon.zzz.fill")
                                .font(.system(size: 12, weight: .semibold))
                                .frame(minWidth: 44, minHeight: 44)
                        }
                        .tint(Color.white.opacity(0.17))
                        .accessibilityLabel(companion.state.mode == .sleeping ? "Wake Anna" : "Let Anna rest")
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.regular)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, compact ? 2 : 4)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .digitalCrownRotation(
            detent: $crownTurns,
            from: -8,
            through: 8,
            by: 0.25,
            sensitivity: .medium,
            isContinuous: false,
            isHapticFeedbackEnabled: companion.state.hapticsEnabled && !companion.state.quietMode,
            onChange: { _ in
                if companion.isSpeakingReply {
                    crownStoppedSpeech = true
                    companion.stopSpeechForUser()
                } else if !crownStoppedSpeech {
                    companion.crownTurned(amount: crownTurns)
                }
            },
            onIdle: {
                withAnimation(.spring(response: 0.48, dampingFraction: 0.72)) {
                    crownTurns = 0
                }
                if crownStoppedSpeech {
                    crownStoppedSpeech = false
                    return
                }
                companion.crownSettled()
            }
        )
        .onChange(of: scenePhase, initial: false) { _, phase in
            if phase == .background {
                companion.stopTransientActivities()
                isHoldingTalk = false
                talkWasAlreadyRecording = false
                talkWasCancelled = false
                talkPressStartedAt = nil
            }
        }
        .onDisappear { companion.stopTransientActivities() }
    }

    private var header: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(Color(red: 1.0, green: 0.46, blue: 0.70))
                .frame(width: 5, height: 5)
            Text(companion.isSpeakingReply ? "ANNA · SPEAKING" : (companion.state.mode == .sleeping ? "ANNA · RESTING" : "ANNA · LOCAL"))
                .font(.system(size: 8, weight: .bold, design: .rounded))
                .tracking(1.2)
                .foregroundStyle(.white.opacity(0.67))
                .lineLimit(1)
                .minimumScaleFactor(0.9)
            Spacer(minLength: 2)
            HStack(spacing: 2) {
                ForEach(0..<5, id: \.self) { index in
                    Capsule()
                        .fill(index < companion.state.energy ? Color(red: 1.0, green: 0.60, blue: 0.72) : Color.white.opacity(0.16))
                        .frame(width: 4, height: 8)
                }
            }
            .accessibilityLabel("Anna energy \(companion.state.energy) of 5")
            Circle()
                .fill(companion.phoneReachable ? Color.green : Color.white.opacity(0.28))
                .frame(width: 5, height: 5)
                .accessibilityLabel(companion.phoneReachable ? "iPhone reachable" : "iPhone may be asleep")
        }
        .frame(height: 14)
    }

    private func beginMicrophonePress() {
        guard !isHoldingTalk else { return }
        if companion.isSpeakingReply {
            companion.stopSpeechForUser()
            talkWasCancelled = true
            return
        }
        talkWasCancelled = false
        talkWasAlreadyRecording = companion.isRecordingSpeech || companion.isPreparingSpeech
        talkPressStartedAt = Date()
        isHoldingTalk = true
        if !talkWasAlreadyRecording { companion.startPushToTalk() }
    }

    private func finishMicrophonePress(_ value: DragGesture.Value) {
        if talkWasCancelled {
            talkWasCancelled = false
            return
        }
        guard isHoldingTalk else { return }
        isHoldingTalk = false
        let startedAt = talkPressStartedAt ?? Date()
        talkPressStartedAt = nil
        if isOutsideTalkButton(value.location) {
            companion.cancelPushToTalk()
        } else {
            let isQuickTap = !talkWasAlreadyRecording && Date().timeIntervalSince(startedAt) < 0.22
            companion.finishPushToTalk(quickTap: isQuickTap, stopWhenReady: talkWasAlreadyRecording)
        }
        talkWasAlreadyRecording = false
    }

    private func isOutsideTalkButton(_ point: CGPoint) -> Bool {
        point.x < -16 || point.x > 140 || point.y < -16 || point.y > 62
    }
}
