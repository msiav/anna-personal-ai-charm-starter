import Foundation
import WatchConnectivity

enum AnnaWatchRequestDisposition {
    case sent
    case queued
    case unavailable
}

@MainActor
final class AnnaWatchRelay {
    var onReachabilityChanged: ((Bool) -> Void)?
    var onApplicationContextChanged: (([String: Any]) -> Void)?
    var onRequestQueued: (() -> Void)?

    private let session: WCSession
    private let delegate: AnnaWatchSessionDelegate
    private var pendingReplies: [String: (String, Bool) -> Void] = [:]
    private var pendingAudioFiles: [String: URL] = [:]

    var isReachable: Bool {
        session.activationState == .activated
            && session.isCompanionAppInstalled
            && session.isReachable
    }

    init() {
        session = WCSession.default
        delegate = AnnaWatchSessionDelegate()
        delegate.onReachabilityChanged = { [weak self] reachable in
            Task { @MainActor [weak self] in
                self?.onReachabilityChanged?(reachable)
            }
        }
        delegate.onApplicationContextChanged = { [weak self] context in
            Task { @MainActor [weak self] in
                self?.onApplicationContextChanged?(context)
            }
        }
        delegate.onUserInfoReceived = { [weak self] userInfo in
            Task { @MainActor [weak self] in
                guard let self, let requestID = userInfo["requestID"] as? String else { return }
                self.deliver(userInfo, requestID: requestID)
            }
        }
        delegate.onFileTransferFinished = { [weak self] metadata, error in
            Task { @MainActor [weak self] in
                guard let self, let requestID = metadata["requestID"] as? String else { return }
                if let fileURL = self.pendingAudioFiles.removeValue(forKey: requestID) {
                    try? FileManager.default.removeItem(at: fileURL)
                }
                if error != nil {
                    self.deliver(["error": "Anna couldn’t send that voice note. Please try again."], requestID: requestID)
                }
            }
        }
        if WCSession.isSupported() {
            session.delegate = delegate
            session.activate()
        }
    }

    @discardableResult
    func ask(_ text: String, completion: @escaping (String, Bool) -> Void) -> AnnaWatchRequestDisposition {
        let requestID = UUID().uuidString
        pendingReplies[requestID] = completion
        let payload: [String: Any] = [
            "schemaVersion": 1,
            "type": "anna.request",
            "requestID": requestID,
            "text": text
        ]

        guard isReachable else {
            return queue(payload, requestID: requestID) ? .queued : .unavailable
        }

        session.sendMessage(
            payload,
            replyHandler: { response in
                Task { @MainActor [weak self] in self?.deliver(response, requestID: requestID) }
            },
            errorHandler: { [weak self] _ in
                Task { @MainActor [weak self] in
                    guard let self, self.pendingReplies[requestID] != nil else { return }
                    if !self.queue(payload, requestID: requestID) {
                        self.deliver(["error": "Anna couldn’t reach your iPhone. Open the Anna app on it and try again."], requestID: requestID)
                    }
                }
            }
        )
        return .sent
    }

    func sendAudioFile(_ fileURL: URL, completion: @escaping (String, Bool) -> Void) -> AnnaWatchRequestDisposition {
        guard session.activationState == .activated, session.isCompanionAppInstalled else { return .unavailable }
        let requestID = UUID().uuidString
        pendingReplies[requestID] = completion
        pendingAudioFiles[requestID] = fileURL
        let metadata: [String: Any] = [
            "schemaVersion": 1,
            "type": "anna.audio",
            "requestID": requestID
        ]
        session.transferFile(fileURL, metadata: metadata)
        onRequestQueued?()
        return .queued
    }

    func acknowledgeSafetyCheckIn() -> AnnaWatchRequestDisposition {
        guard session.activationState == .activated, session.isCompanionAppInstalled else {
            return .unavailable
        }
        let payload: [String: Any] = [
            "schemaVersion": 1,
            "type": "anna.safety.ack"
        ]
        guard session.isReachable else {
            var queuedPayload = payload
            queuedPayload["type"] = "anna.safety.ack.queued"
            session.transferUserInfo(queuedPayload)
            onRequestQueued?()
            return .queued
        }
        session.sendMessage(payload, replyHandler: nil) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor [weak self] in
                guard let self else { return }
                var queuedPayload = payload
                queuedPayload["type"] = "anna.safety.ack.queued"
                self.session.transferUserInfo(queuedPayload)
                self.onRequestQueued?()
            }
        }
        return .sent
    }

    private func queue(_ payload: [String: Any], requestID: String) -> Bool {
        guard pendingReplies[requestID] != nil,
              session.activationState == .activated,
              session.isCompanionAppInstalled else { return false }
        var queuedPayload = payload
        queuedPayload["type"] = "anna.queuedRequest"
        session.transferUserInfo(queuedPayload)
        onRequestQueued?()
        return true
    }

    private func deliver(_ response: [String: Any], requestID: String) {
        guard let completion = pendingReplies.removeValue(forKey: requestID) else { return }
        let answer = (response["text"] as? String)
            ?? (response["error"] as? String)
            ?? "Anna couldn’t reply just now."
        completion(answer, response["speak"] as? Bool ?? true)
    }
}

private final class AnnaWatchSessionDelegate: NSObject, WCSessionDelegate {
    var onReachabilityChanged: ((Bool) -> Void)?
    var onApplicationContextChanged: (([String: Any]) -> Void)?
    var onUserInfoReceived: (([String: Any]) -> Void)?
    var onFileTransferFinished: (([String: Any], Error?) -> Void)?

    func session(
        _ session: WCSession,
        activationDidCompleteWith activationState: WCSessionActivationState,
        error: Error?
    ) {
        onReachabilityChanged?(session.isReachable && session.isCompanionAppInstalled)
        onApplicationContextChanged?(session.receivedApplicationContext)
    }

    func sessionCompanionAppInstalledDidChange(_ session: WCSession) {
        onReachabilityChanged?(session.isReachable && session.isCompanionAppInstalled)
    }

    func sessionReachabilityDidChange(_ session: WCSession) {
        onReachabilityChanged?(session.isReachable && session.isCompanionAppInstalled)
    }

    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        onApplicationContextChanged?(applicationContext)
    }

    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any] = [:]) {
        if userInfo["type"] as? String == "anna.queuedReply" {
            onUserInfoReceived?(userInfo)
        }
    }

    func session(_ session: WCSession, didFinish fileTransfer: WCSessionFileTransfer, error: Error?) {
        onFileTransferFinished?(fileTransfer.file.metadata ?? [:], error)
    }
}
