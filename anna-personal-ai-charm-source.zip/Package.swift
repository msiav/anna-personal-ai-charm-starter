// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "MuseCharmCore",
    platforms: [
        .iOS(.v16),
        .watchOS(.v9),
        .macOS(.v13)
    ],
    products: [
        .library(name: "MuseCharmCore", targets: ["MuseCharmCore"])
    ],
    targets: [
        .target(name: "MuseCharmCore"),
        .testTarget(name: "MuseCharmCoreTests", dependencies: ["MuseCharmCore"])
    ]
)
