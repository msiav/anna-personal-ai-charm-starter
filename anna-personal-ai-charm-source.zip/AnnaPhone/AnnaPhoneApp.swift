import SwiftUI
import UIKit
import EventKit
import UserNotifications

final class AnnaAppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let done = UNNotificationAction(identifier: "ANNA_REMINDER_DONE", title: "Mark Done", options: [])
        let snooze = UNNotificationAction(identifier: "ANNA_REMINDER_SNOOZE", title: "Snooze 1 Hour", options: [])
        let category = UNNotificationCategory(
            identifier: "ANNA_REMINDER_FOLLOW_UP",
            actions: [done, snooze],
            intentIdentifiers: [],
            options: []
        )
        let checkInAcknowledged = UNNotificationAction(
            identifier: "ANNA_SAFETY_CHECKIN_ACK",
            title: "I’m okay",
            options: []
        )
        let checkInCategory = UNNotificationCategory(
            identifier: "ANNA_SAFETY_CHECKIN",
            actions: [checkInAcknowledged],
            intentIdentifiers: [],
            options: []
        )
        let endFocus = UNNotificationAction(
            identifier: "ANNA_FOCUS_END",
            title: "End focus",
            options: []
        )
        let focusCategory = UNNotificationCategory(
            identifier: "ANNA_FOCUS_SESSION",
            actions: [endFocus],
            intentIdentifiers: [],
            options: []
        )
        UNUserNotificationCenter.current().setNotificationCategories([category, checkInCategory, focusCategory])
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    func application(
        _ application: UIApplication,
        handleEventsForBackgroundURLSession identifier: String,
        completionHandler: @escaping () -> Void
    ) {
        guard identifier == AnnaResumableDownloader.backgroundIdentifier else {
            completionHandler()
            return
        }
        _ = AnnaResumableDownloader.shared
        AnnaResumableDownloader.backgroundEventsCompletionHandler = completionHandler
    }
}

extension AnnaAppDelegate: UNUserNotificationCenterDelegate {
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        let info = response.notification.request.content.userInfo
        if response.actionIdentifier == "ANNA_SAFETY_CHECKIN_ACK",
           let checkInID = info["checkInID"] as? String {
            let group = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier)
            group?.set(true, forKey: "anna.safety.pendingAcknowledgement.v1")
            center.removePendingNotificationRequests(withIdentifiers: [
                "anna.safety.\(checkInID).due",
                "anna.safety.\(checkInID).escalation"
            ])
        } else if response.actionIdentifier == "ANNA_FOCUS_END" {
            UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier)?.set(
                true,
                forKey: "anna.focus.pendingEnd.v1"
            )
        } else if response.actionIdentifier == "ANNA_REMINDER_DONE",
           let identifier = info["reminderIdentifier"] as? String {
            markReminderComplete(identifier: identifier)
        } else if response.actionIdentifier == "ANNA_REMINDER_SNOOZE" {
            let content = response.notification.request.content.mutableCopy() as? UNMutableNotificationContent
            if let content {
                let snoozed = UNNotificationRequest(
                    identifier: "\(response.notification.request.identifier).snooze.\(UUID().uuidString)",
                    content: content,
                    trigger: UNTimeIntervalNotificationTrigger(timeInterval: 60 * 60, repeats: false)
                )
                center.add(snoozed) { _ in }
            }
        } else if let kind = info["annaBriefingKind"] as? String {
            UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier)?.set(
                kind,
                forKey: "anna.notification.pendingBriefing.v1"
            )
        } else if response.actionIdentifier == UNNotificationDefaultActionIdentifier,
                  info["annaDestination"] as? String == "windDown" {
            UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier)?.set(
                true,
                forKey: "anna.windDown.pendingStart.v1"
            )
        } else if response.actionIdentifier == UNNotificationDefaultActionIdentifier,
                  info["annaDestination"] as? String == "reminder",
                  let title = info["reminderTitle"] as? String {
            UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier)?.set(
                String(title.prefix(120)),
                forKey: AnnaShortcutSharedState.pendingNotificationReminderKey
            )
        }
        completionHandler()
    }

    private func markReminderComplete(identifier: String) {
        let store = EKEventStore()
        let status = EKEventStore.authorizationStatus(for: .reminder)
        let hasAccess: Bool
        if #available(iOS 17.0, *) { hasAccess = status == .fullAccess }
        else { hasAccess = status == .authorized }
        guard hasAccess,
              let reminder = store.calendarItem(withIdentifier: identifier) as? EKReminder else { return }
        reminder.isCompleted = true
        reminder.completionDate = Date()
        try? store.save(reminder, commit: true)
    }
}

@main
struct AnnaPhoneApp: App {
    @UIApplicationDelegateAdaptor(AnnaAppDelegate.self) private var appDelegate
    @StateObject private var companion = AnnaPhoneViewModel()

    var body: some Scene {
        WindowGroup {
            AnnaPhoneScreen(companion: companion)
        }
    }
}
