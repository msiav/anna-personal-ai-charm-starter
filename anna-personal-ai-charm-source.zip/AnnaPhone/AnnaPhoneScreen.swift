import SwiftUI
import UIKit
import CoreMotion
import SafariServices
import PhotosUI

private struct AnnaChatViewportHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

private struct AnnaPresentedWebPage: Identifiable {
    let id = UUID()
    let url: URL
}

@MainActor
private final class AnnaShakeObserver: ObservableObject {
    private let manager = CMMotionManager()
    private var lastShake = Date.distantPast

    func start(onShake: @escaping () -> Void) {
        guard manager.isAccelerometerAvailable, !manager.isAccelerometerActive else { return }
        manager.accelerometerUpdateInterval = 0.18
        manager.startAccelerometerUpdates(to: .main) { [weak self] sample, _ in
            guard let self, let sample else { return }
            let acceleration = sample.acceleration
            let magnitude = sqrt(acceleration.x * acceleration.x + acceleration.y * acceleration.y + acceleration.z * acceleration.z)
            guard magnitude > 2.25, Date().timeIntervalSince(self.lastShake) > 8 else { return }
            self.lastShake = Date()
            onShake()
        }
    }

    func stop() { manager.stopAccelerometerUpdates() }
}

struct AnnaPhoneScreen: View {
    @ObservedObject var companion: AnnaPhoneViewModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var speechCapture = AnnaSpeechCapture()
    @StateObject private var shakeObserver = AnnaShakeObserver()
    @FocusState private var inputFocused: Bool
    @State private var showingWatchHelp = false
    @State private var showingConversationDrawer = false
    @State private var showingSettings = false
    @State private var showingOpenLoops = false
    @State private var shareCardImage: UIImage?
    @State private var showingWebSearch = false
    @State private var openedWebPage: AnnaPresentedWebPage?
    @State private var webSearchInitialQuery = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var editingMessageID: UUID?
    @State private var editingMessageText = ""
    @State private var showingMessageEditor = false
    @State private var microphonePressStartedAt: Date?
    @State private var microphoneWasRecordingAtPressStart = false
    @State private var microphoneWasCancelled = false
    @State private var captureUsesTapToStop = false
    @State private var rootHasAppeared = false
    @State private var pendingOrbTap: Task<Void, Never>?
    @State private var orbDragStartedAt: Date?
    @State private var orbPettingActive = false
    @State private var orbDragOffset = CGSize.zero
    @State private var chatPinnedToBottom = true
    @State private var userHasMovedChatAway = false
    @State private var unseenMessageCount = 0
    @State private var hasUnseenStreamingContent = false
    @State private var chatViewportHeight: CGFloat = 0
    @State private var observedMessageCount = 0
    @State private var continuousTalkActive = false
    @State private var showingImmersiveVoice = false
    @State private var continuousReplyPending = false
    @State private var continuousRestartTask: Task<Void, Never>?
    @State private var continuousIdleTask: Task<Void, Never>?
    @State private var bargeInCaptureActive = false
    @State private var bargeInTriggered = false
    @State private var consecutiveVoiceMisses = 0
    @State private var ignoreNextEmptyVoiceResult = false
    @State private var thinkingBudgetTask: Task<Void, Never>?
    @State private var thinkingBudgetExceeded = false
    @State private var customStepGoal = ""
    @State private var recurringGoalTitle = ""
    @State private var recurringGoalCadence: AnnaRecurringCadence = .daily

    private let chatBottomAnchor = "anna-chat-bottom"

    private var selectedModel: AnnaModelOption? { companion.selectedModel }

    private var developerBargeInEnabled: Bool {
#if DEBUG
        ProcessInfo.processInfo.arguments.contains("--anna-enable-voice-barge-in")
#else
        false
#endif
    }

    var body: some View {
        GeometryReader { geometry in
            let compact = geometry.size.height < 700
            let horizontalPadding = min(22, max(16, geometry.size.width * 0.055))
            let characterSize = min(176, max(118, min(geometry.size.width * 0.46, geometry.size.height * 0.25)))

            ZStack {
                background.ignoresSafeArea()

                VStack(spacing: 0) {
                    VStack(spacing: compact ? 5 : 8) {
                        header
                        if companion.shouldUseCompactHeader {
                            compactContactHeader
                        } else {
                            hero(characterSize: characterSize, compact: compact)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, horizontalPadding)
                    .padding(.top, compact ? 4 : 10)
                    .padding(.bottom, compact ? 8 : 12)

                    ScrollViewReader { proxy in
                        ScrollView {
                                VStack(spacing: 14) {
                                    if !companion.isSelectedModelReady && !companion.isRestoringModel { modelCard }
                                    conversation
                                        Color.clear
                                            .frame(height: 1)
                                            .id(chatBottomAnchor)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.horizontal, horizontalPadding)
                                .padding(.top, 4)
                                .padding(.bottom, 18)
                            }
                            .coordinateSpace(name: "anna-chat-viewport")
                            .background(GeometryReader { viewport in
                                Color.clear.preference(key: AnnaChatViewportHeightPreferenceKey.self, value: viewport.size.height)
                            })
                            .scrollIndicators(.hidden)
                            .scrollDismissesKeyboard(.interactively)
                            .onAppear {
                                observedMessageCount = companion.messages.count
                                DispatchQueue.main.async {
                                    proxy.scrollTo(chatBottomAnchor, anchor: .bottom)
                                }
                            }
                            .onChange(of: companion.messages.count) { newCount in
                                let addedCount = max(0, newCount - observedMessageCount)
                                observedMessageCount = newCount
                                if chatPinnedToBottom {
                                    withAnimation(reduceMotion ? .none : .easeOut(duration: 0.18)) {
                                        proxy.scrollTo(chatBottomAnchor, anchor: .bottom)
                                    }
                                } else if addedCount > 0 {
                                    unseenMessageCount += addedCount
                                }
                            }
                            .onChange(of: companion.messages.last?.text) { _ in
                                if chatPinnedToBottom {
                                    proxy.scrollTo(chatBottomAnchor, anchor: .bottom)
                                }
                            }
            .onChange(of: companion.streamingReply) { _ in
                                if chatPinnedToBottom {
                                    proxy.scrollTo(chatBottomAnchor, anchor: .bottom)
                                } else if !companion.streamingReply.isEmpty {
                                    hasUnseenStreamingContent = true
                                }
                            }
                            .onChange(of: companion.activeConversationID) { _ in
                                chatPinnedToBottom = true
                                userHasMovedChatAway = false
                                unseenMessageCount = 0
                                hasUnseenStreamingContent = false
                                observedMessageCount = companion.messages.count
                                DispatchQueue.main.async {
                                    proxy.scrollTo(chatBottomAnchor, anchor: .bottom)
                                }
                            }
                            .onChange(of: companion.pendingRecallMessageID) { messageID in
                                guard let messageID else { return }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
                                    proxy.scrollTo(messageID, anchor: .center)
                                    companion.clearPendingRecallNavigation()
                                }
                            }
                            .onChange(of: chatViewportHeight) { _ in
                                if chatPinnedToBottom {
                                    DispatchQueue.main.async { proxy.scrollTo(chatBottomAnchor, anchor: .bottom) }
                                }
                            }
                            .onPreferenceChange(AnnaChatViewportHeightPreferenceKey.self) { chatViewportHeight = $0 }
                            .onScrollPhaseChange { _, phase in
                                if phase == .interacting { userHasMovedChatAway = true }
                            }
                            .onScrollGeometryChange(for: CGFloat.self) { geometry in
                                max(0, geometry.contentSize.height - geometry.visibleRect.maxY)
                            } action: { _, distanceFromBottom in
                                if distanceFromBottom <= 40 {
                                    chatPinnedToBottom = true
                                    userHasMovedChatAway = false
                                    unseenMessageCount = 0
                                    hasUnseenStreamingContent = false
                                } else if distanceFromBottom > 80 && userHasMovedChatAway {
                                    chatPinnedToBottom = false
                                }
                            }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .safeAreaInset(edge: .bottom, spacing: 0) {
                            if !chatPinnedToBottom && (unseenMessageCount > 0 || hasUnseenStreamingContent) {
                                HStack {
                                    Spacer(minLength: 0)
                                    Button {
                                        chatPinnedToBottom = true
                                        userHasMovedChatAway = false
                                        unseenMessageCount = 0
                                        hasUnseenStreamingContent = false
                                        withAnimation(reduceMotion ? .none : .easeOut(duration: 0.2)) {
                                            proxy.scrollTo(chatBottomAnchor, anchor: .bottom)
                                        }
                                    } label: {
                                        Label("Latest", systemImage: "arrow.down")
                                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                                            .padding(.horizontal, 13)
                                            .padding(.vertical, 9)
                                            .background(Color(red: 0.19, green: 0.34, blue: 0.52), in: Capsule())
                                    }
                                    .buttonStyle(.plain)
                                    .foregroundStyle(.white)
                                    .padding(.trailing, horizontalPadding + 6)
                                    .padding(.vertical, 7)
                                    .accessibilityLabel("Jump to latest message")
                                }
                                .frame(maxWidth: .infinity)
                                .background(Color(red: 0.035, green: 0.045, blue: 0.09).opacity(0.98))
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                composer
                    .padding(.horizontal, horizontalPadding)
                    .padding(.top, 8)
                    .padding(.bottom, 7)
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 0.035, green: 0.045, blue: 0.09).opacity(0.98))
            }
            .overlay(alignment: .leading) {
                if showingConversationDrawer {
                    ZStack(alignment: .leading) {
                        Color.black.opacity(0.58)
                            .ignoresSafeArea()
                            .contentShape(Rectangle())
                            .onTapGesture { closeConversationDrawer() }
                            .accessibilityLabel("Close conversations menu")

                        AnnaConversationDrawer(
                            conversations: companion.conversations,
                            activeConversationID: companion.activeConversationID,
                            openLoopCount: companion.openLoops.count,
                            onSelect: { id in
                                companion.selectConversation(id)
                                closeConversationDrawer()
                            },
                            onNewConversation: {
                                companion.startNewConversation()
                                closeConversationDrawer()
                            },
                            onRename: companion.renameConversation,
                            onDelete: companion.deleteConversation,
                            onSettings: {
                                closeConversationDrawer()
                                showingSettings = true
                            },
                            onOpenLoops: {
                                closeConversationDrawer()
                                showingOpenLoops = true
                            }
                        )
                        .frame(width: min(340, max(280, geometry.size.width * 0.84)))
                        .transition(.move(edge: .leading))
                    }
                    .zIndex(2)
                    .accessibilityAddTraits(.isModal)
                }
            }
            .animation(
                reduceMotion ? .easeOut(duration: 0.16) : .spring(response: 0.34, dampingFraction: 0.88),
                value: showingConversationDrawer
            )
            .fullScreenCover(isPresented: Binding(
                get: { !companion.hasCompletedOnboarding },
                set: { if !$0 { companion.hasCompletedOnboarding = true } }
            )) {
                AnnaWelcomeFlow(companion: companion, speechCapture: speechCapture)
            }
            .fullScreenCover(isPresented: $showingImmersiveVoice, onDismiss: {
                if continuousTalkActive { stopContinuousVoice(discardRecording: true) }
            }) {
                AnnaImmersiveVoiceScreen(
                    companion: companion,
                    speechCapture: speechCapture,
                    isActive: continuousTalkActive,
                    thinkingBudgetExceeded: thinkingBudgetExceeded,
                    onStart: startContinuousCapture,
                    onStopSpeaking: stopAnnaSpeakingAndResumeListening,
                    onDone: {
                        stopContinuousVoice(discardRecording: true)
                        showingImmersiveVoice = false
                    }
                )
            }
            .sheet(isPresented: $showingSettings) {
                AnnaSettingsSheet(
                    companion: companion,
                    speechCapture: speechCapture,
                    onStartVoice: {
                        consecutiveVoiceMisses = 0
                        companion.continuousVoiceEnabled = true
                        continuousTalkActive = true
                        showingImmersiveVoice = true
                    }
                )
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
            .sheet(isPresented: $showingOpenLoops) {
                AnnaOpenLoopsSheet(companion: companion)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
            .sheet(isPresented: Binding(
                get: { shareCardImage != nil },
                set: { if !$0 { shareCardImage = nil } }
            )) {
                if let shareCardImage {
                    AnnaShareCardPreview(image: shareCardImage)
                        .presentationDetents([.medium, .large])
                        .presentationDragIndicator(.visible)
                }
            }
            .sheet(isPresented: $showingMessageEditor) {
                NavigationStack {
                    TextEditor(text: $editingMessageText)
                        .padding(16)
                        .scrollContentBackground(.hidden)
                        .background(Color(red: 0.035, green: 0.045, blue: 0.09))
                        .foregroundStyle(.white)
                        .navigationTitle("Edit message")
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) {
                                Button("Cancel") { showingMessageEditor = false }
                            }
                            ToolbarItem(placement: .confirmationAction) {
                                Button("Save and resend") {
                                    if let editingMessageID {
                                        companion.editAndResendMessage(editingMessageID, replacement: editingMessageText)
                                    }
                                    showingMessageEditor = false
                                }
                                .disabled(editingMessageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            }
                        }
                }
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
            }
            .alert(
                showingWatchHelp ? "Connect Anna on Apple Watch" : (companion.isSearchConsentRequested ? "Web search privacy" : "Anna"),
                isPresented: Binding(
                    get: { showingWatchHelp || companion.isSearchConsentRequested || companion.errorMessage != nil || speechCapture.errorMessage != nil },
                    set: {
                        if !$0 {
                            showingWatchHelp = false
                            if companion.isSearchConsentRequested { companion.declineSearchConsent() }
                            companion.dismissError()
                            speechCapture.dismissError()
                        }
                    }
                )
            ) {
                if companion.isSearchConsentRequested {
                    Button("Search") { companion.acceptSearchConsent() }
                    Button("Not now", role: .cancel) { companion.declineSearchConsent() }
                } else {
                    Button("OK", role: .cancel) {
                        showingWatchHelp = false
                        companion.dismissError()
                    }
                }
            } message: {
                Text(companion.isSearchConsentRequested
                    ? companion.searchConsentMessage
                    : (showingWatchHelp
                        ? watchHelpText
                        : (companion.errorMessage ?? speechCapture.errorMessage ?? "Something went wrong.")))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(background.ignoresSafeArea())
        .opacity(rootHasAppeared ? 1 : 0)
        .onAppear {
            companion.applyPendingShortcutActions()
            companion.refreshTimeSensitiveModes()
            speechCapture.refreshPermissionStatus()
            shakeObserver.start { companion.shakeOrb() }
            withAnimation(reduceMotion ? .easeOut(duration: 0.12) : .easeOut(duration: 0.24)) {
                rootHasAppeared = true
            }
        }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active else { return }
            companion.refreshTimeSensitiveModes()
            Task { await companion.checkForBrainUpdates() }
            Task { await companion.synchronizeICloudNow() }
        }
        .onChange(of: speechCapture.transcript) { _, transcript in
            if speechCapture.isRecording, !transcript.isEmpty {
                companion.draft = transcript
            }
        }
        .onDisappear {
            guard !showingImmersiveVoice else { return }
            shakeObserver.stop()
            pendingOrbTap?.cancel()
            continuousRestartTask?.cancel()
            continuousIdleTask?.cancel()
            thinkingBudgetTask?.cancel()
            continuousIdleTask = nil
            if speechCapture.isRecording || speechCapture.isPreparing { speechCapture.interruptAndDiscard() }
            bargeInCaptureActive = false
            bargeInTriggered = false
        }
        .onChange(of: companion.isSending) { isSending in
            if !isSending { continueContinuousVoiceIfReady() }
        }
        .onChange(of: companion.isSpeakingReply) { isSpeaking in
            if isSpeaking {
                continuousRestartTask?.cancel()
                if developerBargeInEnabled {
                    startBargeInMonitorIfAllowed()
                } else {
                    if speechCapture.isRecording || speechCapture.isPreparing {
                        speechCapture.interruptAndDiscard()
                    }
                    bargeInCaptureActive = false
                    bargeInTriggered = false
                }
            } else {
                finishBargeInMonitorAfterReply()
                continueContinuousVoiceIfReady()
            }
        }
        .onChange(of: companion.isThinking) { thinking in
            thinkingBudgetTask?.cancel()
            thinkingBudgetExceeded = false
            guard thinking else { return }
            thinkingBudgetTask = Task { @MainActor in
                try? await Task.sleep(for: .seconds(2))
                guard !Task.isCancelled, companion.isThinking else { return }
                thinkingBudgetExceeded = true
            }
        }
        .onChange(of: companion.continuousVoiceEnabled) { enabled in
            if !enabled {
                stopContinuousVoice(discardRecording: true)
                showingImmersiveVoice = false
            }
        }
        .onChange(of: continuousTalkActive) { active in
            if !active { showingImmersiveVoice = false }
        }
        .onChange(of: showingImmersiveVoice) { isShown in
            if isShown {
                shakeObserver.stop()
            } else if scenePhase == .active {
                shakeObserver.start { companion.shakeOrb() }
            }
        }
        .onChange(of: scenePhase) { phase in
            switch phase {
            case .background:
                showingImmersiveVoice = false
                shakeObserver.stop()
                speechCapture.interruptAndPreserveTranscript()
                companion.stopSpeakingReply()
                bargeInCaptureActive = false
                bargeInTriggered = false
                microphonePressStartedAt = nil
                microphoneWasRecordingAtPressStart = false
                microphoneWasCancelled = false
                captureUsesTapToStop = false
                stopContinuousVoice(discardRecording: false)
                companion.pauseModelDownloadForBackground()
            case .active:
                speechCapture.refreshPermissionStatus()
                shakeObserver.start { companion.shakeOrb() }
                companion.resumePausedModelDownload()
                companion.applyPendingShortcutActions()
            default:
                break
            }
        }
        .onChange(of: companion.pendingWebSearchQuery) { query in
            guard let query else { return }
            webSearchInitialQuery = query
            companion.clearPendingWebSearchQuery()
            showingWebSearch = true
        }
        .onChange(of: companion.pendingActionURL) { url in
            guard let url else { return }
            openedWebPage = AnnaPresentedWebPage(url: url)
            companion.clearPendingActionURL()
        }
        .sheet(isPresented: $showingWebSearch) {
            AnnaWebSearchSheet(initialQuery: webSearchInitialQuery)
                .id(webSearchInitialQuery)
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        }
        .sheet(item: $openedWebPage) { page in
            AnnaSafariView(url: page.url)
                .ignoresSafeArea()
                .presentationDragIndicator(.visible)
        }
        .preferredColorScheme(.dark)
    }

    private func hero(characterSize: CGFloat, compact: Bool) -> some View {
        VStack(spacing: compact ? 5 : 8) {
            annaOrb(size: characterSize)
            Text("Anna")
                .font(.system(size: compact ? 27 : 31, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("A little voice by your side")
                .font(.system(size: compact ? 13 : 14, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
                .padding(.top, -7)
            if let firstReply = companion.firstReplyBubble {
                Text(firstReply.text)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.96))
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color(red: 0.14, green: 0.17, blue: 0.25), in: RoundedRectangle(cornerRadius: 16))
                    .frame(maxWidth: 310)
                    .accessibilityLabel("Anna says: \(firstReply.text)")
                }
            if companion.isSelectedModelReady, let model = selectedModel {
                Button { showingSettings = true } label: {
                    HStack(spacing: 5) {
                        Circle().fill(Color(red: 0.53, green: 0.91, blue: 0.83)).frame(width: 6, height: 6)
                        Text("Running \(model.name)")
                        Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold))
                    }
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.top, 2)
                }
                .buttonStyle(.plain)
                .accessibilityHint("Opens Settings, where you can manage Anna’s brain.")
            }
        }
        .frame(maxWidth: .infinity)
        .animation(reduceMotion ? .easeOut(duration: 0.12) : .spring(response: 0.38, dampingFraction: 0.84), value: companion.firstReplyBubble?.id)
    }

    private func annaOrb(size: CGFloat) -> some View {
        AnnaCharacterView(
            expression: orbExpression,
            showsFace: companion.companionState.mode != .awakeIdle || companion.orbPlayState != .idle || !companion.draft.isEmpty
        )
        .frame(width: size, height: size)
        .scaleEffect(companion.orbPlayState == .petting ? 1.06 : (companion.orbPlayState == .spinning ? 1.04 : 1))
        .rotationEffect(.degrees(reduceMotion ? 0 : (
            Double(companion.orbSpinCount) * 360
                + (companion.orbPlayState == .spinning || companion.orbPlayState == .dizzy ? 360 : 0)
        )))
        .offset(x: orbDragOffset.width * 0.12, y: orbDragOffset.height * 0.12)
        .animation(reduceMotion ? .easeOut(duration: 0.12) : .spring(response: 0.38, dampingFraction: 0.64), value: companion.orbPlayState)
        .animation(reduceMotion ? .easeOut(duration: 0.12) : .spring(response: 0.72, dampingFraction: 0.68), value: companion.orbSpinCount)
        .animation(.spring(response: 0.3, dampingFraction: 0.72), value: orbDragOffset)
        .contentShape(Circle())
        .onTapGesture(count: 2) {
            pendingOrbTap?.cancel()
            pendingOrbTap = nil
            companion.doubleTapOrb()
        }
        .onTapGesture(count: 1) {
            pendingOrbTap?.cancel()
            pendingOrbTap = Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(280))
                guard !Task.isCancelled else { return }
                if continuousTalkActive { stopContinuousVoice(discardRecording: true) }
                else { companion.pet() }
            }
        }
        .onLongPressGesture(minimumDuration: 0.45) {
            pendingOrbTap?.cancel()
            pendingOrbTap = nil
            companion.longPressOrb()
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 9)
                .onChanged { value in
                    if orbDragStartedAt == nil { orbDragStartedAt = Date() }
                    orbDragOffset = value.translation
                    if let started = orbDragStartedAt, Date().timeIntervalSince(started) > 0.65, !orbPettingActive {
                        orbPettingActive = true
                        companion.beginOrbPetting()
                    }
                }
                .onEnded { value in
                    let predicted = hypot(value.predictedEndTranslation.width, value.predictedEndTranslation.height)
                    if orbPettingActive {
                        companion.endOrbPetting()
                    } else if predicted > 115 {
                        companion.flickOrb()
                    } else {
                        companion.strokeOrb()
                    }
                    orbPettingActive = false
                    orbDragStartedAt = nil
                    orbDragOffset = .zero
                }
        )
        .accessibilityAddTraits(.isButton)
        .accessibilityLabel("Anna, your pink pixel companion")
        .accessibilityHint(continuousTalkActive
            ? "Tap to end the continuous conversation. Double tap for a spin, drag to stroke, or touch and hold to comfort Anna."
            : "Tap to say hello, double tap for a spin, drag to stroke, or touch and hold to comfort Anna.")
        .accessibilityAction { companion.pet() }
        .accessibilityAction(named: Text("Comfort Anna")) { companion.longPressOrb() }
        .accessibilityAction(named: Text("Delight Anna")) { companion.doubleTapOrb() }
    }

    private var orbExpression: CharmExpression {
        if bargeInCaptureActive && bargeInTriggered { return .curious }
        if !companion.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return .curious }
        switch companion.orbPlayState {
        case .idle: return companion.expression
        case .petting: return .bashful
        case .spinning: return .excited
        case .dizzy: return .confused
        }
    }

    private var compactContactHeader: some View {
        HStack(spacing: 9) {
            annaOrb(size: 42)
            VStack(alignment: .leading, spacing: 1) {
                Text("Anna")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text(voicePresenceLabel)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
            }
            Spacer()
            if companion.isThinking { ProgressView().tint(.white).scaleEffect(0.8) }
        }
        .frame(maxWidth: .infinity, minHeight: 46, alignment: .leading)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Anna, contact header, \(voicePresenceLabel)")
    }

    private var voicePresenceLabel: String {
        if bargeInCaptureActive && bargeInTriggered { return "Listening" }
        if companion.isSpeakingReply { return "Speaking. Tap Stop Anna when you’re ready." }
        if speechCapture.isRecording || speechCapture.isPreparing {
            return bargeInCaptureActive ? "Speaking. Talk to interrupt." : "Listening"
        }
        if companion.isThinking { return "Thinking" }
        if companion.isSending { return "Replying" }
        return "Online"
    }

    private var background: some View {
        TimelineView(.periodic(from: .now, by: 300)) { timeline in
            ambientBackground(at: timeline.date)
        }
    }

    private func ambientBackground(at date: Date) -> some View {
        let hour = Calendar.current.component(.hour, from: date)
        let palette: (top: Color, base: Color, glow: Color)
        switch hour {
        case 6..<10:
            palette = (Color(red: 0.24, green: 0.13, blue: 0.25), Color(red: 0.045, green: 0.04, blue: 0.12), Color(red: 0.96, green: 0.44, blue: 0.62))
        case 10..<17:
            palette = (Color(red: 0.11, green: 0.19, blue: 0.33), Color(red: 0.025, green: 0.045, blue: 0.10), Color(red: 0.34, green: 0.58, blue: 0.88))
        case 17..<21:
            palette = (Color(red: 0.28, green: 0.12, blue: 0.27), Color(red: 0.055, green: 0.035, blue: 0.12), Color(red: 0.95, green: 0.35, blue: 0.62))
        default:
            palette = (Color(red: 0.075, green: 0.09, blue: 0.20), Color(red: 0.018, green: 0.025, blue: 0.065), Color(red: 0.55, green: 0.35, blue: 0.82))
        }
        return ZStack {
            LinearGradient(colors: [palette.top, palette.base], startPoint: .top, endPoint: .bottom)
            RadialGradient(
                colors: [palette.glow.opacity(companion.quietMode ? 0.045 : 0.14), .clear],
                center: UnitPoint(x: 0.5, y: 0.57),
                startRadius: 8,
                endRadius: 370
            )
        }
    }

    private var header: some View {
        HStack(spacing: 7) {
            Button {
                openConversationDrawer()
            } label: {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 16, weight: .semibold))
                    .frame(width: 34, height: 34)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white.opacity(0.9))
            .accessibilityLabel("Open conversations menu")

            if !companion.shouldUseCompactHeader {
            Label(companion.isSelectedModelReady ? "ANNA · LOCAL READY" : "ON-DEVICE AI", systemImage: "iphone.gen3")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.1)
                    .foregroundStyle(.white.opacity(0.78))
                    .lineLimit(1)
                    .minimumScaleFactor(0.85)
            }

            Spacer(minLength: 5)

            Button {
                if !companion.watchReachable { showingWatchHelp = true }
            } label: {
                HStack(spacing: 6) {
                    Circle()
                        .fill(companion.watchIsSetUp ? Color.green : Color.white.opacity(0.35))
                        .frame(width: 7, height: 7)
                    Text(companion.watchStatusText)
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
                .foregroundStyle(.white.opacity(0.72))
            }
            .buttonStyle(.plain)
            .accessibilityHint(companion.watchReachable ? "Watch is available" : "Show Apple Watch connection details")

            Menu {
                Button("New conversation", systemImage: "square.and.pencil") { companion.startNewConversation() }
                Button("Clear conversation", systemImage: "trash.slash") { companion.clearActiveConversation() }
                Button("Search the web", systemImage: "magnifyingglass") {
                    webSearchInitialQuery = ""
                    showingWebSearch = true
                }
                Button("Open loops", systemImage: "checklist") { showingOpenLoops = true }
                Button("Settings", systemImage: "gearshape") { showingSettings = true }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 34, height: 34)
                    .contentShape(Rectangle())
            }
            .foregroundStyle(.white.opacity(0.82))
            .accessibilityLabel("Conversation actions")
        }
        .frame(maxWidth: .infinity, minHeight: 23)
    }

    private var modelCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Anna’s brain")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                    Text(companion.modelNeedsRedownload
                        ? "Anna’s saved brain needs to be fetched again. Your conversations are safe."
                        : "Choose her recommended on-device brain to get started.")
                        .font(.system(size: 12, design: .rounded))
                        .foregroundStyle(.white.opacity(0.65))
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 8)
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(Color(red: 0.53, green: 0.91, blue: 0.83))
                    .accessibilityLabel("Private on-device model")
            }

            if let selectedModel {
                VStack(alignment: .leading, spacing: 4) {
                    Text(selectedModel.name)
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("\(selectedModel.formattedDownloadSize) download · \(selectedModel.estimatedWorkingSetDescription)")
                        .font(.system(size: 11, design: .rounded))
                        .foregroundStyle(.white.opacity(0.68))
                        .fixedSize(horizontal: false, vertical: true)
                    Text(selectedModel.summary)
                        .font(.system(size: 11, design: .rounded))
                        .foregroundStyle(.white.opacity(0.58))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(red: 0.14, green: 0.16, blue: 0.22), in: RoundedRectangle(cornerRadius: 14))

                if companion.isLoadingModel {
                    HStack(spacing: 10) {
                        ProgressView(value: companion.downloadProgress)
                            .tint(Color(red: 0.53, green: 0.91, blue: 0.83))
                        if companion.modelPreparationStatus.contains("Downloading") {
                            Button("Pause") { companion.pauseModelDownload() }
                                .font(.system(size: 11, weight: .semibold, design: .rounded))
                                .buttonStyle(.plain)
                                .foregroundStyle(.white.opacity(0.8))
                        }
                    }
                    Text(companion.downloadProgressIsEstimated
                        ? "\(companion.modelPreparationStatus) · about \(Int(companion.downloadProgress * 100))%"
                        : (companion.modelPreparationStatus.contains("Downloading")
                            ? "\(companion.modelPreparationStatus) · \(Int(companion.downloadProgress * 100))%"
                            : companion.modelPreparationStatus))
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.7))
                } else if companion.isSelectedModelReady {
                    Label("Ready offline", systemImage: "checkmark.circle.fill")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color(red: 0.53, green: 0.91, blue: 0.83))
                } else if companion.isModelDownloadPaused {
                    ProgressView(value: companion.downloadProgress)
                        .tint(Color(red: 0.53, green: 0.91, blue: 0.83))
                    Button(action: companion.resumePausedModelDownload) {
                        Label("Resume Anna’s brain · \(Int(companion.downloadProgress * 100))%", systemImage: "arrow.clockwise.circle.fill")
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 5)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.29, green: 0.60, blue: 0.92))
                    .disabled(companion.isSending)
                } else {
                    Button(action: companion.loadSelectedModel) {
                        Label("Download & prepare · \(selectedModel.formattedDownloadSize)", systemImage: "arrow.down.circle.fill")
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 5)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.29, green: 0.60, blue: 0.92))
                    .disabled(companion.isSending)
                }

                Text(companion.speaksReplies ? "Voice replies on" : "Voice replies off")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
            } else {
                Text("Anna’s lightweight model is not available for this device’s memory estimate.")
                    .font(.system(size: 12, design: .rounded))
                    .foregroundStyle(.white.opacity(0.7))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(15)
        .background(Color(red: 0.10, green: 0.12, blue: 0.19), in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.09), lineWidth: 1))
    }

    private var watchHelpText: String {
        if !companion.watchPaired {
            return "Pair an Apple Watch with this iPhone in the Watch app to use Anna on your wrist."
        }
        if !companion.watchAppInstalled {
            return "Open the Watch app on your iPhone, find Anna under Available Apps, and tap Install."
        }
        return "Anna is installed. Apple Watch pauses apps when its screen sleeps, so the live connection may pause too. Open Anna on the watch when you want to talk."
    }

    private var conversation: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text("Conversation")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
                if companion.conversations.first(where: { $0.id == companion.activeConversationID })?.rollingSummary != nil {
                    Button("Catch me up") { companion.catchMeUpOnActiveConversation() }
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color(red: 0.93, green: 0.62, blue: 0.77))
                        .buttonStyle(.plain)
                }
                Spacer()
                if companion.isSpeakingReply {
                    Text("Anna is speaking")
                        .font(.system(size: 10, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                } else if companion.isThinking {
                    ProgressView().tint(.white).scaleEffect(0.8)
                    Text(companion.streamingReply.isEmpty
                        ? (thinkingBudgetExceeded ? "Still thinking, one moment" : "Anna is thinking")
                        : "Anna is replying")
                        .font(.system(size: 10, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                } else if companion.isSending {
                    Text("Sending")
                        .font(.system(size: 10, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                }
            }

            if let article = companion.sharedArticle {
                VStack(alignment: .leading, spacing: 7) {
                    Label(article.title, systemImage: "text.book.closed")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                    Text(String(article.text.prefix(150)))
                        .font(.system(size: 11, design: .rounded))
                        .foregroundStyle(.white.opacity(0.68))
                        .lineLimit(2)
                    HStack {
                        if companion.isReadingArticle {
                            Button(companion.isArticlePaused ? "Resume reading" : "Pause reading") {
                                if companion.isArticlePaused { companion.resumeReadingSharedArticle() }
                                else { companion.pauseReadingSharedArticle() }
                            }
                            Button("Stop") { companion.stopReadingSharedArticle() }
                        } else {
                            Button("Read it to me") { companion.startReadingSharedArticle() }
                        }
                        Spacer()
                    }
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    Text(companion.articleReadingStatus.isEmpty ? "Shared text is ready to read aloud." : companion.articleReadingStatus)
                        .font(.system(size: 10, design: .rounded))
                        .foregroundStyle(.white.opacity(0.55))
                }
                .padding(11)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(red: 0.10, green: 0.12, blue: 0.19), in: RoundedRectangle(cornerRadius: 14))
            }

            if let receipt = companion.actionReceipt {
                VStack(alignment: .leading, spacing: 7) {
                    HStack(spacing: 6) {
                        Image(systemName: receipt.undoAction == nil ? "checkmark.circle.fill" : "checkmark.circle")
                            .foregroundStyle(Color(red: 0.53, green: 0.91, blue: 0.83))
                        Text(receipt.title)
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                        Spacer()
                        Button {
                            companion.dismissActionReceipt()
                        } label: {
                            Image(systemName: "xmark")
                                .font(.caption.weight(.semibold))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Dismiss action receipt")
                    }
                    Text(receipt.detail)
                        .font(.system(size: 11, design: .rounded))
                        .foregroundStyle(.white.opacity(0.72))
                        .fixedSize(horizontal: false, vertical: true)
                    if receipt.undoAction != nil {
                        Button {
                            companion.undoActionReceipt()
                        } label: {
                            if companion.isUndoingAction {
                                ProgressView().tint(.white)
                            } else {
                                Label("Undo", systemImage: "arrow.uturn.backward")
                            }
                        }
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                        .disabled(companion.isUndoingAction)
                    }
                }
                .padding(11)
                .background(Color(red: 0.10, green: 0.16, blue: 0.18), in: RoundedRectangle(cornerRadius: 13))
                .overlay(RoundedRectangle(cornerRadius: 13).stroke(.white.opacity(0.08), lineWidth: 1))
            }

            if companion.messages.isEmpty {
                Text("A quiet little beginning. What would you like to talk about?")
                    .font(.system(size: 13, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 8) {
                    suggestion("How are you?")
                    suggestion("Tell me something kind")
                }
            } else {
                VStack(alignment: .leading, spacing: 9) {
                    ForEach(visibleConversationMessages, id: \.id) { line in
                        VStack(spacing: 7) {
                            if shouldShowTimestamp(for: line) {
                                Text(line.createdAt.formatted(date: .abbreviated, time: .shortened))
                                    .font(.system(size: 10, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.42))
                                    .padding(.top, 4)
                                    .accessibilityLabel(line.createdAt.formatted(date: .complete, time: .shortened))
                            }
                            HStack {
                                if line.role == .user { Spacer(minLength: 34) }
                                VStack(alignment: .leading, spacing: 8) {
                                    if let filename = line.attachmentFilename,
                                       let url = AnnaPhoneViewModel.cloudAttachmentURL(for: filename),
                                       let image = UIImage(contentsOfFile: url.path) {
                                        Image(uiImage: image)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(maxWidth: 260, maxHeight: 260)
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                            .accessibilityLabel("Photo attached to message")
                                    }
                                    if !line.text.isEmpty {
                                        AnnaRichMessageContent(text: line.text)
                                    }
                                    if line.generationStopped == true {
                                        Text("Stopped. This partial reply was kept.")
                                            .font(.system(size: 10, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.58))
                                    }
                                    if line.speechInterrupted == true {
                                        HStack(spacing: 8) {
                                            Text("Speech stopped. The full reply remains in chat.")
                                                .font(.system(size: 10, weight: .medium, design: .rounded))
                                                .foregroundStyle(.white.opacity(0.56))
                                            Button("Hear it again") { companion.speakMessageAgain(line.id) }
                                                .font(.system(size: 10, weight: .semibold, design: .rounded))
                                                .foregroundStyle(Color(red: 0.93, green: 0.62, blue: 0.77))
                                                .buttonStyle(.plain)
                                        }
                                    }
                                }
                                    .padding(.horizontal, 13)
                                    .padding(.vertical, 10)
                                    .background(
                                        line.role == .user ? Color(red: 0.18, green: 0.34, blue: 0.55) : Color(red: 0.14, green: 0.16, blue: 0.22),
                                        in: RoundedRectangle(cornerRadius: 18)
                                    )
                                if line.role == .anna { Spacer(minLength: 34) }
                            }
                            .contextMenu {
                                Button("Copy message", systemImage: "doc.on.doc") {
                                    UIPasteboard.general.string = line.text
                                }
                                Button("Share this message as an image", systemImage: "square.and.arrow.up") {
                                    prepareShareCard(for: line)
                                }
                                if line.role == .user {
                                    Button("Edit and resend", systemImage: "pencil") {
                                        editingMessageID = line.id
                                        editingMessageText = line.text
                                        showingMessageEditor = true
                                    }
                                } else {
                                    Button("Read aloud", systemImage: "speaker.wave.2") {
                                        companion.speakMessageAgain(line.id)
                                    }
                                    if companion.canRegenerateReply(line.id) {
                                        Button("Regenerate reply", systemImage: "arrow.clockwise") {
                                            companion.regenerateReply(for: line.id)
                                        }
                                        Button("Try a different angle", systemImage: "arrow.triangle.2.circlepath") {
                                            companion.regenerateReply(for: line.id, differentAngle: true)
                                        }
                                    }
                                    if let helpStyle = line.helpStyle {
                                        Button("Helpful", systemImage: "hand.thumbsup") {
                                            companion.recordHelpFeedback(for: line.id, feedback: .helpful)
                                        }
                                        ForEach(AnnaHelpStyle.allCases.filter { $0 != helpStyle }) { alternative in
                                            Button("Prefer \(alternative.label)", systemImage: "slider.horizontal.3") {
                                                let feedback: AnnaHelpFeedback
                                                switch alternative {
                                                case .listening: feedback = .preferListening
                                                case .advice: feedback = .preferAdvice
                                                case .action: feedback = .preferAction
                                                }
                                                companion.recordHelpFeedback(for: line.id, feedback: feedback)
                                            }
                                        }
                                    }
                                }
                            }
                            if let references = line.conversationReferences, !references.isEmpty {
                                VStack(alignment: .leading, spacing: 5) {
                                    ForEach(references) { reference in
                                        Button {
                                            companion.openConversationReference(reference)
                                            closeConversationDrawer()
                                        } label: {
                                            VStack(alignment: .leading, spacing: 3) {
                                                Label("Earlier chat: \(reference.conversationTitle)", systemImage: "arrow.uturn.backward")
                                                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                                                Text(reference.excerpt)
                                                    .font(.system(size: 10, design: .rounded))
                                                    .lineLimit(2)
                                                    .multilineTextAlignment(.leading)
                                            }
                                            .foregroundStyle(Color(red: 0.76, green: 0.79, blue: 0.91))
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                                .padding(.leading, 5)
                            }
                            if let sources = line.searchSources, !sources.isEmpty {
                                VStack(alignment: .leading, spacing: 5) {
                                    if let query = line.searchQuery {
                                        Text("Searched: \(query) · \(line.searchDate?.formatted(date: .omitted, time: .shortened) ?? "just now")")
                                            .font(.system(size: 10, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.55))
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                    ForEach(Array(sources.prefix(5).enumerated()), id: \.offset) { index, source in
                                        Button {
                                            companion.openURL(source.url)
                                        } label: {
                                            Label("[\(index + 1)] \(source.title)", systemImage: "arrow.up.right.square")
                                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                                .foregroundStyle(Color(red: 0.63, green: 0.82, blue: 1))
                                                .lineLimit(2)
                                                .multilineTextAlignment(.leading)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, line.role == .anna ? 4 : 40)
                            }
                        }
                        .id(line.id)
                        .transaction { $0.animation = nil }
                    }
                    if !companion.isSending, !companion.suggestedFollowUps.isEmpty {
                        ScrollView(.horizontal) {
                            HStack(spacing: 7) {
                                ForEach(companion.suggestedFollowUps, id: \.self) { followUp in
                                    Button(followUp) {
                                        companion.useSuggestedFollowUp(followUp)
                                        inputFocused = true
                                    }
                                    .font(.system(size: 11, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.9))
                                    .padding(.horizontal, 11)
                                    .padding(.vertical, 8)
                                    .background(.white.opacity(0.08), in: Capsule())
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                    if !companion.streamingReply.isEmpty {
                        HStack {
                            Text(companion.streamingReply)
                                .font(.system(size: 15, design: .rounded))
                                .foregroundStyle(.white.opacity(0.96))
                                .fixedSize(horizontal: false, vertical: true)
                                .padding(.horizontal, 13)
                                .padding(.vertical, 10)
                                .background(Color(red: 0.14, green: 0.16, blue: 0.22), in: RoundedRectangle(cornerRadius: 18))
                            Spacer(minLength: 34)
                        }
                        .id("anna-streaming-reply")
                        .transaction { $0.animation = nil }
                    }
                }
            }
            if let step = companion.goalInterviewStep {
                goalInterviewCard(for: step)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func goalInterviewCard(for step: AnnaGoalInterviewStep) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            Label("A little get-to-know-you", systemImage: "sparkles")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(Color(red: 0.98, green: 0.62, blue: 0.78))

            switch step {
            case .steps:
                Text("What daily step goal feels right for you?")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                HStack(spacing: 7) {
                    ForEach([6_000, 8_000, 10_000], id: \.self) { target in
                        Button(target.formatted()) { companion.answerStepGoal(target) }
                            .buttonStyle(.bordered)
                            .tint(Color(red: 0.80, green: 0.36, blue: 0.59))
                    }
                    Button("Skip") { companion.answerStepGoal(nil) }
                        .buttonStyle(.plain)
                        .foregroundStyle(.white.opacity(0.7))
                }
                HStack {
                    TextField("Or enter a number", text: $customStepGoal)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                    Button("Save") {
                        guard let target = Int(customStepGoal) else { return }
                        companion.answerStepGoal(target)
                        customStepGoal = ""
                    }
                    .disabled(Int(customStepGoal) == nil)
                }
            case .sleep:
                Text("What bedtime and wake-up time would you like me to keep in mind?")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                DatePicker("Bedtime", selection: $companion.goalBedtimeTime, displayedComponents: .hourAndMinute)
                DatePicker("Wake up", selection: $companion.goalWakeTime, displayedComponents: .hourAndMinute)
                HStack {
                    Button("Save schedule") { companion.saveSleepGoal() }
                        .buttonStyle(.borderedProminent)
                        .tint(Color(red: 0.80, green: 0.36, blue: 0.59))
                    Button("Skip") { companion.skipSleepGoal() }
                        .buttonStyle(.plain)
                        .foregroundStyle(.white.opacity(0.7))
                }
            case .routines:
                Text("Is there one recurring task you’d like me to keep on your routine list?")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                TextField("For example, stretch after lunch", text: $recurringGoalTitle)
                    .textFieldStyle(.roundedBorder)
                Picker("Repeats", selection: $recurringGoalCadence) {
                    ForEach(AnnaRecurringCadence.allCases) { cadence in
                        Text(cadence.label).tag(cadence)
                    }
                }
                .pickerStyle(.segmented)
                HStack {
                    Button("Add routine") {
                        companion.addRecurringGoal(recurringGoalTitle, cadence: recurringGoalCadence)
                        recurringGoalTitle = ""
                    }
                    .buttonStyle(.bordered)
                    .disabled(recurringGoalTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("Finish") { companion.finishGoalInterview() }
                        .buttonStyle(.borderedProminent)
                        .tint(Color(red: 0.80, green: 0.36, blue: 0.59))
                }
            }
        }
        .font(.system(size: 13, design: .rounded))
        .padding(13)
        .background(Color(red: 0.10, green: 0.12, blue: 0.20), in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(.white.opacity(0.08), lineWidth: 1))
        .accessibilityElement(children: .contain)
    }

    private var visibleConversationMessages: [AnnaChatLine] {
        companion.messages.filter { $0.id != companion.firstReplyBubble?.id }
    }

    private func shouldShowTimestamp(for line: AnnaChatLine) -> Bool {
        guard let index = companion.messages.firstIndex(where: { $0.id == line.id }) else { return false }
        guard index > 0 else { return true }
        let previous = companion.messages[index - 1]
        return !Calendar.current.isDate(previous.createdAt, inSameDayAs: line.createdAt)
            || line.createdAt.timeIntervalSince(previous.createdAt) > 4 * 60 * 60
    }

    private var composer: some View {
        VStack(spacing: 6) {
            if companion.continuousVoiceEnabled {
                Button {
                    if continuousTalkActive {
                        stopContinuousVoice(discardRecording: false)
                        showingImmersiveVoice = false
                    } else {
                        consecutiveVoiceMisses = 0
                        continuousTalkActive = true
                        showingImmersiveVoice = true
                    }
                } label: {
                    Label(
                        continuousTalkActive ? "Done for now" : "Keep talking",
                        systemImage: continuousTalkActive ? "stop.circle.fill" : "waveform.circle"
                    )
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(continuousTalkActive ? Color.white : Color.white.opacity(0.78))
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
                .accessibilityHint("Starts an iPhone-only conversation. Anna listens again after each reply. Tap Done for now or tap Anna to stop.")
            }
            if speechCapture.isPreparing || speechCapture.isRecording || speechCapture.isFinishing {
                HStack(spacing: 8) {
                    HStack(alignment: .center, spacing: 2) {
                        ForEach(0..<9, id: \.self) { index in
                            Capsule()
                                .fill(Color(red: 1.0, green: 0.48, blue: 0.68))
                                .frame(width: 3, height: CGFloat(4 + speechCapture.audioLevel * Double((index % 4) * 5 + 4)))
                        }
                    }
                    .frame(width: 34, height: 22)
                    Text(speechCapture.isPreparing
                        ? "Connecting to microphone…"
                        : (speechCapture.isFinishing
                            ? "Finishing…"
                            : (bargeInCaptureActive && !bargeInTriggered
                                ? "Talk to interrupt Anna"
                                : (speechCapture.transcript.isEmpty ? "I’m listening" : speechCapture.transcript))))
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.86))
                        .lineLimit(1)
                        .truncationMode(.tail)
                    Spacer(minLength: 4)
                    Text(timeLabel(speechCapture.elapsedSeconds))
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.65))
                    if speechCapture.isRecording {
                        Text(bargeInCaptureActive && !bargeInTriggered
                            ? "Talk to interrupt"
                            : (continuousTalkActive ? "Pause to send" : (captureUsesTapToStop ? "Pause to send" : "Release to send")))
                            .font(.system(size: 9, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.58))
                    }
                }
                .padding(.horizontal, 9)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("\(speechCapture.isRecording ? "Listening" : "Preparing microphone"), \(timeLabel(speechCapture.elapsedSeconds))")
            }
            HStack(spacing: 9) {
            PhotosPicker(selection: $selectedPhoto, matching: .images) {
                Image(systemName: "plus")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 40, height: 44)
                    .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            .disabled(companion.isSending || companion.isLoadingModel)
            .accessibilityLabel("Attach a photo")
            .onChange(of: selectedPhoto) { _, item in
                guard let item else { return }
                Task { @MainActor in
                    defer { selectedPhoto = nil }
                    do {
                        guard let data = try await item.loadTransferable(type: Data.self) else {
                            companion.reportPhotoImportFailure()
                            return
                        }
                        companion.sendPhoto(data)
                    } catch {
                        companion.reportPhotoImportFailure()
                    }
                }
            }

            TextField("Dictate or type a message…", text: $companion.draft, axis: .vertical)
                .font(.system(size: 14, design: .rounded))
                .lineLimit(1...4)
                .focused($inputFocused)
                .submitLabel(.send)
                .onSubmit(companion.sendDraft)
                .padding(.horizontal, 13)
                .padding(.vertical, 10)
                .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 15))

            Image(systemName: speechCapture.isRecording ? "waveform" : (companion.isSpeakingReply ? "speaker.wave.2.fill" : "mic.fill"))
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(speechCapture.isRecording ? .white : Color(red: 0.86, green: 0.62, blue: 0.78))
                .frame(width: 42, height: 44)
                .background(
                    speechCapture.isRecording ? Color(red: 0.82, green: 0.30, blue: 0.55) : Color.white.opacity(0.09),
                    in: RoundedRectangle(cornerRadius: 14)
                )
                .contentShape(RoundedRectangle(cornerRadius: 14))
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { _ in beginMicrophonePress() }
                        .onEnded(finishMicrophonePress)
                )
                .allowsHitTesting(!speechCapture.isFinishing && (!companion.isSpeakingReply || developerBargeInEnabled))
                .accessibilityAddTraits(.isButton)
                .accessibilityLabel(companion.isSpeakingReply && !developerBargeInEnabled
                    ? "Microphone off while Anna speaks"
                    : (bargeInCaptureActive && !bargeInTriggered
                    ? "Talk to interrupt Anna"
                    : (speechCapture.isRecording ? "Stop listening" : "Talk to Anna")))
                .accessibilityHint(companion.isSpeakingReply && !developerBargeInEnabled
                    ? "Wait until Anna finishes, or use Stop Anna to take your turn."
                    : (bargeInCaptureActive && !bargeInTriggered
                        ? "Developer voice interruption is active."
                        : "Tap, speak, then pause to send automatically. Hold to record and release to send. Slide away to cancel."))
                .accessibilityAction(named: Text("Start or stop listening")) { toggleMicrophoneFromAccessibility() }
                .accessibilityAction(named: Text("Cancel recording")) { speechCapture.cancel() }

            Button {
                if companion.isSpeakingReply {
                    companion.stopSpeakingReplyByUser()
                } else if companion.isSending {
                    companion.stopGenerationKeepingPartial()
                } else {
                    companion.sendDraft()
                }
            } label: {
                Group {
                    if companion.isSending || companion.isSpeakingReply {
                        Image(systemName: "stop.fill")
                            .font(.system(size: 13, weight: .bold))
                    } else {
                        Image(systemName: "arrow.up")
                            .font(.system(size: 15, weight: .bold))
                    }
                }
                .frame(width: 44, height: 44)
                .background(
                    companion.isSending || companion.isSpeakingReply ? Color(red: 0.82, green: 0.30, blue: 0.55)
                        : (canSend ? Color(red: 0.29, green: 0.60, blue: 0.92) : Color.white.opacity(0.12)),
                    in: RoundedRectangle(cornerRadius: 15)
                )
                .foregroundStyle(.white.opacity(companion.isSending || companion.isSpeakingReply || canSend ? 1 : 0.48))
            }
            .buttonStyle(.plain)
            .disabled(companion.isLoadingModel || (!companion.isSending && !companion.isSpeakingReply && !canSend))
            .accessibilityLabel(companion.isSpeakingReply ? "Stop Anna speaking" : (companion.isSending ? "Stop reply" : "Send message"))
            }
        }
    }

    private var canSend: Bool {
        !companion.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !companion.isSending && !companion.isLoadingModel
    }

    @MainActor
    private func prepareShareCard(for line: AnnaChatLine) {
        let content = line.text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !content.isEmpty else { return }
        let renderer = ImageRenderer(content: AnnaShareCardView(
            text: content,
            speaker: line.role == .user ? "You" : "Anna"
        ).frame(width: 1_080, height: 1_350))
        renderer.scale = 1
        shareCardImage = renderer.uiImage
    }

    private func suggestion(_ text: String) -> some View {
        Button(text) { companion.draft = text }
            .font(.system(size: 11, weight: .medium, design: .rounded))
            .foregroundStyle(.white.opacity(0.9))
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(.white.opacity(0.08), in: Capsule())
            .buttonStyle(.plain)
    }

    private func closeConversationDrawer() {
        showingConversationDrawer = false
        inputFocused = false
    }

    private func openConversationDrawer() {
        inputFocused = false
        speechCapture.interruptAndDiscard()
        microphonePressStartedAt = nil
        microphoneWasRecordingAtPressStart = false
        showingConversationDrawer = true
    }

    private func beginMicrophonePress() {
        guard microphonePressStartedAt == nil else { return }
        guard !companion.isSpeakingReply || developerBargeInEnabled else { return }
        if bargeInCaptureActive && !bargeInTriggered {
            bargeInTriggered = true
            continuousIdleTask?.cancel()
            companion.interruptReplyForBargeIn()
        }
        microphonePressStartedAt = Date()
        microphoneWasCancelled = false
        microphoneWasRecordingAtPressStart = speechCapture.isRecording || speechCapture.isPreparing
        captureUsesTapToStop = false
        if microphoneWasRecordingAtPressStart { return }
        inputFocused = false
        companion.beginVoiceCapture()
        speechCapture.start(maximumDuration: 120, autoFinishAfterSilence: false) { handleCapturedSpeech($0) } onInterrupted: {
            handleInterruptedSpeech($0)
        }
    }

    private func finishMicrophonePress(_ value: DragGesture.Value) {
        guard let startedAt = microphonePressStartedAt else { return }
        microphonePressStartedAt = nil
        let outsideButton = value.location.x < -12 || value.location.x > 54
            || value.location.y < -12 || value.location.y > 56
        if outsideButton {
            microphoneWasCancelled = true
            speechCapture.cancel()
            companion.cancelVoiceCapture()
            return
        }
        if microphoneWasCancelled { return }
        if microphoneWasRecordingAtPressStart {
            speechCapture.finish()
        } else if Date().timeIntervalSince(startedAt) < 0.22 {
            captureUsesTapToStop = true
            speechCapture.continueAfterQuickTap()
        } else {
            captureUsesTapToStop = false
            speechCapture.finish()
        }
        microphoneWasRecordingAtPressStart = false
    }

    private func toggleMicrophoneFromAccessibility() {
        guard !companion.isSpeakingReply || developerBargeInEnabled else { return }
        if bargeInCaptureActive && !bargeInTriggered {
            bargeInTriggered = true
            continuousIdleTask?.cancel()
            companion.interruptReplyForBargeIn()
            return
        }
        if speechCapture.isRecording || speechCapture.isPreparing {
            speechCapture.finish()
        } else {
            inputFocused = false
            companion.beginVoiceCapture()
            captureUsesTapToStop = true
            speechCapture.start(maximumDuration: 120, autoFinishAfterSilence: true) { handleCapturedSpeech($0) } onInterrupted: {
                handleInterruptedSpeech($0)
            }
        }
    }

    private func timeLabel(_ seconds: Double) -> String {
        let elapsed = max(0, Int(seconds))
        return String(format: "%d:%02d", elapsed / 60, elapsed % 60)
    }

    private func handleCapturedSpeech(_ text: String) {
        continuousIdleTask?.cancel()
        continuousIdleTask = nil
        bargeInCaptureActive = false
        bargeInTriggered = false
        let cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else {
            if ignoreNextEmptyVoiceResult {
                ignoreNextEmptyVoiceResult = false
                return
            }
            guard speechCapture.errorMessage == nil else {
                if speechCapture.permissionStatus == .enabled {
                    speechCapture.dismissError()
                    handleVoiceRecognitionMiss()
                } else {
                    if continuousTalkActive {
                        stopContinuousVoice(discardRecording: true)
                        showingImmersiveVoice = false
                        inputFocused = true
                    }
                }
                return
            }
            handleVoiceRecognitionMiss()
            return
        }
        ignoreNextEmptyVoiceResult = false
        consecutiveVoiceMisses = 0
        if continuousTalkActive && isContinuousEndPhrase(cleaned) {
            stopContinuousVoice(discardRecording: true)
            showingImmersiveVoice = false
            companion.finishContinuousVoiceSession(transcript: cleaned)
            return
        }
        companion.markVoiceTurnFinalized()
        continuousReplyPending = continuousTalkActive
        companion.draft = cleaned
        companion.sendDraft()
    }

    private func handleInterruptedSpeech(_ text: String) {
        continuousIdleTask?.cancel()
        bargeInCaptureActive = false
        bargeInTriggered = false
        companion.cancelVoiceCapture()
        guard !text.isEmpty else { return }
        companion.draft = text
    }

    private func startBargeInMonitorIfAllowed() {
#if DEBUG
        guard developerBargeInEnabled else { return }
        guard companion.speaksReplies,
              speechCapture.permissionStatus == .enabled,
              scenePhase == .active,
              !bargeInCaptureActive,
              !speechCapture.isRecording,
              !speechCapture.isPreparing else { return }
        bargeInCaptureActive = true
        bargeInTriggered = false
        captureUsesTapToStop = true
        speechCapture.start(
            maximumDuration: 120,
            autoFinishAfterSilence: true,
            onComplete: { handleCapturedSpeech($0) },
            onInterrupted: { handleInterruptedSpeech($0) },
            bargeInMode: true,
            onSpeechDetected: {
                guard bargeInCaptureActive, !bargeInTriggered else { return }
                bargeInTriggered = true
                continuousIdleTask?.cancel()
                companion.interruptReplyForBargeIn()
            }
        )
#endif
    }

    private func finishBargeInMonitorAfterReply() {
        guard bargeInCaptureActive, !bargeInTriggered else { return }
        speechCapture.cancel()
        bargeInCaptureActive = false
    }

    private func handleVoiceRecognitionMiss() {
        consecutiveVoiceMisses += 1
        let offerTyping = consecutiveVoiceMisses >= 2
        continuousReplyPending = continuousTalkActive && !offerTyping
        if offerTyping {
            stopContinuousVoice(discardRecording: true)
            inputFocused = true
            showingImmersiveVoice = false
        }
        companion.reportVoiceRecognitionMiss(
            offerTyping: offerTyping,
            confidence: speechCapture.lastRecognitionConfidence
        )
        if continuousReplyPending && !companion.speaksReplies {
            continueContinuousVoiceIfReady()
        }
    }

    private func isContinuousEndPhrase(_ text: String) -> Bool {
        let normalized = text.lowercased()
            .replacingOccurrences(of: "’", with: "'")
            .filter { $0.isLetter || $0.isNumber || $0.isWhitespace || $0 == "'" }
            .split(whereSeparator: \.isWhitespace)
            .joined(separator: " ")
        return ["that's all", "that's it", "thanks i'm good", "thanks i'm good for now", "i'm good for now", "i'm done"]
            .contains(normalized)
    }

    private func startContinuousCapture() {
        guard continuousTalkActive, companion.continuousVoiceEnabled, scenePhase == .active else { return }
        guard !companion.isSpeakingReply else {
            continuousReplyPending = true
            return
        }
        continuousRestartTask?.cancel()
        continuousReplyPending = false
        captureUsesTapToStop = true
        inputFocused = false
        companion.markVoiceListeningStarted()
        companion.beginVoiceCapture()
        speechCapture.start(
            maximumDuration: 120,
            autoFinishAfterSilence: true,
            onComplete: { handleCapturedSpeech($0) },
            onInterrupted: { handleInterruptedSpeech($0) },
            onSpeechDetected: {
                continuousIdleTask?.cancel()
                continuousIdleTask = nil
            }
        )
        scheduleContinuousSilenceTimeout()
    }

    private func continueContinuousVoiceIfReady() {
        guard continuousTalkActive, continuousReplyPending,
              !companion.isSending, !companion.isSpeakingReply,
              !speechCapture.isRecording, !speechCapture.isPreparing else { return }
        continuousReplyPending = false
        continuousRestartTask?.cancel()
        continuousRestartTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(100))
            guard !Task.isCancelled else { return }
            startContinuousCapture()
        }
    }

    private func stopAnnaSpeakingAndResumeListening() {
        guard companion.isSpeakingReply else { return }
        continuousReplyPending = continuousTalkActive
        companion.stopSpeakingReplyByUser()
        if continuousTalkActive { continueContinuousVoiceIfReady() }
    }

    private func scheduleContinuousSilenceTimeout() {
        continuousIdleTask?.cancel()
        continuousIdleTask = Task { @MainActor in
            try? await Task.sleep(for: .seconds(30))
            guard !Task.isCancelled, continuousTalkActive else { return }
            stopContinuousVoice(discardRecording: true)
            showingImmersiveVoice = false
            companion.finishContinuousVoiceSession()
        }
    }

    private func stopContinuousVoice(discardRecording: Bool) {
        continuousTalkActive = false
        continuousReplyPending = false
        continuousRestartTask?.cancel()
        continuousRestartTask = nil
        continuousIdleTask?.cancel()
        continuousIdleTask = nil
        if companion.isSpeakingReply { companion.stopSpeakingReply() }
        if bargeInCaptureActive {
            bargeInCaptureActive = false
            bargeInTriggered = false
        }
        if speechCapture.isRecording || speechCapture.isPreparing {
            if discardRecording { speechCapture.cancel() }
            else {
                ignoreNextEmptyVoiceResult = true
                speechCapture.finish()
            }
        }
    }
}

private struct AnnaImmersiveVoiceScreen: View {
    private enum TurnState: Equatable {
        case speaking
        case listening
        case thinking
    }

    @ObservedObject var companion: AnnaPhoneViewModel
    @ObservedObject var speechCapture: AnnaSpeechCapture
    let isActive: Bool
    let thinkingBudgetExceeded: Bool
    let onStart: () -> Void
    let onStopSpeaking: () -> Void
    let onDone: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var showingTranscript = false

    private let background = Color(red: 0.035, green: 0.045, blue: 0.09)

    private var turnState: TurnState {
        if companion.isSpeakingReply { return .speaking }
        if companion.isThinking || companion.isSending || speechCapture.isFinishing { return .thinking }
        return .listening
    }

    private var statusText: String {
        switch turnState {
        case .speaking:
            return "Anna is speaking. Tap Stop Anna when you’re ready."
        case .thinking:
            return thinkingBudgetExceeded ? "Still thinking, one moment" : "Thinking"
        case .listening:
            return speechCapture.isPreparing ? "Connecting to microphone" : "I’m listening"
        }
    }

    private var orbExpression: CharmExpression {
        switch turnState {
        case .speaking: return .happy
        case .thinking: return .thinking
        case .listening: return .listening
        }
    }

    var body: some View {
        GeometryReader { geometry in
            let orbSize = min(min(geometry.size.width * 0.72, geometry.size.height * 0.48), 330)

            ZStack {
                background.ignoresSafeArea()
                RadialGradient(
                    colors: [Color.pink.opacity(0.17), .clear],
                    center: .center,
                    startRadius: 20,
                    endRadius: max(geometry.size.width, geometry.size.height) * 0.72
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    HStack {
                        Image(systemName: "waveform")
                            .foregroundStyle(Color.pink.opacity(0.9))
                        Text("ANNA · VOICE")
                            .font(.caption.weight(.bold))
                            .tracking(2)
                            .foregroundStyle(.white.opacity(0.66))
                        Spacer()
                        Button("Transcript") {
                            withAnimation(reduceMotion ? .none : .easeInOut(duration: 0.2)) {
                                showingTranscript.toggle()
                            }
                        }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.82))
                        .accessibilityHint(showingTranscript ? "Shows Anna’s orb" : "Shows the recent conversation transcript")
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 18)

                    Spacer(minLength: 4)

                    if showingTranscript {
                        transcriptPanel
                            .frame(maxWidth: 620, maxHeight: geometry.size.height * 0.58)
                            .transition(reduceMotion ? .opacity : .move(edge: .top).combined(with: .opacity))
                    } else {
                        ZStack {
                            ForEach(0..<3, id: \.self) { ring in
                                Circle()
                                    .stroke(Color.pink.opacity(speechCapture.isRecording ? 0.2 : 0.08), lineWidth: 1)
                                    .frame(width: orbSize + CGFloat(44 + ring * 34), height: orbSize + CGFloat(44 + ring * 34))
                                    .scaleEffect(speechCapture.isRecording
                                        ? 1 + CGFloat(speechCapture.audioLevel) * (0.25 + CGFloat(ring) * 0.06)
                                        : 1)
                                    .opacity(speechCapture.isRecording ? max(0.12, 0.72 - Double(ring) * 0.16) : 0.5)
                                    .animation(reduceMotion ? .easeOut(duration: 0.18) : .easeOut(duration: 0.24), value: speechCapture.audioLevel)
                                    .accessibilityHidden(true)
                            }
                            AnnaCharacterView(expression: orbExpression, showsFace: true)
                                .frame(width: orbSize, height: orbSize)
                                .shadow(color: Color.pink.opacity(companion.isSpeakingReply ? 0.4 : 0.2), radius: companion.isSpeakingReply ? 32 : 18)
                                .animation(reduceMotion ? .easeOut(duration: 0.12) : .easeInOut(duration: 0.24), value: orbExpression)
                                .accessibilityLabel("Anna, voice conversation")
                                .accessibilityHint(companion.isSpeakingReply
                                    ? "Stops Anna speaking and returns to your turn."
                                    : "Ends the voice conversation.")
                                .accessibilityAddTraits(.isButton)
                                .accessibilityAction {
                                    if companion.isSpeakingReply { onStopSpeaking() }
                                    else { onDone() }
                                }
                                .contentShape(Circle())
                                .onTapGesture {
                                    if companion.isSpeakingReply { onStopSpeaking() }
                                    else { onDone() }
                                }
                        }
                        .frame(maxWidth: .infinity)
                        .transition(.opacity)
                    }

                    Text(statusText)
                        .font(.system(size: 21, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                        .contentTransition(.opacity)
                        .accessibilityAddTraits(.updatesFrequently)

                    if speechCapture.isRecording || speechCapture.isPreparing {
                        HStack(spacing: 8) {
                            Image(systemName: "mic.fill")
                                .foregroundStyle(.pink)
                            Text(speechCapture.transcript.isEmpty ? "Speak naturally. Anna is listening." : speechCapture.transcript)
                                .font(.body)
                                .foregroundStyle(.white.opacity(0.82))
                                .lineLimit(3)
                                .multilineTextAlignment(.center)
                        }
                        .padding(.horizontal, 28)
                        .frame(minHeight: 42)
                    } else if companion.isSpeakingReply || companion.isThinking || companion.isSending {
                        Text(companion.streamingReply.isEmpty
                            ? (companion.messages.last(where: { $0.role == .anna })?.text ?? "")
                            : companion.streamingReply)
                            .font(.body)
                            .foregroundStyle(.white.opacity(0.82))
                            .multilineTextAlignment(.center)
                            .lineLimit(4)
                            .padding(.horizontal, 28)
                            .frame(minHeight: 42)
                    } else {
                        Text("Your words will appear here as text.")
                            .font(.footnote)
                            .foregroundStyle(.white.opacity(0.58))
                            .frame(minHeight: 42)
                    }

                    Spacer(minLength: 4)

                    Button {
                        if turnState == .speaking { onStopSpeaking() }
                        else { onDone() }
                    } label: {
                        Label(turnState == .speaking ? "Stop Anna" : "Done",
                              systemImage: turnState == .speaking ? "stop.fill" : "xmark")
                            .font(.system(size: 17, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 58)
                            .background(Color(red: 0.72, green: 0.22, blue: 0.48), in: Capsule())
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 28)
                    .padding(.bottom, max(16, geometry.safeAreaInsets.bottom + 8))
                    .accessibilityHint(turnState == .speaking
                        ? "Stops Anna speaking now and returns to listening."
                        : "Ends the voice conversation and stops listening.")
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .contentShape(Rectangle())
            .simultaneousGesture(
                DragGesture(minimumDistance: 30)
                    .onEnded { value in
                        guard abs(value.translation.height) > abs(value.translation.width) else { return }
                        withAnimation(reduceMotion ? .none : .easeInOut(duration: 0.2)) {
                            if value.translation.height < -30 { showingTranscript = true }
                            if value.translation.height > 30 { showingTranscript = false }
                        }
                    }
            )
        }
        .preferredColorScheme(.dark)
        .onAppear {
            if isActive && !speechCapture.isRecording && !speechCapture.isPreparing { onStart() }
        }
    }

    private var transcriptPanel: some View {
        ScrollViewReader { (proxy: ScrollViewProxy) in
            transcriptScrollView(proxy: proxy)
        }
    }

    private var recentTranscriptMessages: [AnnaChatLine] {
        Array(companion.messages.suffix(12))
    }

    private func transcriptScrollView(proxy: ScrollViewProxy) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                ForEach(recentTranscriptMessages) { message in
                    AnnaImmersiveTranscriptRow(message: message)
                }
                if !speechCapture.transcript.isEmpty {
                    AnnaImmersiveTranscriptLine(label: "You", text: speechCapture.transcript, tint: .white.opacity(0.84))
                }
                if !companion.streamingReply.isEmpty {
                    AnnaImmersiveTranscriptLine(label: "Anna", text: companion.streamingReply, tint: .white)
                }
                Color.clear.frame(height: 1).id("anna-transcript-bottom")
            }
            .padding(18)
        }
        .background(Color.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 24))
        .onChange(of: companion.messages.count) { _, _ in
            withAnimation(reduceMotion ? .none : .easeOut(duration: 0.18)) {
                proxy.scrollTo("anna-transcript-bottom", anchor: .bottom)
            }
        }
    }
}

private struct AnnaImmersiveTranscriptRow: View {
    let message: AnnaChatLine

    private var isUser: Bool { message.role == .user }
    private var alignment: HorizontalAlignment { isUser ? .trailing : .leading }
    private var frameAlignment: Alignment { isUser ? .trailing : .leading }
    private var bubbleColor: Color { isUser ? .pink.opacity(0.24) : .white.opacity(0.08) }

    var body: some View {
        VStack(alignment: alignment, spacing: 4) {
            Text(isUser ? "You" : "Anna")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.54))
            Text(message.text)
                .font(.body)
                .foregroundStyle(.white)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: frameAlignment)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: frameAlignment)
        .background(bubbleColor, in: RoundedRectangle(cornerRadius: 17))
        .id(message.id)
    }
}

private struct AnnaImmersiveTranscriptLine: View {
    let label: String
    let text: String
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.54))
            Text(text)
                .font(.body)
                .foregroundStyle(tint)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct AnnaRichMessageContent: View {
    private enum Content {
        case markdown(String)
        case code(String)
        case table([[String]])
    }

    private struct Block: Identifiable {
        let id: Int
        let content: Content
    }

    let text: String

    private var blocks: [Block] {
        let lines = text.components(separatedBy: .newlines)
        var result: [Block] = []
        var index = 0
        var markdownBuffer: [String] = []

        func flushMarkdown() {
            let value = markdownBuffer.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty { result.append(Block(id: result.count, content: .markdown(value))) }
            markdownBuffer.removeAll(keepingCapacity: true)
        }

        while index < lines.count {
            let line = lines[index]
            if line.trimmingCharacters(in: .whitespaces).hasPrefix("```") {
                flushMarkdown()
                index += 1
                var code: [String] = []
                while index < lines.count, !lines[index].trimmingCharacters(in: .whitespaces).hasPrefix("```") {
                    code.append(lines[index])
                    index += 1
                }
                result.append(Block(id: result.count, content: .code(code.joined(separator: "\n"))))
                index += index < lines.count ? 1 : 0
                continue
            }
            if line.contains("|"), index + 1 < lines.count,
               lines[index + 1].contains("-"), lines[index + 1].contains("|") {
                flushMarkdown()
                var rows: [[String]] = []
                while index < lines.count, lines[index].contains("|") {
                    let cells = lines[index].trimmingCharacters(in: .whitespaces)
                        .split(separator: "|")
                        .map { String($0).trimmingCharacters(in: .whitespaces) }
                    let isSeparator = !cells.isEmpty && cells.allSatisfy { $0.allSatisfy { $0 == "-" || $0 == ":" || $0 == " " } }
                    if !isSeparator { rows.append(cells) }
                    index += 1
                }
                if !rows.isEmpty { result.append(Block(id: result.count, content: .table(rows))) }
                continue
            }
            markdownBuffer.append(line)
            index += 1
        }
        flushMarkdown()
        return result
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(blocks) { block in
                switch block.content {
                case .markdown(let source):
                    let richText = (try? AttributedString(markdown: source)) ?? AttributedString(source)
                    Text(richText)
                        .font(.system(size: 15, design: .rounded))
                        .foregroundStyle(.white.opacity(0.96))
                        .fixedSize(horizontal: false, vertical: true)
                case .code(let source):
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("Code")
                                .font(.system(size: 10, weight: .semibold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.62))
                            Spacer()
                            Button("Copy") { UIPasteboard.general.string = source }
                                .font(.system(size: 10, weight: .semibold, design: .rounded))
                                .foregroundStyle(Color(red: 0.73, green: 0.82, blue: 1))
                        }
                        ScrollView(.horizontal) {
                            Text(source)
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundStyle(.white.opacity(0.92))
                                .textSelection(.enabled)
                        }
                        .scrollIndicators(.hidden)
                    }
                    .padding(9)
                    .background(.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 10))
                case .table(let rows):
                    ScrollView(.horizontal) {
                        VStack(alignment: .leading, spacing: 0) {
                            ForEach(Array(rows.enumerated()), id: \.offset) { rowIndex, row in
                                HStack(alignment: .top, spacing: 0) {
                                    ForEach(Array(row.enumerated()), id: \.offset) { _, cell in
                                        Text(cell)
                                            .font(.system(size: 12, weight: rowIndex == 0 ? .semibold : .regular, design: .rounded))
                                            .foregroundStyle(.white.opacity(rowIndex == 0 ? 1 : 0.88))
                                            .frame(minWidth: 100, maxWidth: 190, alignment: .leading)
                                            .padding(7)
                                    }
                                }
                                .background(rowIndex == 0 ? .white.opacity(0.10) : .white.opacity(0.035))
                            }
                        }
                    }
                    .scrollIndicators(.hidden)
                    .clipShape(RoundedRectangle(cornerRadius: 9))
                }
            }
        }
        .fixedSize(horizontal: false, vertical: true)
    }
}

private struct AnnaConversationDrawer: View {
    let conversations: [AnnaConversation]
    let activeConversationID: UUID?
    let openLoopCount: Int
    let onSelect: (UUID) -> Void
    let onNewConversation: () -> Void
    let onRename: (UUID, String) -> Void
    let onDelete: (UUID) -> Void
    let onSettings: () -> Void
    let onOpenLoops: () -> Void

    @State private var renameTarget: UUID?
    @State private var renameText = ""

    private var orderedConversations: [AnnaConversation] {
        conversations.sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 11) {
                AnnaCharacterView(expression: .happy, showsFace: false)
                    .frame(width: 44, height: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Anna")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("A little voice by your side")
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.65))
                }
            }
            .padding(.top, 12)
            .padding(.bottom, 18)

            Button(action: onNewConversation) {
                Label("New conversation", systemImage: "square.and.pencil")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .background(Color(red: 0.82, green: 0.30, blue: 0.55).opacity(0.28), in: RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)

            Text("RECENT")
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1.3)
                .foregroundStyle(.white.opacity(0.5))
                .padding(.top, 22)
                .padding(.bottom, 8)

            ScrollView {
                LazyVStack(spacing: 5) {
                    ForEach(orderedConversations) { conversation in
                        Button { onSelect(conversation.id) } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                HStack(alignment: .firstTextBaseline) {
                                    Text(conversation.title)
                                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                                        .lineLimit(1)
                                    Spacer(minLength: 5)
                                    Text(Self.relativeTime(conversation.updatedAt))
                                        .font(.system(size: 10, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.5))
                                        .lineLimit(1)
                                }
                                Text(conversation.preview)
                                    .font(.system(size: 11, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.62))
                                    .lineLimit(2)
                                    .multilineTextAlignment(.leading)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 11)
                            .padding(.vertical, 10)
                            .background(
                                activeConversationID == conversation.id ? .white.opacity(0.12) : .clear,
                                in: RoundedRectangle(cornerRadius: 12)
                            )
                            .contentShape(RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(.white)
                        .accessibilityElement(children: .combine)
                        .accessibilityLabel("\(conversation.title), \(conversation.preview), \(Self.relativeTime(conversation.updatedAt))")
                        .contextMenu {
                            Button("Rename", systemImage: "pencil") {
                                renameText = conversation.title
                                renameTarget = conversation.id
                            }
                            Button("Delete", systemImage: "trash", role: .destructive) {
                                onDelete(conversation.id)
                            }
                        }
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) { onDelete(conversation.id) } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                }
            }
            .scrollIndicators(.hidden)

            Button(action: onOpenLoops) {
                Label("Open loops · \(openLoopCount)", systemImage: "checklist")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 13)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white.opacity(0.9))

            Button(action: onSettings) {
                Label("Settings", systemImage: "gearshape")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white.opacity(0.9))
            .overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.12)).frame(height: 1) }
        }
        .padding(.horizontal, 16)
        .frame(maxHeight: .infinity)
        .background(Color(red: 0.055, green: 0.07, blue: 0.13).ignoresSafeArea())
        .shadow(color: .black.opacity(0.35), radius: 24, x: 12)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Conversation navigation menu")
        .alert("Rename conversation", isPresented: Binding(
            get: { renameTarget != nil },
            set: { if !$0 { renameTarget = nil } }
        )) {
            TextField("Conversation title", text: $renameText)
            Button("Cancel", role: .cancel) { renameTarget = nil }
            Button("Save") {
                if let renameTarget { onRename(renameTarget, renameText) }
                renameTarget = nil
            }
        }
    }

    private static func relativeTime(_ date: Date) -> String {
        RelativeDateTimeFormatter().localizedString(for: date, relativeTo: Date())
    }
}

private struct AnnaOpenLoopsSheet: View {
    @ObservedObject var companion: AnnaPhoneViewModel
    @Environment(\.dismiss) private var dismiss

    private var upcomingMemories: [AnnaMemoryItem] {
        companion.savedMemories.filter { item in
            guard let date = item.dueDate else { return false }
            return date >= Calendar.current.startOfDay(for: Date())
        }.sorted { ($0.dueDate ?? .distantFuture) < ($1.dueDate ?? .distantFuture) }
    }

    var body: some View {
        NavigationStack {
            List {
                if companion.openLoops.isEmpty && upcomingMemories.isEmpty {
                    ContentUnavailableView(
                        "Nothing open right now",
                        systemImage: "checkmark.circle",
                        description: Text("Active check-ins, focus sessions, today’s habits, and unfinished routine steps will appear here.")
                    )
                    .listRowBackground(Color.clear)
                }
                if !companion.openLoops.isEmpty {
                    Section("Needs attention") {
                        ForEach(companion.openLoops) { loop in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(loop.title).font(.headline)
                                Text(loop.detail).font(.subheadline).foregroundStyle(.secondary)
                                actionControl(for: loop)
                            }
                            .padding(.vertical, 5)
                        }
                    }
                }
                if !upcomingMemories.isEmpty {
                    Section("Coming up") {
                        ForEach(upcomingMemories) { memory in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(memory.text)
                                if let dueDate = memory.dueDate {
                                    Text(dueDate.formatted(date: .abbreviated, time: .omitted))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .padding(.vertical, 3)
                        }
                    }
                }
                Section {
                    Text("Anna shows the local commitments she can track here. System reminders remain in your reminders app.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color(red: 0.035, green: 0.045, blue: 0.09))
            .navigationTitle("Open loops")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    @ViewBuilder
    private func actionControl(for loop: AnnaOpenLoop) -> some View {
        switch loop.action {
        case .acknowledgeCheckIn:
            HStack {
                Button("I’m okay") { companion.confirmSafetyCheckIn() }
                    .buttonStyle(.borderedProminent)
                Button("Cancel check-in", role: .destructive) { companion.cancelSafetyCheckInNow() }
                    .buttonStyle(.bordered)
            }
        case .cancelCheckIn:
            Button("Cancel check-in", role: .destructive) { companion.cancelSafetyCheckInNow() }
        case .endFocus:
            Button("End focus session") { companion.endFocusSessionNow() }
                .buttonStyle(.bordered)
        case .cancelTimer:
            Button("Cancel timer", role: .destructive) { companion.cancelAnnaTimer() }
                .buttonStyle(.bordered)
        case .completeHabit(let id):
            Button("Mark done today") { companion.completeHabit(id) }
                .buttonStyle(.borderedProminent)
        case .completeMilestone(let goalID, let milestoneID):
            Button("Complete this step") {
                companion.completeRoutineMilestone(goalID: goalID, milestoneID: milestoneID)
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

private struct AnnaShareCardView: View {
    let text: String
    let speaker: String

    private var quoteSize: CGFloat {
        text.count > 360 ? 30 : (text.count > 220 ? 36 : (text.count > 100 ? 42 : 50))
    }

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.045, blue: 0.09)
            Circle()
                .fill(Color(red: 0.82, green: 0.30, blue: 0.55).opacity(0.26))
                .frame(width: 800, height: 800)
                .blur(radius: 90)
                .offset(x: 420, y: -480)
            VStack(alignment: .leading, spacing: 34) {
                HStack(spacing: 18) {
                    AnnaCharacterView(expression: .happy, showsFace: true)
                        .frame(width: 112, height: 112)
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Anna")
                            .font(.system(size: 38, weight: .bold, design: .rounded))
                        Text("A little voice by your side")
                            .font(.system(size: 21, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.72))
                    }
                    Spacer(minLength: 0)
                }
                Spacer(minLength: 0)
                Text(speaker.uppercased())
                    .font(.system(size: 19, weight: .bold, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(Color(red: 1.0, green: 0.58, blue: 0.74))
                Text(text)
                    .font(.system(size: quoteSize, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
                HStack {
                    Text("A moment with Anna")
                    Spacer()
                    Text("ANNA")
                        .tracking(2)
                }
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.55))
            }
            .padding(72)
            .foregroundStyle(.white)
        }
        .clipShape(RoundedRectangle(cornerRadius: 48))
    }
}

private struct AnnaShareCardPreview: View {
    let image: UIImage

    var body: some View {
        VStack(spacing: 14) {
            Text("Your share card")
                .font(.title3.weight(.semibold))
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 430)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            Text("Preview includes only the selected message and Anna’s artwork. Health summaries and saved memories are not included.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            ShareLink(item: Image(uiImage: image), preview: SharePreview("A moment with Anna", image: Image(uiImage: image))) {
                Label("Share image", systemImage: "square.and.arrow.up")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .preferredColorScheme(.dark)
    }
}

private struct AnnaSettingsCapabilityRow: View {
    let title: String
    let detail: String
    let status: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(alignment: .firstTextBaseline) {
                Text(title).font(.subheadline.weight(.semibold))
                Spacer(minLength: 8)
                Text(status)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(status == "Unavailable" || status == "Brain needed" ? Color.orange : Color.secondary)
                    .multilineTextAlignment(.trailing)
            }
            Text(detail)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }
}

private struct AnnaSettingsSheet: View {
    @ObservedObject var companion: AnnaPhoneViewModel
    @ObservedObject var speechCapture: AnnaSpeechCapture
    let onStartVoice: () -> Void
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dismiss) private var dismiss
    @State private var confirmsMemoryClear = false
    @State private var memoryBeingEdited: AnnaMemoryItem?
    @State private var newHabitTitle = ""
    @State private var routineBeingEdited: AnnaRecurringGoal?
    @State private var newRoutineTitle = ""
    @State private var newRoutineCadence: AnnaRecurringCadence = .weekly
    @State private var focusMinutes = "25"
    @State private var checkInMinutes = "40"

    private let background = Color(red: 0.035, green: 0.045, blue: 0.09)

    var body: some View {
        NavigationStack {
            Form {
                Section("Anna’s brain") {
                    if let model = companion.selectedModel {
                        LabeledContent("Current brain", value: model.name)
                        LabeledContent("Version", value: model.releaseVersion)
                        LabeledContent("Storage", value: companion.selectedBrainStorageDescription)
                        LabeledContent(
                            "Anna’s personality",
                            value: AnnaPersonalityPack.bundleIsVerified ? "Version \(AnnaPersonalityPack.current.version), verified" : "Needs repair"
                        )

                        if companion.isBrainUpdateFeedConfigured {
                            Toggle("Update Anna automatically", isOn: $companion.automaticBrainUpdatesEnabled)
                            Toggle("Wi-Fi only", isOn: $companion.brainUpdatesWiFiOnly)

                            Button {
                                Task { await companion.checkForBrainUpdates() }
                            } label: {
                                if companion.isCheckingBrainUpdates {
                                    Label("Checking for updates…", systemImage: "arrow.triangle.2.circlepath")
                                } else {
                                    Label("Check for updates", systemImage: "arrow.clockwise")
                                }
                            }
                            .disabled(companion.isCheckingBrainUpdates || companion.isLoadingModel)

                            Text(companion.brainUpdateStatus)
                                .font(.footnote)
                                .foregroundStyle(.secondary)

                            if let update = companion.availableBrainUpdate {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("Anna Max · \(update.releaseVersion)")
                                        .font(.subheadline.weight(.semibold))
                                    Text("\(update.formattedDownloadSize) · \(update.changelog ?? update.summary)")
                                        .font(.footnote)
                                        .foregroundStyle(.secondary)
                                    if companion.isLoadingModel {
                                        ProgressView(value: companion.downloadProgress)
                                        Text(companion.modelPreparationStatus)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    } else {
                                        Button("Update Anna Max") {
                                            companion.installAvailableBrainUpdate()
                                        }
                                    }
                                }
                            }
                        }

                        Link("Model details and license", destination: model.modelCardURL)
                    }
                    Text(companion.modelLoadDiagnostics)
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                    Text(companion.performanceDiagnostics)
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                    if !companion.recentPerformanceDiagnostics.isEmpty {
                        DisclosureGroup("Recent generation timings") {
                            ForEach(Array(companion.recentPerformanceDiagnostics.enumerated()), id: \.offset) { index, sample in
                                Text("\(index + 1). \(sample)")
                                    .font(.caption.monospacedDigit())
                                    .foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                }

                Section("Permissions") {
                    AnnaPermissionActionRow(
                        title: "Voice input",
                        explanation: "Use speech recognition and the microphone when you choose to talk.",
                        enabledTitle: "Voice input ready",
                        status: speechCapture.permissionStatus,
                        requestTitle: "Enable voice input",
                        deniedTitle: "Voice input off",
                        onRequest: { Task { _ = await speechCapture.requestPermissions() } },
                        onSuccess: companion.permissionSuccessFeedback,
                        onActionFeedback: companion.permissionTapFeedback
                    )
                    AnnaPermissionActionRow(
                        title: "Notifications",
                        explanation: "Allow local check-ins and scheduled briefings.",
                        enabledTitle: "Notifications on",
                        status: companion.notificationPermissionStatus,
                        isRequesting: companion.isRequestingNotificationPermission,
                        requestTitle: "Allow notifications",
                        deniedTitle: "Notifications off",
                        onRequest: { Task { await companion.requestProactiveNotificationAccess() } },
                        onSuccess: companion.permissionSuccessFeedback,
                        onActionFeedback: companion.permissionTapFeedback
                    )
                    AnnaPermissionActionRow(
                        title: "Health",
                        explanation: "Read optional steps, sleep, and workout summaries.",
                        enabledTitle: "Health request complete",
                        detailOverride: companion.healthStatus,
                        status: companion.healthPermissionStatus,
                        isRequesting: companion.isRequestingHealthPermission,
                        requestTitle: "Connect read-only Health",
                        deniedTitle: "Health access not confirmed",
                        onRequest: { companion.setHealthIntegrationEnabled(true) },
                        onSuccess: {},
                        onActionFeedback: companion.permissionTapFeedback
                    )
                    AnnaPermissionActionRow(
                        title: "Calendar and reminders",
                        explanation: "Read your schedule for requested briefings. Anna asks before creating reminders.",
                        enabledTitle: "Calendar and reminders connected",
                        detailOverride: companion.planningStatus,
                        status: companion.planningPermissionStatus,
                        isRequesting: companion.isRequestingPlanningPermission,
                        requestTitle: "Connect Calendar and Reminders",
                        deniedTitle: "Calendar and reminders off",
                        onRequest: { companion.planningContextEnabled = true },
                        onSuccess: companion.permissionSuccessFeedback,
                        onActionFeedback: companion.permissionTapFeedback
                    )
                    LabeledContent("iCloud sync", value: companion.iCloudSyncEnabled ? "On" : "Paused")
                    Text("Location is not used by this version. You can change granted access in iPhone Settings at any time.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("What Anna can do") {
                    AnnaSettingsCapabilityRow(
                        title: "Private chat",
                        detail: "Replies are generated on this iPhone when a brain is ready.",
                        status: companion.isSelectedModelReady ? "Ready" : "Brain needed"
                    )
                    AnnaSettingsCapabilityRow(
                        title: "Free search",
                        detail: companion.liveSearchStatus,
                        status: "No key needed"
                    )
                    AnnaSettingsCapabilityRow(
                        title: "Voice conversations",
                        detail: "Speak with Anna, then let her listen again after each reply.",
                        status: speechCapture.permissionStatus == .enabled ? "Ready" : "Permission needed"
                    )
                    Button("Try a voice conversation", action: startVoiceFromGallery)
                    AnnaSettingsCapabilityRow(
                        title: "Saved notes and chat memory",
                        detail: "Review, edit, or delete saved notes. Chats sync only if iCloud sync is on.",
                        status: "On this iPhone"
                    )
                    Button("Review goals and routines") {
                        companion.beginGoalInterview(force: true)
                        dismiss()
                    }
                    AnnaSettingsCapabilityRow(
                        title: "Health summaries",
                        detail: "Optional read-only steps, sleep, and workout summaries.",
                        status: companion.healthIntegrationEnabled ? "Connected" : "Optional"
                    )
                    AnnaSettingsCapabilityRow(
                        title: "Briefings and check-ins",
                        detail: "Local schedules, focus timers, wind-down, and requested check-ins.",
                        status: companion.proactiveEnabled ? "On" : "Paused"
                    )
                    AnnaSettingsCapabilityRow(
                        title: "Apple Watch",
                        detail: "A glanceable companion that uses the iPhone for full AI replies.",
                        status: !companion.watchPaired ? "Not paired" : (companion.watchAppInstalled ? "Installed" : "App not installed")
                    )
                    AnnaSettingsCapabilityRow(
                        title: "Private device sync",
                        detail: "Chats and photos can sync through your private iCloud space.",
                        status: companion.iCloudSyncEnabled ? "On" : "Paused"
                    )
                }

                Section("Voice") {
                    Toggle("Speak Anna’s replies", isOn: Binding(
                        get: { companion.speaksReplies },
                        set: { companion.setSpeaksReplies($0) }
                    ))
                    Toggle("Continuous voice conversations", isOn: $companion.continuousVoiceEnabled)
                    Text("This starts only when you tap Keep talking. Anna listens again after each reply and stops after about thirty seconds of silence.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Text("Anna uses the built-in voice unless you choose an available Personal Voice.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    if !companion.availableEnglishSpeechVoices.isEmpty {
                        Picker("Built-in English voice", selection: $companion.selectedSpeechVoiceIdentifier) {
                            ForEach(companion.availableEnglishSpeechVoices, id: \.identifier) { voice in
                                Text("\(voice.name) · \(voice.language)").tag(voice.identifier)
                            }
                        }
                        .disabled(companion.personalVoiceEnabled)
                        Button("Preview selected voice") { companion.previewSelectedSpeechVoice() }
                            .disabled(companion.quietMode)
                    }
                    if companion.personalVoiceAvailable {
                        Button {
                            companion.setPersonalVoiceEnabled(true)
                        } label: {
                            Label(
                                companion.personalVoiceEnabled ? "Personal Voice · Selected" : "Use Personal Voice",
                                systemImage: companion.personalVoiceEnabled ? "checkmark.circle.fill" : "person.wave.2"
                            )
                        }
                        Button("Use built-in voice") {
                            companion.setPersonalVoiceEnabled(false)
                        }
                    } else {
                        Text("To use your own voice, create a Personal Voice in Settings › Accessibility › Personal Voice, then allow apps to request it. Anna does not train or upload a voice model.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                        if #available(iOS 17.0, *) {
                            Button("Check Personal Voice access") {
                                companion.requestPersonalVoiceAccess()
                            }
                        }
                    }
                    Text(companion.personalVoiceStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("How Anna helps") {
                    Picker("Default style", selection: Binding(
                        get: { companion.helpPreferences.selectedStyle },
                        set: { companion.setHelpPreference($0) }
                    )) {
                        Text("Automatic").tag(nil as AnnaHelpStyle?)
                        ForEach(AnnaHelpStyle.allCases) { style in
                            Text(style.label).tag(Optional(style))
                        }
                    }
                    Text("Anna can learn whether you prefer listening, advice, or a next step from your feedback. This is stored on this iPhone and never trains or changes the model.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    if let learnedStyle = companion.helpPreferences.learnedStyle {
                        LabeledContent("Learned tendency", value: learnedStyle.label)
                        Text("Based on \(companion.helpPreferences.feedbackCount) feedback signals. You can change the default above or clear the learning below.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else {
                        Text("To teach Anna, long-press one of her replies and choose whether you wanted listening, advice, or a practical next step. You can change or clear that preference here.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Button("Clear learned preference") { companion.resetHelpLearning() }
                        .disabled(companion.helpPreferences.feedbackCount == 0)
                }

                Section("Proactive Anna") {
                    Toggle("Proactive Anna", isOn: Binding(
                        get: { companion.proactiveEnabled },
                        set: { companion.setProactiveEnabled($0) }
                    ))
                    Toggle("Quiet mode", isOn: Binding(
                        get: { companion.quietMode },
                        set: { companion.setQuietMode($0) }
                    ))
                    Text("One choice controls Anna’s local check-ins, scheduled briefings, and reminder follow-ups. Quiet mode silences her.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    if companion.proactiveEnabled {
                        DatePicker("Daily hello", selection: $companion.dailyCheckInTime, displayedComponents: .hourAndMinute)
                        DatePicker("Morning briefing", selection: $companion.morningBriefingTime, displayedComponents: .hourAndMinute)
                        DatePicker("Evening briefing", selection: $companion.eveningBriefingTime, displayedComponents: .hourAndMinute)

                        Text(companion.dailyCheckInStatus)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(companion.scheduledBriefingStatus)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        HStack {
                            Button("Morning briefing now") { companion.requestBriefing(.morning) }
                            Spacer(minLength: 8)
                            Button("Evening briefing now") { companion.requestBriefing(.evening) }
                        }
                        .font(.subheadline.weight(.semibold))
                    }
                }

                Section("Focus and check-ins") {
                    Text("Timers are saved on this iPhone and use local notifications. A check-in can remind you, but it cannot contact someone or share your location automatically.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Text(companion.focusSessionStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if companion.activeFocusSession == nil {
                        HStack {
                            TextField("25", text: $focusMinutes)
                                .keyboardType(.numberPad)
                                .frame(width: 70)
                            Text("minutes")
                            Spacer()
                            Button("Start focus") {
                                companion.startFocusSession(minutes: Int(focusMinutes) ?? 25)
                            }
                            .disabled(companion.isSending)
                        }
                    } else {
                        Button("End focus session") { companion.endFocusSessionNow() }
                        LabeledContent("Focus streak", value: "\(companion.focusStreak) days")
                    }

                    Text(companion.safetyCheckInStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if companion.safetyCheckIn == nil {
                        HStack {
                            TextField("40", text: $checkInMinutes)
                                .keyboardType(.numberPad)
                                .frame(width: 70)
                            Text("minutes")
                            Spacer()
                            Button("Set check-in") {
                                companion.startSafetyCheckIn(minutes: Int(checkInMinutes) ?? 40)
                            }
                        }
                    } else if let checkIn = companion.safetyCheckIn, !checkIn.isAcknowledged {
                        Button("I’m okay") { companion.confirmSafetyCheckIn() }
                        Button("Cancel check-in", role: .destructive) { companion.cancelSafetyCheckInNow() }
                    }

                    Toggle("Bedtime wind-down reminder", isOn: $companion.windDownEnabled)
                    Text(companion.windDownStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("Start a quiet wind-down now") { companion.startWindDownNow() }
                }

                if companion.sharedArticle != nil {
                    Section("Read to me") {
                        if let article = companion.sharedArticle {
                            Text(article.title).font(.subheadline.weight(.semibold))
                            Text(String(article.text.prefix(180)))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(3)
                            Picker("Reading speed", selection: $companion.articleSpeechRate) {
                                Text("Slower").tag(0.8)
                                Text("Natural").tag(1.0)
                                Text("Faster").tag(1.2)
                            }
                            .pickerStyle(.segmented)
                            if companion.isReadingArticle {
                                HStack {
                                    Button(companion.isArticlePaused ? "Resume" : "Pause") {
                                        if companion.isArticlePaused { companion.resumeReadingSharedArticle() }
                                        else { companion.pauseReadingSharedArticle() }
                                    }
                                    Button("Stop") { companion.stopReadingSharedArticle() }
                                }
                            } else {
                                Button("Read aloud on this iPhone") { companion.startReadingSharedArticle() }
                            }
                            Text(companion.articleReadingStatus.isEmpty ? "Shared text stays on this iPhone. Reading controls appear here." : companion.articleReadingStatus)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Button("Forget shared article", role: .destructive) { companion.forgetSharedArticle() }
                        }
                    }
                }

                if let receipt = companion.actionReceipt {
                    Section("Recent action") {
                        Label(receipt.title, systemImage: receipt.undoAction == nil ? "checkmark.circle.fill" : "checkmark.circle")
                        Text(receipt.detail)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                        if receipt.undoAction != nil {
                            Button(companion.isUndoingAction ? "Undoing…" : "Undo this change") {
                                companion.undoActionReceipt()
                            }
                            .disabled(companion.isUndoingAction)
                        }
                        Button("Dismiss receipt") { companion.dismissActionReceipt() }
                    }
                }

                Section("Goals and routines") {
                    Text("Goals and milestones stay on this iPhone. Routines are not system reminders. Anna will ask before creating or changing any reminder for them.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Button("Review or update goals with Anna") {
                        companion.beginGoalInterview(force: true)
                        dismiss()
                    }
                    if let target = companion.personalGoals.dailyStepTarget {
                        LabeledContent("Daily step goal", value: "\(target.formatted()) steps")
                        Button("Remove step goal", role: .destructive) {
                            companion.setDailyStepGoal(nil)
                        }
                    }
                    if let bedtime = companion.personalGoals.bedtimeMinuteOfDay,
                       let wakeTime = companion.personalGoals.wakeMinuteOfDay {
                        LabeledContent(
                            "Preferred sleep schedule",
                            value: "\(DateFormatter.localizedString(from: Calendar.current.date(from: DateComponents(hour: bedtime / 60, minute: bedtime % 60)) ?? Date(), dateStyle: .none, timeStyle: .short)) to \(DateFormatter.localizedString(from: Calendar.current.date(from: DateComponents(hour: wakeTime / 60, minute: wakeTime % 60)) ?? Date(), dateStyle: .none, timeStyle: .short))"
                        )
                        Button("Remove sleep schedule", role: .destructive) { companion.clearSleepGoal() }
                    }
                    if companion.personalGoals.recurringTasks.isEmpty {
                        Text("No recurring routines saved yet.").foregroundStyle(.secondary)
                    } else {
                        ForEach(companion.personalGoals.recurringTasks) { task in
                            Button {
                                routineBeingEdited = task
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(task.title)
                                            .foregroundStyle(.primary)
                                        let completed = task.milestones.filter { $0.completedAt != nil }.count
                                        Text("\(task.status.label) · \(task.cadence.label) · \(completed)/\(task.milestones.count) milestones")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint("Edit routine details, milestones, or its active state")
                        }
                    }
                    HStack {
                        TextField("A longer goal or routine", text: $newRoutineTitle)
                        Button("Add") {
                            companion.addRecurringGoal(newRoutineTitle, cadence: newRoutineCadence)
                            newRoutineTitle = ""
                        }
                        .disabled(newRoutineTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                    Picker("Repeats", selection: $newRoutineCadence) {
                        ForEach(AnnaRecurringCadence.allCases) { cadence in
                            Text(cadence.label).tag(cadence)
                        }
                    }
                }

                Section("Memory and health") {
                    Text("Anna keeps only notes you ask her to remember. They stay on this iPhone and can be reviewed or removed here.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    if companion.savedMemories.isEmpty {
                        Text("No saved notes yet").foregroundStyle(.secondary)
                    } else {
                        ForEach(companion.savedMemories) { memory in
                            HStack(alignment: .top, spacing: 10) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(memory.text).fixedSize(horizontal: false, vertical: true)
                                    Text("\(memory.kind.label) · saved \(memory.createdAt.formatted(date: .abbreviated, time: .shortened))")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 4)
                                Button {
                                    memoryBeingEdited = memory
                                } label: {
                                    Image(systemName: "pencil")
                                }
                                .accessibilityLabel("Edit saved note: \(memory.text)")
                                Button(role: .destructive) {
                                    companion.deleteSavedMemory(memory.id)
                                } label: {
                                    Image(systemName: "trash")
                                }
                                .accessibilityLabel("Forget saved note: \(memory.text)")
                            }
                        }
                        Button("Forget all saved notes", role: .destructive) {
                            confirmsMemoryClear = true
                        }
                    }

                    Text("Private habits")
                        .font(.headline)
                    HStack {
                        TextField("A small habit", text: $newHabitTitle)
                            .submitLabel(.done)
                        Button("Add") {
                            companion.addHabit(newHabitTitle)
                            newHabitTitle = ""
                        }
                        .disabled(newHabitTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                    if companion.habits.isEmpty {
                        Text("Add a gentle habit to track on this iPhone.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(companion.habits) { habit in
                        HStack {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(habit.title)
                                Text(habit.currentStreak == 1 ? "1-day streak" : "\(habit.currentStreak)-day streak")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button(companion.habitCompletedToday(habit) ? "Done today" : "Check in") {
                                companion.completeHabit(habit.id)
                            }
                            .disabled(companion.habitCompletedToday(habit))
                            Button(role: .destructive) {
                                companion.deleteHabit(habit.id)
                            } label: {
                                Image(systemName: "trash")
                            }
                            .accessibilityLabel("Delete habit \(habit.title)")
                        }
                    }

                    if companion.healthIntegrationEnabled {
                        if let summary = companion.healthSummary {
                            LabeledContent("Steps today", value: summary.stepsToday.formatted())
                            if let baseline = summary.stepsAverageLast7Days {
                                LabeledContent("7-day recorded average", value: baseline.formatted())
                                Text(summary.stepsTrendLabel)
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                            LabeledContent("Recent sleep", value: summary.sleepLabel)
                            LabeledContent("Workouts this week", value: summary.workoutsThisWeek.formatted())
                        }
                        Button {
                            Task { await companion.refreshHealthSummary() }
                        } label: {
                            if companion.isRefreshingHealth { ProgressView() }
                            else { Label("Refresh summary", systemImage: "arrow.clockwise") }
                        }
                        .disabled(companion.isRefreshingHealth)
                    }

                    Text("Calendar and Reminders")
                        .font(.headline)
                    if companion.planningContextEnabled && companion.planningPermissionStatus == .enabled {
                        Button("Refresh calendar and reminders") {
                            Task { await companion.refreshPlanningSummary() }
                        }
                        .disabled(companion.planningStatus.hasPrefix("Requesting"))
                    }
                    Text("Used locally for briefings; access is read-only.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Sounds and touch") {
                    Toggle("Orb sounds", isOn: Binding(
                        get: { companion.soundsEnabled },
                        set: { companion.setSoundsEnabled($0) }
                    ))
                    Toggle("Haptic feedback", isOn: Binding(
                        get: { companion.hapticsEnabled },
                        set: { companion.setHapticsEnabled($0) }
                    ))
                    Text("Anna’s gentle chimes and taps respect Quiet mode.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Sync across your devices") {
                    Toggle("Sync chats and photos from this iPhone", isOn: $companion.iCloudSyncEnabled)
                        .disabled(companion.isSyncingICloud)
                    Text("No Anna login is needed. Anna uses the same Apple Account on your iPhone and Apple Watch to sync privately. Sync starts automatically when iCloud is available. This switch pauses syncing from this iPhone only. Existing iCloud copies are not erased.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Text(companion.iCloudSyncStatus)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button {
                        Task { await companion.synchronizeICloudNow() }
                    } label: {
                        if companion.isSyncingICloud {
                            Label("Syncing…", systemImage: "icloud")
                        } else {
                            Label("Sync now", systemImage: "arrow.triangle.2.circlepath.icloud")
                        }
                    }
                    .disabled(!companion.iCloudSyncEnabled || companion.isSyncingICloud || companion.isSending)
                }

                Section("About") {
                    LabeledContent("Your brain", value: companion.selectedModel?.name ?? "Not downloaded")
                    LabeledContent(
                        "App version",
                        value: "\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "—") (\(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "—"))"
                    )
                    Text("Privacy: model replies, saved memories, and Health summaries stay on this iPhone unless you choose a cloud service. Chats and photos sync through your private iCloud space when sync is on. Model files are downloaded separately to each device.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Text("Siri and Shortcuts can start a conversation, prepare a briefing, save a note, and manage supported reminders. Shared article text can be summarized locally on this iPhone.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .confirmationDialog(
                "Forget all saved notes?",
                isPresented: $confirmsMemoryClear,
                titleVisibility: .visible
            ) {
                Button("Forget All Notes", role: .destructive) { companion.clearSavedMemories() }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("This permanently removes Anna’s saved notes from this iPhone.")
            }
            .sheet(item: $memoryBeingEdited) { memory in
                AnnaMemoryEditorSheet(memory: memory) { updatedText in
                    companion.updateSavedMemory(memory.id, text: updatedText)
                }
            }
            .sheet(item: $routineBeingEdited) { routine in
                AnnaRoutineEditorSheet(
                    routine: routine,
                    onSave: companion.updateRecurringGoal,
                    onDelete: { companion.deleteRecurringGoal(routine.id) }
                )
            }
            .scrollContentBackground(.hidden)
            .background(background)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
        }
        .background(background.ignoresSafeArea())
        .preferredColorScheme(.dark)
        .task { await refreshPermissions() }
        .onChange(of: scenePhase) { phase in
            if phase == .active { Task { await refreshPermissions() } }
        }
    }

    @MainActor
    private func refreshPermissions() async {
        speechCapture.refreshPermissionStatus()
        await companion.refreshPermissionStatuses()
    }

    private func startVoiceFromGallery() {
        dismiss()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            onStartVoice()
        }
    }
}

private struct AnnaRoutineEditorSheet: View {
    let routine: AnnaRecurringGoal
    let onSave: (AnnaRecurringGoal) -> Void
    let onDelete: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var cadence: AnnaRecurringCadence
    @State private var status: AnnaRoutineStatus
    @State private var milestones: [AnnaRoutineMilestone]
    @State private var newMilestoneTitle = ""
    @State private var targetDateEnabled = false
    @State private var targetDate = Date()
    @State private var confirmsDelete = false

    init(routine: AnnaRecurringGoal, onSave: @escaping (AnnaRecurringGoal) -> Void, onDelete: @escaping () -> Void) {
        self.routine = routine
        self.onSave = onSave
        self.onDelete = onDelete
        _title = State(initialValue: routine.title)
        _cadence = State(initialValue: routine.cadence)
        _status = State(initialValue: routine.status)
        _milestones = State(initialValue: routine.milestones)
    }

    private var cleanedTitle: String { title.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        NavigationStack {
            Form {
                Section("Routine") {
                    TextField("Name", text: $title)
                        .textInputAutocapitalization(.sentences)
                    Picker("Cadence", selection: $cadence) {
                        ForEach(AnnaRecurringCadence.allCases) { value in
                            Text(value.label).tag(value)
                        }
                    }
                    Picker("Status", selection: $status) {
                        ForEach(AnnaRoutineStatus.allCases) { value in
                            Text(value.label).tag(value)
                        }
                    }
                    Text("Pausing or archiving only changes this local routine. Anna will ask before creating or changing a system reminder.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Milestones") {
                    if milestones.isEmpty {
                        Text("Add small steps that make this longer goal feel manageable.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(milestones) { milestone in
                        HStack(spacing: 10) {
                            Button {
                                toggleMilestone(milestone.id)
                            } label: {
                                Image(systemName: milestone.completedAt == nil ? "circle" : "checkmark.circle.fill")
                                    .foregroundStyle(milestone.completedAt == nil ? .secondary : Color.accentColor)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(milestone.completedAt == nil ? "Mark \(milestone.title) complete" : "Mark \(milestone.title) incomplete")
                            VStack(alignment: .leading, spacing: 3) {
                                Text(milestone.title)
                                    .strikethrough(milestone.completedAt != nil)
                                if let date = milestone.targetDate {
                                    Text("Target \(date.formatted(date: .abbreviated, time: .omitted))")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Button(role: .destructive) { removeMilestone(milestone.id) } label: {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.borderless)
                            .accessibilityLabel("Delete milestone \(milestone.title)")
                        }
                    }
                    TextField("A small next step", text: $newMilestoneTitle)
                    Toggle("Add a target date", isOn: $targetDateEnabled)
                    if targetDateEnabled {
                        DatePicker("Target date", selection: $targetDate, in: Date()..., displayedComponents: .date)
                    }
                    Button("Add milestone", action: addMilestone)
                        .disabled(newMilestoneTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || milestones.count >= 30)
                }

                Section {
                    Button("Delete routine", role: .destructive) { confirmsDelete = true }
                }
            }
            .navigationTitle("Manage routine")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        var updated = routine
                        updated.title = cleanedTitle
                        updated.cadence = cadence
                        updated.status = status
                        updated.milestones = milestones
                        updated.updatedAt = Date()
                        onSave(updated)
                        dismiss()
                    }
                    .disabled(cleanedTitle.isEmpty || cleanedTitle.count > 100)
                }
            }
            .confirmationDialog("Delete this routine?", isPresented: $confirmsDelete, titleVisibility: .visible) {
                Button("Delete routine", role: .destructive) {
                    onDelete()
                    dismiss()
                }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("Its milestones will also be removed from this iPhone.")
            }
        }
        .presentationDetents([.medium, .large])
    }

    private func addMilestone() {
        let value = newMilestoneTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, milestones.count < 30 else { return }
        milestones.append(AnnaRoutineMilestone(title: value, targetDate: targetDateEnabled ? targetDate : nil))
        newMilestoneTitle = ""
    }

    private func toggleMilestone(_ id: UUID) {
        guard let index = milestones.firstIndex(where: { $0.id == id }) else { return }
        milestones[index].completedAt = milestones[index].completedAt == nil ? Date() : nil
    }

    private func removeMilestone(_ id: UUID) {
        milestones.removeAll { $0.id == id }
    }
}

private struct AnnaMemoryEditorSheet: View {
    let memory: AnnaMemoryItem
    let onSave: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var text: String

    init(memory: AnnaMemoryItem, onSave: @escaping (String) -> Void) {
        self.memory = memory
        self.onSave = onSave
        _text = State(initialValue: memory.text)
    }

    private var cleanedText: String {
        text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Saved note") {
                    TextEditor(text: $text)
                        .frame(minHeight: 150)
                    Text("Keep this note under 500 characters. It stays on this iPhone.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Edit memory")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        onSave(cleanedText)
                        dismiss()
                    }
                    .disabled(cleanedText.isEmpty || cleanedText.count > 500)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

private struct AnnaWelcomeFlow: View {
    @ObservedObject var companion: AnnaPhoneViewModel
    @ObservedObject var speechCapture: AnnaSpeechCapture
    @Environment(\.scenePhase) private var scenePhase
    @State private var page = 0
    private let background = Color(red: 0.035, green: 0.045, blue: 0.09)

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 18) {
                HStack {
                    Spacer()
                    Button("Skip setup") { finish() }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.75))
                }

                Spacer(minLength: 8)
                AnnaCharacterView(expression: .calm, showsFace: false)
                    .frame(width: min(geometry.size.width * 0.42, 170), height: min(geometry.size.width * 0.42, 170))
                    .accessibilityHidden(true)

                Text("Anna")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("A little voice by your side")
                    .font(.system(size: 16, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))

                Group {
                    switch page {
                    case 0:
                        firstPage
                    case 1:
                        permissionsPage
                    default:
                        finalPage
                    }
                }
                .frame(maxWidth: 460)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 22)
                .frame(maxHeight: 270)

                Spacer(minLength: 4)
                Text("\(page + 1) of 3")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.white.opacity(0.55))
                pageActions
            }
            .padding(.horizontal, 18)
            .padding(.top, 16)
            .padding(.bottom, max(18, geometry.safeAreaInsets.bottom + 8))
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(background.ignoresSafeArea())
        }
        .interactiveDismissDisabled()
        .preferredColorScheme(.dark)
        .task { await refreshPermissions() }
        .onChange(of: scenePhase) { phase in
            if phase == .active { Task { await refreshPermissions() } }
        }
    }

    @MainActor
    private func refreshPermissions() async {
        speechCapture.refreshPermissionStatus()
        await companion.refreshPermissionStatuses()
    }

    @ViewBuilder
    private var firstPage: some View {
        VStack(spacing: 12) {
            Text(companion.isSelectedModelReady ? "Her brain is ready" : "Meet Anna’s local brain")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text(companion.selectedModel?.summary ?? "Anna keeps her conversation on this iPhone.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.72))
            if companion.isLoadingModel {
                ProgressView(value: companion.downloadProgress)
                    .tint(Color(red: 0.96, green: 0.42, blue: 0.66))
                Text(companion.modelPreparationStatus)
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.7))
            } else if !companion.isSelectedModelReady {
                Button(companion.modelNeedsRedownload ? "Download Anna’s brain again" : "Download Anna’s brain") {
                    companion.loadSelectedModel()
                }
                .buttonStyle(.borderedProminent)
                .tint(Color(red: 0.78, green: 0.25, blue: 0.51))
                .disabled(companion.isRestoringModel)
            }
            Text("Download once to chat offline. You can continue while it downloads.")
                .font(.footnote)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.62))
        }
    }

    private var permissionsPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                Text("Optional ways to make Anna more helpful")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(.white)
                AnnaPermissionActionRow(
                    title: "Notifications",
                    explanation: "Daily hellos and scheduled briefings. Optional.",
                    enabledTitle: "Notifications on",
                    status: companion.notificationPermissionStatus,
                    isRequesting: companion.isRequestingNotificationPermission,
                    requestTitle: "Allow notifications",
                    deniedTitle: "Notifications off",
                    onRequest: { Task { await companion.requestProactiveNotificationAccess() } },
                    onSuccess: companion.permissionSuccessFeedback,
                    onActionFeedback: companion.permissionTapFeedback
                )
                AnnaPermissionActionRow(
                    title: "Voice input",
                    explanation: "Speak instead of typing. Optional.",
                    enabledTitle: "Voice input ready",
                    status: speechCapture.permissionStatus,
                    requestTitle: "Enable voice input",
                    deniedTitle: "Voice input off",
                    onRequest: { Task { _ = await speechCapture.requestPermissions() } },
                    onSuccess: companion.permissionSuccessFeedback,
                    onActionFeedback: companion.permissionTapFeedback
                )
                AnnaPermissionActionRow(
                    title: "Health",
                    explanation: "Read optional steps, sleep, and workout summaries.",
                    enabledTitle: "Health request complete",
                    detailOverride: companion.healthStatus,
                    status: companion.healthPermissionStatus,
                    isRequesting: companion.isRequestingHealthPermission,
                    requestTitle: "Connect read-only Health",
                    deniedTitle: "Health access not confirmed",
                    onRequest: { companion.setHealthIntegrationEnabled(true) },
                    onSuccess: {},
                    onActionFeedback: companion.permissionTapFeedback
                )
                AnnaPermissionActionRow(
                    title: "Calendar and reminders",
                    explanation: "Use your schedule in briefings. Optional and read-only.",
                    enabledTitle: "Calendar and reminders connected",
                    detailOverride: companion.planningStatus,
                    status: companion.planningPermissionStatus,
                    isRequesting: companion.isRequestingPlanningPermission,
                    requestTitle: "Connect Calendar and Reminders",
                    deniedTitle: "Calendar and reminders off",
                    onRequest: { companion.planningContextEnabled = true },
                    onSuccess: companion.permissionSuccessFeedback,
                    onActionFeedback: companion.permissionTapFeedback
                )
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var finalPage: some View {
        VStack(spacing: 12) {
            Text("Let’s make this useful from the start.")
                .font(.title3.weight(.semibold))
                .foregroundStyle(.white)
            Text(companion.isSelectedModelReady
                ? "I can help answer questions, keep notes you choose, and plan a useful next step. Your chat stays on this iPhone."
                : "Download my brain to chat offline. You can also explore voice, notes, and optional permissions in Settings.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.72))
            Text("Try asking: Help me plan one small thing for today.")
                .font(.footnote.weight(.medium))
                .multilineTextAlignment(.center)
                .foregroundStyle(Color(red: 1.0, green: 0.62, blue: 0.78))
        }
    }

    @ViewBuilder
    private var pageActions: some View {
        if page < 2 {
            Button(page == 0 ? "Continue" : "Meet Anna") {
                if page == 1 { page = 2 } else { page += 1 }
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(red: 0.78, green: 0.25, blue: 0.51))
            .padding(.bottom, 8)
        } else {
            VStack(spacing: 10) {
                Button("Ask Anna for a next step") {
                    companion.draft = "Help me plan one small thing for today."
                    finish()
                }
                .buttonStyle(.borderedProminent)
                .tint(Color(red: 0.78, green: 0.25, blue: 0.51))
                Button("Start with an empty chat") { finish() }
                    .buttonStyle(.plain)
                    .foregroundStyle(.white.opacity(0.76))
            }
            .padding(.bottom, 8)
        }
    }

    private func finish() {
        companion.hasCompletedOnboarding = true
    }
}

private struct AnnaPermissionActionRow: View {
    let title: String
    let explanation: String
    let enabledTitle: String
    var detailOverride: String? = nil
    let status: AnnaPermissionStatus
    var isRequesting = false
    let requestTitle: String
    let deniedTitle: String
    let onRequest: () -> Void
    let onSuccess: () -> Void
    var onActionFeedback: () -> Void = {}

    @State private var previousStatus: AnnaPermissionStatus

    init(
        title: String,
        explanation: String,
        enabledTitle: String,
        detailOverride: String? = nil,
        status: AnnaPermissionStatus,
        isRequesting: Bool = false,
        requestTitle: String,
        deniedTitle: String,
        onRequest: @escaping () -> Void,
        onSuccess: @escaping () -> Void,
        onActionFeedback: @escaping () -> Void = {}
    ) {
        self.title = title
        self.explanation = explanation
        self.enabledTitle = enabledTitle
        self.detailOverride = detailOverride
        self.status = status
        self.isRequesting = isRequesting
        self.requestTitle = requestTitle
        self.deniedTitle = deniedTitle
        self.onRequest = onRequest
        self.onSuccess = onSuccess
        self.onActionFeedback = onActionFeedback
        _previousStatus = State(initialValue: status)
    }

    private var displayedStatus: AnnaPermissionStatus {
        isRequesting ? .requesting : status
    }

    private var confirmed: Bool {
        displayedStatus == .enabled || displayedStatus == .requestComplete
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.subheadline.weight(.semibold))
            Text(detailText)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            switch displayedStatus {
            case .notRequested:
                Button {
                    onActionFeedback()
                    onRequest()
                } label: {
                    Label(requestTitle, systemImage: "hand.tap")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.bordered)
                .accessibilityHint(explanation)
            case .requesting:
                HStack(spacing: 9) {
                    ProgressView()
                    Text("Requesting access…")
                        .font(.subheadline.weight(.medium))
                    Spacer()
                }
                .padding(.vertical, 7)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Requesting \(title) access")
            case .enabled, .requestComplete:
                Label(enabledTitle, systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.green)
                    .padding(.vertical, 7)
                    .accessibilityAddTraits(.isStaticText)
            case .denied:
                Button {
                    onActionFeedback()
                    openAppSettings()
                } label: {
                    Label("\(deniedTitle) · Enable in Settings", systemImage: "gearshape")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.bordered)
                .tint(.orange)
                .accessibilityHint("Opens this app’s settings so you can change permission.")
            case .failed:
                Button {
                    onActionFeedback()
                    onRequest()
                } label: {
                    Label("Try again", systemImage: "arrow.clockwise")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.bordered)
            case .unavailable:
                Label("Unavailable on this device", systemImage: "minus.circle")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 7)
            }
        }
        .padding(11)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14))
        .overlay {
            RoundedRectangle(cornerRadius: 14)
                .strokeBorder(confirmed ? Color.green.opacity(0.32) : Color.white.opacity(0.08), lineWidth: 1)
        }
        .animation(.easeInOut(duration: 0.2), value: displayedStatus)
        .onChange(of: displayedStatus) { newStatus in
            let wasRequesting = previousStatus == .requesting
            previousStatus = newStatus
            if wasRequesting && (newStatus == .enabled || newStatus == .requestComplete) {
                onSuccess()
            }
        }
    }

    private var detailText: String {
        switch displayedStatus {
        case .notRequested: explanation
        case .requesting: "The system permission sheet is open. This row will update when it closes."
        case .enabled: detailOverride ?? "Anna can use this permission when you ask."
        case .requestComplete: detailOverride ?? explanation
        case .denied: detailOverride ?? "This permission is currently off. You can change it in Settings."
        case .unavailable: detailOverride ?? explanation
        case .failed: detailOverride ?? "The request did not finish. You can safely try again."
        }
    }

    private func openAppSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }
}

private struct AnnaWebSearchSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var query: String
    @State private var resultURL: URL?

    init(initialQuery: String) {
        _query = State(initialValue: initialQuery)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack(spacing: 8) {
                    TextField("What should I search for?", text: $query)
                        .textInputAutocapitalization(.sentences)
                        .autocorrectionDisabled()
                        .submitLabel(.search)
                        .onSubmit(search)
                        .padding(.horizontal, 13)
                        .frame(height: 46)
                        .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 13))
                        .accessibilityLabel("Web search terms")

                    Button(action: search) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 16, weight: .semibold))
                            .frame(width: 46, height: 46)
                            .background(Color(red: 0.82, green: 0.36, blue: 0.61), in: RoundedRectangle(cornerRadius: 13))
                    }
                    .buttonStyle(.plain)
                    .disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityLabel("Search DuckDuckGo")
                }
                .padding(.horizontal)
                .padding(.top, 12)

                Text("Free live results open right here. Anna does not automatically read the pages, but you can bring a link or copied text back to chat.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)

                if let resultURL {
                    AnnaSafariView(url: resultURL)
                        .id(resultURL)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .padding(.horizontal, 8)
                        .padding(.bottom, 8)
                } else {
                    ContentUnavailableSearchView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
            .background(Color(red: 0.035, green: 0.045, blue: 0.09).ignoresSafeArea())
            .navigationTitle("Search the Web")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .preferredColorScheme(.dark)
        .task {
            if !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                search()
            }
        }
    }

    private func search() {
        let trimmed = String(query.trimmingCharacters(in: .whitespacesAndNewlines).prefix(500))
        guard !trimmed.isEmpty else { return }
        var components = URLComponents(string: "https://duckduckgo.com/")
        components?.queryItems = [URLQueryItem(name: "q", value: trimmed)]
        resultURL = components?.url
    }
}

private struct ContentUnavailableSearchView: View {
    var body: some View {
        VStack(spacing: 9) {
            Image(systemName: "sparkle.magnifyingglass")
                .font(.system(size: 32))
                .foregroundStyle(Color(red: 0.93, green: 0.57, blue: 0.75))
            Text("What are you curious about?")
                .font(.headline)
            Text("Enter a phrase above and I’ll open the web results for you.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(28)
    }
}

private struct AnnaSafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ controller: SFSafariViewController, context: Context) {
        // Safari view controllers are intentionally replaced when the search URL changes.
    }
}
