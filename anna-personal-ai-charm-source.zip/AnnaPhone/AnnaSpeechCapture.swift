import AVFoundation
import Combine
import Foundation
import os
import Speech

@MainActor
final class AnnaSpeechCapture: ObservableObject {
    enum State: Equatable {
        case idle
        case preparing
        case recording
        case finishing
        case cancelled
    }

    @Published private(set) var state: State = .idle
    @Published private(set) var transcript = ""
    @Published private(set) var errorMessage: String?
    @Published private(set) var elapsedSeconds = 0.0
    @Published private(set) var audioLevel = 0.0
    @Published private(set) var lastRecognitionConfidence: Double?
    @Published private(set) var permissionStatus: AnnaPermissionStatus = .notRequested

    var isPreparing: Bool { state == .preparing }
    var isRecording: Bool { state == .recording }
    var isFinishing: Bool { state == .finishing }

    private let audioEngine = AVAudioEngine()
    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "Anna", category: "SpeechCapture")
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var completion: ((String) -> Void)?
    private var interruptedCompletion: ((String) -> Void)?
    private var speechActivityCallback: (() -> Void)?
    private var captureID = UUID()
    private var maximumTask: Task<Void, Never>?
    private var silenceTask: Task<Void, Never>?
    private var elapsedTask: Task<Void, Never>?
    private var finalizationTask: Task<Void, Never>?
    private var autoFinishAfterSilence = true
    private var pendingFinishOnStart = false
    private var inputTapInstalled = false
    private var completionDelivered = false
    private var preserveTranscriptOnFinish = false
    private var hasDetectedSpeech = false
    private var didSignalSpeechActivity = false
    private var speechAboveThresholdSince: Double?
    private var bargeInMode = false
    private var noiseFloorRMS = 0.001
    private var lastPublishedLevelAt = 0.0
    private var interruptionObserver: NSObjectProtocol?

    private let silenceWindow: Duration = .milliseconds(1_500)
    private let minimumSpeechRMS = 0.0035
    private let bargeInSpeechDuration = 0.24

    init() {
        interruptionObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance(),
            queue: .main
        ) { [weak self] notification in
            guard let rawType = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  AVAudioSession.InterruptionType(rawValue: rawType) == .began else { return }
            Task { @MainActor [weak self] in self?.interruptAndPreserveTranscript() }
        }
    }

    func requestPermissions() async -> Bool {
        guard permissionStatus != .requesting else { return false }
        permissionStatus = .requesting
        let speechAllowed = await requestSpeechAuthorization()
        let microphoneAllowed = await requestMicrophoneAuthorization()
        refreshPermissionStatus()
        return speechAllowed && microphoneAllowed
    }

    func refreshPermissionStatus() {
        let speech = SFSpeechRecognizer.authorizationStatus()
        let microphone = AVAudioSession.sharedInstance().recordPermission
        if speech == .authorized && microphone == .granted {
            permissionStatus = .enabled
        } else if speech == .denied || speech == .restricted || microphone == .denied {
            permissionStatus = .denied
        } else if speech == .notDetermined || microphone == .undetermined {
            permissionStatus = .notRequested
        } else {
            permissionStatus = .unavailable
        }
    }

    deinit {
        if let interruptionObserver {
            NotificationCenter.default.removeObserver(interruptionObserver)
        }
    }

    func start(
        maximumDuration: TimeInterval = 120,
        autoFinishAfterSilence: Bool = true,
        onComplete: @escaping (String) -> Void,
        onInterrupted: ((String) -> Void)? = nil,
        bargeInMode: Bool = false,
        onSpeechDetected: (() -> Void)? = nil
    ) {
        guard state == .idle || state == .cancelled else { return }
        captureID = UUID()
        let id = captureID
        completion = onComplete
        interruptedCompletion = onInterrupted
        speechActivityCallback = onSpeechDetected
        self.bargeInMode = bargeInMode
        completionDelivered = false
        preserveTranscriptOnFinish = false
        hasDetectedSpeech = false
        didSignalSpeechActivity = false
        speechAboveThresholdSince = nil
        noiseFloorRMS = 0.001
        lastPublishedLevelAt = 0
        transcript = ""
        lastRecognitionConfidence = nil
        errorMessage = nil
        elapsedSeconds = 0
        audioLevel = 0
        self.autoFinishAfterSilence = autoFinishAfterSilence
        state = .preparing

        Task { [weak self] in
            guard let self else { return }
            await self.prepareAndStart(id: id, maximumDuration: maximumDuration)
        }
    }

    private func prepareAndStart(id: UUID, maximumDuration: TimeInterval) async {
        let speechAuthorized = await requestSpeechAuthorization()
        guard id == captureID, state == .preparing else { return }
        guard speechAuthorized else {
            fail("Allow Speech Recognition to use voice input.")
            return
        }

        let microphoneAuthorized = await requestMicrophoneAuthorization()
        guard id == captureID, state == .preparing else { return }
        guard microphoneAuthorized else {
            fail("Allow microphone access to talk to Anna.")
            return
        }
        guard let recognizer, recognizer.isAvailable else {
            fail("Speech Recognition is temporarily unavailable. Please try again.")
            return
        }

        do {
            let session = AVAudioSession.sharedInstance()
            if bargeInMode {
                try session.setCategory(
                    .playAndRecord,
                    mode: .voiceChat,
                    options: [.defaultToSpeaker, .allowBluetooth, .duckOthers]
                )
            } else {
                try session.setCategory(.record, mode: .measurement, options: [.duckOthers])
            }
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            let request = SFSpeechAudioBufferRecognitionRequest()
            request.shouldReportPartialResults = true
            if recognizer.supportsOnDeviceRecognition {
                request.requiresOnDeviceRecognition = true
            }
            recognitionRequest = request

            let input = audioEngine.inputNode
            if bargeInMode {
                try input.setVoiceProcessingEnabled(true)
            }
            let format = input.outputFormat(forBus: 0)
            guard format.channelCount > 0, format.sampleRate > 0 else {
                throw CaptureError.invalidAudioFormat
            }
            let activityDispatchGate = AudioActivityDispatchGate(minimumInterval: 0.08)
            input.installTap(onBus: 0, bufferSize: 1_024, format: format) { [weak self] buffer, _ in
                request.append(buffer)
                let rms = Self.rmsLevel(from: buffer)
                let level = Self.normalizedLevel(fromRMS: rms)
                let timestamp = ProcessInfo.processInfo.systemUptime
                guard activityDispatchGate.shouldDispatch(at: timestamp) else { return }
                Task { @MainActor [weak self] in
                    self?.processAudioActivity(rms: rms, displayLevel: level, at: timestamp, captureID: id)
                }
            }
            inputTapInstalled = true

            recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
                Task { @MainActor [weak self] in
                    guard let self, self.captureID == id else { return }
                    if let result {
                        self.transcript = result.bestTranscription.formattedString
                        let confidences = result.bestTranscription.segments.map { Double($0.confidence) }
                        if !confidences.isEmpty {
                            let confidence = confidences.reduce(0, +) / Double(confidences.count)
                            self.lastRecognitionConfidence = confidence
                            if result.isFinal {
                                self.logger.info("recognition_confidence=\(confidence, privacy: .public) segment_count=\(confidences.count, privacy: .public)")
                            }
                        }
                        if result.isFinal, self.state == .finishing {
                            self.completeCapture()
                            return
                        }
                    }
                    if let error, self.state == .recording || self.state == .preparing {
                        self.fail("I couldn’t hear that clearly. Please try again.")
                        _ = error
                    }
                }
            }

            audioEngine.prepare()
            try audioEngine.start()
            guard id == captureID, state == .preparing else {
                tearDownAudio()
                return
            }
            state = .recording
            if pendingFinishOnStart {
                pendingFinishOnStart = false
                finish()
                return
            }
            elapsedTask = Task { [weak self] in
                let start = Date()
                while !Task.isCancelled {
                    try? await Task.sleep(for: .milliseconds(100))
                    guard let self, self.captureID == id, self.state == .recording else { return }
                    self.elapsedSeconds = Date().timeIntervalSince(start)
                }
            }
            maximumTask = Task { [weak self] in
                try? await Task.sleep(for: .seconds(max(1, maximumDuration)))
                guard !Task.isCancelled, let self, self.captureID == id else { return }
                self.finish()
            }
        } catch {
            fail("The microphone couldn’t start. Please try again.")
        }
    }

    func finish() {
        guard state == .recording else {
            if state == .preparing { pendingFinishOnStart = true }
            return
        }
        state = .finishing
        cancelTimers()
        audioEngine.stop()
        removeInputTapIfNeeded()
        recognitionRequest?.endAudio()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        finalizationTask?.cancel()
        finalizationTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(1_200))
            guard let self, self.state == .finishing else { return }
            self.completeCapture()
        }
    }

    func continueAfterQuickTap() {
        guard state == .recording || state == .preparing else { return }
        autoFinishAfterSilence = true
    }

    func cancel() {
        guard state != .idle else { return }
        captureID = UUID()
        state = .cancelled
        completion = nil
        interruptedCompletion = nil
        speechActivityCallback = nil
        bargeInMode = false
        didSignalSpeechActivity = false
        speechAboveThresholdSince = nil
        preserveTranscriptOnFinish = false
        pendingFinishOnStart = false
        transcript = ""
        cancelTimers()
        tearDownAudio()
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        state = .idle
    }

    func interruptAndDiscard() {
        cancel()
    }

    func interruptAndPreserveTranscript(immediately: Bool = false) {
        guard state == .recording || state == .preparing else { return }
        preserveTranscriptOnFinish = true
        if immediately {
            let callback = interruptedCompletion
            let result = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
            captureID = UUID()
            completion = nil
            interruptedCompletion = nil
            speechActivityCallback = nil
            bargeInMode = false
            didSignalSpeechActivity = false
            speechAboveThresholdSince = nil
            preserveTranscriptOnFinish = false
            cancelTimers()
            tearDownAudio()
            recognitionTask?.cancel()
            recognitionTask = nil
            recognitionRequest = nil
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            state = .idle
            callback?(result)
            return
        }
        finish()
    }

    func dismissError() {
        errorMessage = nil
    }

    func transcribe(fileURL: URL) async throws -> String {
        guard let recognizer, recognizer.isAvailable else { throw CaptureError.unavailable }
        let authorized = await requestSpeechAuthorization()
        guard authorized else { throw CaptureError.permissionDenied }
        return try await withCheckedThrowingContinuation { continuation in
            let request = SFSpeechURLRecognitionRequest(url: fileURL)
            request.shouldReportPartialResults = false
            if recognizer.supportsOnDeviceRecognition { request.requiresOnDeviceRecognition = true }
            let gate = SpeechTranscriptionGate()
            _ = recognizer.recognitionTask(with: request) { result, error in
                if let result, result.isFinal {
                    let text = result.bestTranscription.formattedString.trimmingCharacters(in: .whitespacesAndNewlines)
                    if text.isEmpty {
                        gate.resume(.failure(CaptureError.noSpeech), continuation: continuation)
                    } else {
                        gate.resume(.success(text), continuation: continuation)
                    }
                } else if let error {
                    gate.resume(.failure(error), continuation: continuation)
                }
            }
        }
    }

    private func scheduleSilenceFinish(for id: UUID) {
        silenceTask?.cancel()
        silenceTask = Task { [weak self] in
            try? await Task.sleep(for: silenceWindow)
            guard !Task.isCancelled, let self, self.captureID == id, self.state == .recording else { return }
            self.finish()
        }
    }

    private func processAudioActivity(rms: Double, displayLevel: Double, at timestamp: Double, captureID id: UUID) {
        guard self.captureID == id, state == .recording else { return }

        let threshold = max(minimumSpeechRMS, noiseFloorRMS * 2.0)
        if rms >= threshold {
            hasDetectedSpeech = true
            if speechActivityCallback != nil, !didSignalSpeechActivity {
                if speechAboveThresholdSince == nil { speechAboveThresholdSince = timestamp }
                if let speechAboveThresholdSince,
                   timestamp - speechAboveThresholdSince >= bargeInSpeechDuration {
                    didSignalSpeechActivity = true
                    speechActivityCallback?()
                }
            }
            silenceTask?.cancel()
            silenceTask = nil
        } else {
            speechAboveThresholdSince = nil
            noiseFloorRMS += (rms - noiseFloorRMS) * (rms < noiseFloorRMS ? 0.12 : 0.025)
            if autoFinishAfterSilence, hasDetectedSpeech, silenceTask == nil {
                scheduleSilenceFinish(for: id)
            }
        }

        if timestamp - lastPublishedLevelAt >= 0.08 {
            lastPublishedLevelAt = timestamp
            audioLevel = displayLevel
        }
    }

    private func completeCapture() {
        guard state == .finishing, !completionDelivered else { return }
        completionDelivered = true
        let result = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        let callback = completion
        let interruptedCallback = interruptedCompletion
        let preserveTranscript = preserveTranscriptOnFinish
        completion = nil
        interruptedCompletion = nil
        speechActivityCallback = nil
        bargeInMode = false
        preserveTranscriptOnFinish = false
        finalizationTask?.cancel()
        finalizationTask = nil
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        tearDownAudio()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        state = .idle
        audioLevel = 0
        if preserveTranscript { interruptedCallback?(result) }
        else { callback?(result) }
    }

    private func fail(_ message: String) {
        errorMessage = message
        let callback = completion
        completion = nil
        interruptedCompletion = nil
        speechActivityCallback = nil
        bargeInMode = false
        pendingFinishOnStart = false
        preserveTranscriptOnFinish = false
        cancelTimers()
        tearDownAudio()
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        state = .idle
        callback?("")
    }

    private func tearDownAudio() {
        if audioEngine.isRunning { audioEngine.stop() }
        removeInputTapIfNeeded()
        try? audioEngine.inputNode.setVoiceProcessingEnabled(false)
        audioEngine.reset()
    }

    private func removeInputTapIfNeeded() {
        guard inputTapInstalled else { return }
        audioEngine.inputNode.removeTap(onBus: 0)
        inputTapInstalled = false
    }

    private func cancelTimers() {
        maximumTask?.cancel(); maximumTask = nil
        silenceTask?.cancel(); silenceTask = nil
        elapsedTask?.cancel(); elapsedTask = nil
        finalizationTask?.cancel(); finalizationTask = nil
        speechAboveThresholdSince = nil
    }

    private func requestSpeechAuthorization() async -> Bool {
        await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
    }

    private func requestMicrophoneAuthorization() async -> Bool {
        let session = AVAudioSession.sharedInstance()
        return await withCheckedContinuation { continuation in
            session.requestRecordPermission { continuation.resume(returning: $0) }
        }
    }

    private static func rmsLevel(from buffer: AVAudioPCMBuffer) -> Double {
        guard let channel = buffer.floatChannelData?.pointee, buffer.frameLength > 0 else { return 0 }
        let count = Int(buffer.frameLength)
        var sum = 0.0
        for index in 0..<count {
            let sample = Double(channel[index])
            sum += sample * sample
        }
        return sqrt(sum / Double(count))
    }

    private static func normalizedLevel(fromRMS rms: Double) -> Double {
        return min(1, max(0, (20 * log10(max(rms, 0.000_01)) + 60) / 60))
    }

    private enum CaptureError: LocalizedError {
        case invalidAudioFormat
        case unavailable
        case permissionDenied
        case noSpeech

        var errorDescription: String? {
            switch self {
            case .invalidAudioFormat: return "The microphone format is unavailable."
            case .unavailable: return "Speech Recognition is temporarily unavailable."
            case .permissionDenied: return "Allow Speech Recognition to transcribe this voice note."
            case .noSpeech: return "No speech was recognized in that recording."
            }
        }
    }
}

private final class AudioActivityDispatchGate: @unchecked Sendable {
    private let lock = NSLock()
    private let minimumInterval: Double
    private var lastDispatch = 0.0

    init(minimumInterval: Double) {
        self.minimumInterval = minimumInterval
    }

    func shouldDispatch(at timestamp: Double) -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard timestamp - lastDispatch >= minimumInterval else { return false }
        lastDispatch = timestamp
        return true
    }
}

private final class SpeechTranscriptionGate: @unchecked Sendable {
    private let lock = NSLock()
    private var didResume = false

    func resume(
        _ result: Result<String, Error>,
        continuation: CheckedContinuation<String, Error>
    ) {
        lock.lock()
        guard !didResume else {
            lock.unlock()
            return
        }
        didResume = true
        lock.unlock()
        continuation.resume(with: result)
    }
}
