import SwiftUI
import WidgetKit

private struct AnnaWidgetEntry: TimelineEntry {
    let date: Date
    let snapshot: AnnaWidgetSnapshot
}

private struct AnnaWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> AnnaWidgetEntry {
        AnnaWidgetEntry(date: .now, snapshot: .resting)
    }

    func getSnapshot(in context: Context, completion: @escaping (AnnaWidgetEntry) -> Void) {
        completion(AnnaWidgetEntry(date: .now, snapshot: AnnaWidgetStateStore.read()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<AnnaWidgetEntry>) -> Void) {
        let entry = AnnaWidgetEntry(date: .now, snapshot: AnnaWidgetStateStore.read())
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(30 * 60))))
    }
}

private struct AnnaWidgetBody: View {
    @Environment(\.widgetFamily) private var family
    let entry: AnnaWidgetEntry

    var body: some View {
        Group {
            switch family {
            case .accessoryInline:
                Label("Anna · \(entry.snapshot.mode)", systemImage: "sparkles")
            case .accessoryCircular:
                ZStack {
                    AccessoryWidgetBackground()
                    Image("AnnaOrb").resizable().interpolation(.none).scaledToFit().padding(5)
                }
            #if os(watchOS)
            case .accessoryCorner:
                Image("AnnaOrb").resizable().interpolation(.none).scaledToFit()
                    .widgetLabel { Text(entry.snapshot.mode) }
            #endif
            case .accessoryRectangular:
                HStack(spacing: 7) {
                    Image("AnnaOrb").resizable().interpolation(.none).scaledToFit().frame(width: 25, height: 25)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Anna").font(.headline)
                        if let healthSummaryText {
                            Text(healthSummaryText)
                                .font(.caption2)
                                .lineLimit(2)
                                .minimumScaleFactor(0.8)
                        } else {
                            Text(entry.snapshot.quiet ? "Resting" : entry.snapshot.mode).font(.caption2)
                        }
                    }
                }
            default:
                phoneSummary
            }
        }
        .widgetURL(URL(string: "anna://open"))
    }

    private var phoneSummary: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image("AnnaOrb").resizable().interpolation(.none).scaledToFit().frame(width: 35, height: 35)
                VStack(alignment: .leading, spacing: 0) {
                    Text("Anna").font(.headline)
                    Text(entry.snapshot.quiet ? "Resting" : entry.snapshot.mode).font(.caption)
                }
            }
            if let healthSummaryText {
                Text(healthSummaryText)
                    .font(.caption2)
                    .lineLimit(3)
                    .minimumScaleFactor(0.8)
            }
            if let stepProgress {
                ProgressView(value: stepProgress)
                    .tint(Color(red: 0.94, green: 0.45, blue: 0.69))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .padding(10)
        .background(Color(red: 0.05, green: 0.06, blue: 0.13), in: RoundedRectangle(cornerRadius: 20))
    }

    private var healthSummaryText: String? {
        var metrics: [String] = []
        if let steps = entry.snapshot.stepsToday {
            if let target = entry.snapshot.dailyStepTarget, target > 0 {
                metrics.append("\(steps.formatted()) / \(target.formatted()) steps")
            } else {
                metrics.append("\(steps.formatted()) steps")
            }
        }
        if let sleep = entry.snapshot.sleepHours {
            metrics.append(String(format: "%.1f h sleep", sleep))
        }
        if let workouts = entry.snapshot.workoutsThisWeek {
            metrics.append("\(workouts) workouts")
        }
        return metrics.isEmpty ? nil : metrics.joined(separator: " · ")
    }

    private var stepProgress: Double? {
        guard let steps = entry.snapshot.stepsToday,
              let target = entry.snapshot.dailyStepTarget,
              target > 0 else { return nil }
        return min(1, Double(steps) / Double(target))
    }
}

private struct AnnaStatusWidget: Widget {
    let kind = "AnnaStatusWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AnnaWidgetProvider()) { entry in
            AnnaWidgetBody(entry: entry)
        }
        .configurationDisplayName("Anna")
        .description("See Anna’s current state and your opt-in activity summary.")
        #if os(watchOS)
        .supportedFamilies([.accessoryCircular, .accessoryInline, .accessoryCorner, .accessoryRectangular])
        #else
        .supportedFamilies([.systemSmall, .accessoryCircular, .accessoryRectangular])
        #endif
    }
}

#if os(watchOS)
@main
struct AnnaWatchWidgetBundle: WidgetBundle {
    var body: some Widget { AnnaStatusWidget() }
}
#else
@main
struct AnnaPhoneWidgetBundle: WidgetBundle {
    var body: some Widget { AnnaStatusWidget() }
}
#endif
