import SwiftUI

struct AnnaCharacterView: View {
    var expression: CharmExpression = .calm
    var showsFace = true

    var body: some View {
        AnnaOrbView(expression: expression, showsFace: showsFace)
    }
}
