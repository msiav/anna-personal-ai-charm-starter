var ExtensionPreprocessingJS = function () {};

ExtensionPreprocessingJS.prototype = {
  run: function (arguments) {
    var bodyText = document.body ? document.body.innerText : "";
    var payload = {
      title: document.title || "",
      url: window.location.href || "",
      text: bodyText.substring(0, 12000)
    };
    arguments.completionFunction(payload);
  }
};

var ExtensionPreprocessingJS = new ExtensionPreprocessingJS();
