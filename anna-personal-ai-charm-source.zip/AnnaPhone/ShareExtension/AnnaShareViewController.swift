import UIKit
import UniformTypeIdentifiers

final class AnnaShareViewController: UIViewController {
    private let preview = UITextView()
    private let status = UILabel()
    private var sharedText = ""
    private var sharedURL = ""
    private var isLoading = true

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.055, green: 0.075, blue: 0.14, alpha: 1)
        configureInterface()
        loadSharedItems()
    }

    private func configureInterface() {
        let title = UILabel()
        title.text = "Share to Anna"
        title.textColor = .white
        title.font = .systemFont(ofSize: 22, weight: .semibold)

        let subtitle = UILabel()
        subtitle.text = "Shared text stays on this iPhone. Anna won’t fetch a page from its link."
        subtitle.textColor = UIColor.white.withAlphaComponent(0.72)
        subtitle.font = .preferredFont(forTextStyle: .subheadline)
        subtitle.numberOfLines = 0

        preview.backgroundColor = UIColor.white.withAlphaComponent(0.08)
        preview.textColor = .white
        preview.font = .preferredFont(forTextStyle: .body)
        preview.layer.cornerRadius = 14
        preview.isEditable = false
        preview.accessibilityLabel = "Shared content preview"

        status.text = "Reading the content you chose to share…"
        status.textColor = UIColor.white.withAlphaComponent(0.7)
        status.font = .preferredFont(forTextStyle: .caption1)
        status.numberOfLines = 0

        let save = UIButton(type: .system)
        save.setTitle("Save to Anna", for: .normal)
        save.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        save.setTitleColor(.white, for: .normal)
        save.backgroundColor = UIColor(red: 0.75, green: 0.25, blue: 0.49, alpha: 1)
        save.layer.cornerRadius = 14
        save.addTarget(self, action: #selector(saveSharedContent), for: .touchUpInside)
        save.accessibilityHint = "Save this shared text or link for Anna to use when you open the app."

        let cancel = UIButton(type: .system)
        cancel.setTitle("Cancel", for: .normal)
        cancel.setTitleColor(UIColor.white.withAlphaComponent(0.75), for: .normal)
        cancel.addTarget(self, action: #selector(cancelShare), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [title, subtitle, preview, status, save, cancel])
        stack.axis = .vertical
        stack.spacing = 14
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            stack.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 18),
            stack.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -14),
            preview.heightAnchor.constraint(greaterThanOrEqualToConstant: 130),
            save.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func loadSharedItems() {
        let inputItems = extensionContext?.inputItems as? [NSExtensionItem] ?? []
        for item in inputItems {
            if let page = item.userInfo?[NSExtensionJavaScriptPreprocessingResultsKey] as? [String: Any] {
                if let title = page["title"] as? String, !title.isEmpty { sharedText = "\(title)\n\n" + sharedText }
                if let url = page["url"] as? String { sharedURL = url }
                if let text = page["text"] as? String { sharedText += text }
            }
        }
        let providers = inputItems.flatMap { $0.attachments ?? [] }
        let group = DispatchGroup()
        let lock = NSLock()

        for provider in providers {
            if provider.hasItemConformingToTypeIdentifier(UTType.plainText.identifier) {
                group.enter()
                provider.loadItem(forTypeIdentifier: UTType.plainText.identifier, options: nil) { [weak self] item, _ in
                    let value = Self.stringValue(item)
                    lock.lock()
                    if !value.isEmpty, let self, self.sharedText.isEmpty { self.sharedText = value }
                    lock.unlock()
                    group.leave()
                }
            }
            if provider.hasItemConformingToTypeIdentifier(UTType.url.identifier) {
                group.enter()
                provider.loadItem(forTypeIdentifier: UTType.url.identifier, options: nil) { [weak self] item, _ in
                    let value: String
                    if let url = item as? URL { value = url.absoluteString }
                    else if let text = item as? String, URL(string: text)?.scheme != nil { value = text }
                    else { value = "" }
                    lock.lock()
                    if !value.isEmpty, let self { self.sharedURL = value }
                    lock.unlock()
                    group.leave()
                }
            }
            if provider.hasItemConformingToTypeIdentifier(UTType.html.identifier) {
                group.enter()
                provider.loadItem(forTypeIdentifier: UTType.html.identifier, options: nil) { [weak self] item, _ in
                    let raw: String
                    if let data = item as? Data { raw = String(decoding: data, as: UTF8.self) }
                    else if let value = item as? String { raw = value }
                    else { raw = "" }
                    let text = Self.stripHTML(raw)
                    lock.lock()
                    if !text.isEmpty, let self, self.sharedText.isEmpty { self.sharedText = text }
                    lock.unlock()
                    group.leave()
                }
            }
        }

        group.notify(queue: .main) { [weak self] in
            guard let self else { return }
            self.isLoading = false
            let excerpt = String(self.sharedText.trimmingCharacters(in: .whitespacesAndNewlines).prefix(4_000))
            self.preview.text = !excerpt.isEmpty ? excerpt : (!self.sharedURL.isEmpty ? self.sharedURL : "No text or link was provided by the sharing app.")
            self.status.text = !excerpt.isEmpty
                ? "Text is ready for private, on-device summarization."
                : "Only the link is available. Anna will save it but won’t fetch the webpage."
        }
    }

    @objc private func saveSharedContent() {
        guard !isLoading else { return }
        guard !sharedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !sharedURL.isEmpty else {
            status.text = "There’s nothing to save from this share."
            return
        }
        guard let defaults = UserDefaults(suiteName: "group.com.example.annacharm.shared") else {
            status.text = "Anna’s shared storage isn’t available."
            return
        }
        let payload: [String: String] = [
            "text": String(sharedText.prefix(12_000)),
            "url": String(sharedURL.prefix(2_000))
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: payload) else {
            status.text = "Anna couldn’t prepare this share."
            return
        }
        defaults.set(data, forKey: "anna.share.pending.v1")
        status.text = "Saved. Open Anna to review the shared text or link."
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in
            self?.extensionContext?.completeRequest(returningItems: nil)
        }
    }

    @objc private func cancelShare() {
        extensionContext?.cancelRequest(withError: NSError(domain: "AnnaShare", code: 1))
    }

    private static func stringValue(_ item: NSSecureCoding?) -> String {
        if let value = item as? String { return value }
        if let data = item as? Data { return String(decoding: data, as: UTF8.self) }
        return ""
    }

    private static func stripHTML(_ html: String) -> String {
        let withoutTags = html.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        let decoded = withoutTags
            .replacingOccurrences(of: "&nbsp;", with: " ")
            .replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
        return decoded.split(whereSeparator: \.isWhitespace).joined(separator: " ")
    }
}
