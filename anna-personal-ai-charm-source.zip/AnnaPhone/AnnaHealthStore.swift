import Foundation
import HealthKit

struct AnnaHealthSummary: Codable, Equatable {
    let stepsToday: Int
    let stepsAverageLast7Days: Int?
    let sleepHoursLastNight: Double?
    let workoutsThisWeek: Int
    let updatedAt: Date

    var sleepLabel: String {
        guard let sleepHoursLastNight else { return "No recent sleep data" }
        return String(format: "%.1f hours", sleepHoursLastNight)
    }

    var stepsTrendLabel: String {
        guard let baseline = stepsAverageLast7Days, baseline > 0 else {
            return "Anna needs more recorded days before comparing your steps."
        }
        let ratio = Double(stepsToday) / Double(baseline)
        if ratio >= 1.2 { return "Your steps are above your recent recorded daily average." }
        if ratio <= 0.8 { return "Your steps are below your recent recorded daily average so far today." }
        return "Your steps are near your recent recorded daily average."
    }
}

@MainActor
final class AnnaHealthStore {
    private let store = HKHealthStore()

    var isAvailable: Bool { HKHealthStore.isHealthDataAvailable() }

    func requestReadAccess() async throws {
        guard isAvailable else { throw HealthError.unavailable }
        guard let steps = HKObjectType.quantityType(forIdentifier: .stepCount),
              let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else {
            throw HealthError.unavailable
        }
        let readTypes: Set<HKObjectType> = [steps, sleep, HKObjectType.workoutType()]
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let gate = HealthAuthorizationGate(continuation)
            let timeout = Task {
                try? await Task.sleep(for: .seconds(25))
                guard !Task.isCancelled else { return }
                gate.finish(.failure(HealthError.authorizationTimedOut))
            }
            gate.setTimeout(timeout)
            store.requestAuthorization(toShare: [], read: readTypes) { success, error in
                if let error {
                    gate.finish(.failure(error))
                } else if success {
                    gate.finish(.success(()))
                } else {
                    gate.finish(.failure(HealthError.authorizationUnavailable))
                }
            }
        }
    }

    func readSummary(now: Date = Date()) async throws -> AnnaHealthSummary {
        guard isAvailable else { throw HealthError.unavailable }
        async let steps = readSteps(since: Calendar.current.startOfDay(for: now), until: now)
        async let baseline = readSevenDayStepAverage(endingAt: Calendar.current.startOfDay(for: now))
        async let sleep = readMostRecentSleep(endingBefore: now)
        async let workouts = readWorkoutCount(since: Calendar.current.date(byAdding: .day, value: -7, to: now) ?? now, until: now)
        let (stepCount, stepAverage, sleepHours, workoutCount) = try await (steps, baseline, sleep, workouts)
        return AnnaHealthSummary(
            stepsToday: stepCount,
            stepsAverageLast7Days: stepAverage,
            sleepHoursLastNight: sleepHours,
            workoutsThisWeek: workoutCount,
            updatedAt: now
        )
    }

    private func readSevenDayStepAverage(endingAt end: Date) async throws -> Int? {
        guard let type = HKObjectType.quantityType(forIdentifier: .stepCount) else { throw HealthError.unavailable }
        let start = Calendar.current.date(byAdding: .day, value: -7, to: end) ?? end
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        var interval = DateComponents()
        interval.day = 1
        let anchor = Calendar.current.startOfDay(for: end)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKStatisticsCollectionQuery(
                quantityType: type,
                quantitySamplePredicate: predicate,
                options: .cumulativeSum,
                anchorDate: anchor,
                intervalComponents: interval
            )
            query.initialResultsHandler = { _, collection, error in
                if let error {
                    continuation.resume(throwing: error)
                    return
                }
                guard let collection else {
                    continuation.resume(returning: nil)
                    return
                }
                var totals: [Double] = []
                collection.enumerateStatistics(from: start, to: end) { statistics, _ in
                    if let value = statistics.sumQuantity()?.doubleValue(for: .count()) {
                        totals.append(value)
                    }
                }
                guard !totals.isEmpty else {
                    continuation.resume(returning: nil)
                    return
                }
                continuation.resume(returning: Int(totals.reduce(0, +) / Double(totals.count)))
            }
            store.execute(query)
        }
    }

    private func readSteps(since start: Date, until end: Date) async throws -> Int {
        guard let type = HKObjectType.quantityType(forIdentifier: .stepCount) else { throw HealthError.unavailable }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKStatisticsQuery(
                quantityType: type,
                quantitySamplePredicate: predicate,
                options: .cumulativeSum
            ) { _, statistics, error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume(returning: Int(statistics?.sumQuantity()?.doubleValue(for: .count()) ?? 0))
                }
            }
            store.execute(query)
        }
    }

    private func readWorkoutCount(since start: Date, until end: Date) async throws -> Int {
        let type = HKObjectType.workoutType()
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, samples, error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    let workouts = samples as? [HKWorkout] ?? []
                    continuation.resume(returning: Set(workouts.map(\.uuid)).count)
                }
            }
            store.execute(query)
        }
    }

    private func readMostRecentSleep(endingBefore end: Date) async throws -> Double? {
        guard let type = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else { throw HealthError.unavailable }
        let start = Calendar.current.date(byAdding: .hour, value: -36, to: end) ?? end
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]
            ) { _, samples, error in
                if let error {
                    continuation.resume(throwing: error)
                    return
                }
                let asleepValues: Set<Int> = [
                    HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,
                    HKCategoryValueSleepAnalysis.asleepCore.rawValue,
                    HKCategoryValueSleepAnalysis.asleepDeep.rawValue,
                    HKCategoryValueSleepAnalysis.asleepREM.rawValue
                ]
                let asleep = (samples as? [HKCategorySample] ?? [])
                    .filter { asleepValues.contains($0.value) }
                    .sorted { $0.startDate < $1.startDate }
                guard !asleep.isEmpty else {
                    continuation.resume(returning: nil)
                    return
                }

                let sessions = Self.sleepSessions(from: asleep)
                let latest = sessions.max(by: { ($0.last?.endDate ?? .distantPast) < ($1.last?.endDate ?? .distantPast) }) ?? asleep
                let intervals = latest.map { ($0.startDate, $0.endDate) }.sorted { $0.0 < $1.0 }
                var total: TimeInterval = 0
                var intervalStart: Date?
                var intervalEnd: Date?
                for (sampleStart, sampleEnd) in intervals {
                    if let currentEnd = intervalEnd, sampleStart <= currentEnd {
                        intervalEnd = max(currentEnd, sampleEnd)
                    } else {
                        if let intervalStart, let intervalEnd { total += intervalEnd.timeIntervalSince(intervalStart) }
                        intervalStart = sampleStart
                        intervalEnd = sampleEnd
                    }
                }
                if let intervalStart, let intervalEnd { total += intervalEnd.timeIntervalSince(intervalStart) }
                continuation.resume(returning: min(total / 3_600, 24))
            }
            store.execute(query)
        }
    }

    nonisolated private static func sleepSessions(from samples: [HKCategorySample]) -> [[HKCategorySample]] {
        var sessions: [[HKCategorySample]] = []
        for sample in samples {
            if let lastSession = sessions.indices.last,
               let previous = sessions[lastSession].last,
               sample.startDate.timeIntervalSince(previous.endDate) <= 3 * 3_600 {
                sessions[lastSession].append(sample)
            } else {
                sessions.append([sample])
            }
        }
        return sessions
    }

    private enum HealthError: LocalizedError {
        case unavailable
        case authorizationUnavailable
        case authorizationTimedOut

        var errorDescription: String? {
            switch self {
            case .unavailable: return "Health data isn’t available on this device."
            case .authorizationUnavailable: return "Anna couldn’t request Health access. Check Health permissions in Settings."
            case .authorizationTimedOut: return "The Health access request took too long. Anna stopped waiting safely. Please try again."
        }
    }
}

private final class HealthAuthorizationGate: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Void, Error>?
    private var timeoutTask: Task<Void, Never>?

    init(_ continuation: CheckedContinuation<Void, Error>) {
        self.continuation = continuation
    }

    func setTimeout(_ task: Task<Void, Never>) {
        lock.lock()
        let shouldCancel = continuation == nil
        if !shouldCancel { timeoutTask = task }
        lock.unlock()
        if shouldCancel { task.cancel() }
    }

    func finish(_ result: Result<Void, Error>) {
        lock.lock()
        let pending = continuation
        continuation = nil
        let timeout = timeoutTask
        timeoutTask = nil
        lock.unlock()

        timeout?.cancel()
        pending?.resume(with: result)
    }
}
}
