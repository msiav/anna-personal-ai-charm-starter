import CloudKit
import Foundation

struct AnnaCloudMessage: Codable, Equatable, Identifiable {
    var id: UUID
    var role: String
    var text: String
    var createdAt: Date
    var stableContentID: String?
    var attachmentFilename: String?
    var attachmentAnalysis: String? = nil
    var platformPayload: Data?
}

struct AnnaCloudConversation: Codable, Equatable, Identifiable {
    var id: UUID
    var title: String
    var createdAt: Date
    var updatedAt: Date
    var providerIdentifier: String
    var modelIdentifier: String
    var messages: [AnnaCloudMessage]
    var rollingSummary: String? = nil
    var deletedMessageIDs: [UUID]? = nil
    var deletedAt: Date?
}

struct AnnaCloudSyncSnapshot {
    var conversations: [AnnaCloudConversation]
    var deletionDates: [String: Date]
    var editionNumber: String
}

private struct AnnaCloudIdentity: Codable {
    var editionNumber: String
}

private struct AnnaCloudConversationIndex: Codable {
    var conversationIDs: [String]
    var updatedAt: Date
}

enum AnnaEditionIdentity {
    static let defaultsKey = "anna.edition.number.v1"

    static func localNumber(in defaults: UserDefaults = .standard) -> String {
        if let saved = defaults.string(forKey: defaultsKey), isValid(saved) {
            return saved
        }
        let generated = String(UInt64.random(in: 100_000_000_000_000...999_999_999_999_999))
        defaults.set(generated, forKey: defaultsKey)
        return generated
    }

    static func isValid(_ number: String) -> Bool {
        number.count == 15 && number.allSatisfy(\.isNumber)
    }
}

enum AnnaCloudSyncError: LocalizedError {
    case noICloudAccount
    case accountUnavailable
    case malformedCloudRecord

    var errorDescription: String? {
        switch self {
        case .noICloudAccount:
            return "Turn on iCloud for this device to sync Anna. No Anna login is needed. Your chats remain on this device until iCloud is available."
        case .accountUnavailable:
            return "iCloud is temporarily unavailable. Anna will keep your chats here and try again later."
        case .malformedCloudRecord:
            return "Anna found a sync item it could not read. Your local conversations are safe."
        }
    }
}

@MainActor
final class AnnaCloudSyncStore {
    static let containerIdentifier = "iCloud.com.example.annacharm"

    private let container = CKContainer(identifier: containerIdentifier)
    private var database: CKDatabase { container.privateCloudDatabase }
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()
    private let fileManager = FileManager.default

    func synchronize(
        localConversations: [AnnaCloudConversation],
        localDeletionDates: [String: Date],
        localEditionNumber: String,
        attachmentsDirectory: URL
    ) async throws -> AnnaCloudSyncSnapshot {
        do {
            guard try await container.accountStatus() == .available else {
                throw AnnaCloudSyncError.noICloudAccount
            }

            let resolvedEditionNumber = try await synchronizeEditionNumber(localEditionNumber)

            let localByName = Dictionary(uniqueKeysWithValues: localConversations.map { ($0.id.uuidString, $0) })
            let indexedNames = try await fetchConversationIDs()
            let allNames = Set(localByName.keys)
                .union(indexedNames)
                .union(localDeletionDates.keys)
            let recordNames = allNames.map { "conversation-\($0)" }
            let cloudRecords = try await fetchRecords(recordNames: recordNames, desiredKeys: ["payload", "updatedAt"])
            var cloudDocuments: [String: AnnaCloudConversation] = [:]
            for record in cloudRecords {
                guard let asset = record["payload"] as? CKAsset,
                      let fileURL = asset.fileURL,
                      let data = try? Data(contentsOf: fileURL),
                      let document = try? decoder.decode(AnnaCloudConversation.self, from: data) else { continue }
                cloudDocuments[document.id.uuidString] = document
            }

            let allResolvedNames = allNames.union(cloudDocuments.keys)

            var resolved: [String: AnnaCloudConversation] = [:]
            var resolvedDeletionDates = localDeletionDates

            for name in allResolvedNames {
                let local = localByName[name]
                let remote = cloudDocuments[name]
                let localDeletion = localDeletionDates[name]
                let remoteDeletion = remote?.deletedAt
                let deletionDate = [localDeletion, remoteDeletion].compactMap { $0 }.max()

                if let deletionDate {
                    var tombstone = remote ?? local ?? Self.emptyConversation(id: name, date: deletionDate)
                    tombstone.messages = []
                    tombstone.deletedAt = deletionDate
                    tombstone.updatedAt = deletionDate
                    resolved[name] = tombstone
                    resolvedDeletionDates[name] = deletionDate
                    continue
                }

                let merged: AnnaCloudConversation
                switch (local, remote) {
                case let (local?, remote?):
                    merged = Self.merge(local: local, remote: remote)
                case let (local?, nil):
                    merged = local
                case let (nil, remote?):
                    merged = remote
                case (nil, nil):
                    continue
                }
                resolved[name] = merged
                resolvedDeletionDates.removeValue(forKey: name)
            }

            for (name, document) in resolved {
                if cloudDocuments[name] == document { continue }
                let recordID = CKRecord.ID(recordName: "conversation-\(name)")
                try await saveConverging(document, recordID: recordID)
            }

            try await saveConversationIDs(Set(resolved.keys))

            try await synchronizeAttachments(
                referencedNames: Set(resolved.values.filter { $0.deletedAt == nil }
                    .flatMap(\.messages)
                    .compactMap(\.attachmentFilename)),
                directory: attachmentsDirectory
            )

            let liveDocuments = resolved.values
                .filter { $0.deletedAt == nil }
                .sorted { $0.updatedAt > $1.updatedAt }
            return AnnaCloudSyncSnapshot(
                conversations: liveDocuments,
                deletionDates: resolvedDeletionDates,
                editionNumber: resolvedEditionNumber
            )
        } catch let error as AnnaCloudSyncError {
            throw error
        } catch let error as CKError where error.code == .notAuthenticated {
            throw AnnaCloudSyncError.noICloudAccount
        } catch let error as CKError where error.code == .accountTemporarilyUnavailable || error.code == .networkUnavailable || error.code == .networkFailure {
            throw AnnaCloudSyncError.accountUnavailable
        }
    }

    private func fetchConversationIDs() async throws -> Set<String> {
        guard let record = try await recordIfPresent(withName: Self.conversationIndexRecordName) else { return [] }
        guard let asset = record["payload"] as? CKAsset,
              let fileURL = asset.fileURL,
              let data = try? Data(contentsOf: fileURL),
              let index = try? decoder.decode(AnnaCloudConversationIndex.self, from: data) else {
            throw AnnaCloudSyncError.malformedCloudRecord
        }
        return Set(index.conversationIDs.filter { UUID(uuidString: $0) != nil })
    }

    private func saveConversationIDs(_ ids: Set<String>) async throws {
        let recordID = CKRecord.ID(recordName: Self.conversationIndexRecordName)
        let record = try await recordIfPresent(withName: Self.conversationIndexRecordName)
            ?? CKRecord(recordType: "AnnaConversation", recordID: recordID)
        let index = AnnaCloudConversationIndex(conversationIDs: ids.sorted(), updatedAt: Date())
        let temporaryURL = fileManager.temporaryDirectory
            .appendingPathComponent("anna-conversation-index-\(UUID().uuidString).json")
        defer { try? fileManager.removeItem(at: temporaryURL) }
        try encoder.encode(index).write(to: temporaryURL, options: .atomic)
        record["payload"] = CKAsset(fileURL: temporaryURL)
        record["updatedAt"] = index.updatedAt as CKRecordValue
        try await database.save(record)
    }

    private func fetchRecords(
        recordNames: [String],
        desiredKeys: [CKRecord.FieldKey]?
    ) async throws -> [CKRecord] {
        var records: [CKRecord] = []
        for offset in stride(from: 0, to: recordNames.count, by: 100) {
            let names = Array(recordNames.sorted().dropFirst(offset).prefix(100))
            let ids = names.map { CKRecord.ID(recordName: $0) }
            guard !ids.isEmpty else { continue }
            let results = try await database.records(for: ids, desiredKeys: desiredKeys)
            for result in results.values {
                switch result {
                case .success(let record): records.append(record)
                case .failure(let error as CKError) where error.code == .unknownItem: continue
                case .failure(let error): throw error
                }
            }
        }
        return records
    }

    private func recordIfPresent(withName name: String) async throws -> CKRecord? {
        do {
            return try await database.record(for: CKRecord.ID(recordName: name))
        } catch let error as CKError where error.code == .unknownItem {
            return nil
        }
    }

    // Keep the per-person identity in each customer's private CloudKit database.
    // Reusing the deployed conversation record type avoids a production-schema migration.
    private static let identityRecordName = "anna-profile-identity-v1"
    private static let conversationIndexRecordName = "anna-conversation-index-v1"

    private func synchronizeEditionNumber(_ localNumber: String) async throws -> String {
        let recordID = CKRecord.ID(recordName: Self.identityRecordName)
        let profile = AnnaCloudIdentity(editionNumber: localNumber)

        for attempt in 0..<5 {
            var record: CKRecord
            do {
                record = try await database.record(for: recordID)
                if let remoteNumber = editionNumber(in: record) {
                    return remoteNumber
                }
            } catch let error as CKError where error.code == .unknownItem {
                record = CKRecord(recordType: "AnnaConversation", recordID: recordID)
            }

            let temporaryURL = fileManager.temporaryDirectory
                .appendingPathComponent("anna-identity-\(UUID().uuidString).json")
            defer { try? fileManager.removeItem(at: temporaryURL) }
            try encoder.encode(profile).write(to: temporaryURL, options: .atomic)
            record["payload"] = CKAsset(fileURL: temporaryURL)
            record["updatedAt"] = Date() as CKRecordValue

            do {
                try await database.save(record)
                return localNumber
            } catch let error as CKError where error.code == .serverRecordChanged {
                if let winner = try? await database.record(for: recordID),
                   let canonicalNumber = editionNumber(in: winner) {
                    return canonicalNumber
                }
                if attempt == 4 { throw error }
            }
        }

        throw AnnaCloudSyncError.accountUnavailable
    }

    private func editionNumber(in record: CKRecord) -> String? {
        guard let asset = record["payload"] as? CKAsset,
              let fileURL = asset.fileURL,
              let data = try? Data(contentsOf: fileURL),
              let identity = try? decoder.decode(AnnaCloudIdentity.self, from: data),
              AnnaEditionIdentity.isValid(identity.editionNumber) else { return nil }
        return identity.editionNumber
    }

    private func synchronizeAttachments(referencedNames: Set<String>, directory: URL) async throws {
        try fileManager.createDirectory(at: directory, withIntermediateDirectories: true)
        let safeNames = referencedNames.filter(Self.isSafeAttachmentFilename)
        let recordNames = safeNames.map { "attachment-\($0)" }
        let cloudRecords = try await fetchRecords(recordNames: recordNames, desiredKeys: ["filename", "asset"])
        let cloudEntries: [(String, CKRecord)] = cloudRecords.compactMap { record in
            guard let filename = record["filename"] as? String else { return nil }
            return (filename, record)
        }
        let cloudByFilename = Dictionary(uniqueKeysWithValues: cloudEntries)

        for filename in safeNames {
            guard Self.isSafeAttachmentFilename(filename) else { continue }
            let localURL = directory.appendingPathComponent(filename)
            if fileManager.fileExists(atPath: localURL.path) { continue }
            if let record = cloudByFilename[filename],
               let asset = record["asset"] as? CKAsset,
               let fileURL = asset.fileURL {
                try? fileManager.copyItem(at: fileURL, to: localURL)
            }
        }

        for filename in safeNames {
            let localURL = directory.appendingPathComponent(filename)
            guard Self.isSafeAttachmentFilename(filename),
                  fileManager.fileExists(atPath: localURL.path),
                  cloudByFilename[filename] == nil else { continue }
            let recordID = CKRecord.ID(recordName: "attachment-\(filename)")
            let record = CKRecord(recordType: "AnnaAttachment", recordID: recordID)
            record["filename"] = filename as CKRecordValue
            try await saveFile(localURL, to: record, field: "asset")
        }
    }

    private func saveConverging(_ document: AnnaCloudConversation, recordID: CKRecord.ID) async throws {
        var candidate = document
        for attempt in 0..<3 {
            let record: CKRecord
            do {
                record = try await database.record(for: recordID)
                if let asset = record["payload"] as? CKAsset,
                   let fileURL = asset.fileURL,
                   let data = try? Data(contentsOf: fileURL),
                   let remote = try? decoder.decode(AnnaCloudConversation.self, from: data) {
                    if let deletionDate = [candidate.deletedAt, remote.deletedAt].compactMap({ $0 }).max() {
                        candidate.messages = []
                        candidate.deletedAt = deletionDate
                        candidate.updatedAt = max(max(candidate.updatedAt, remote.updatedAt), deletionDate)
                    } else {
                        candidate = Self.merge(local: candidate, remote: remote)
                    }
                }
            } catch let error as CKError where error.code == .unknownItem {
                record = CKRecord(recordType: "AnnaConversation", recordID: recordID)
            }

            do {
                try await save(candidate, to: record)
                return
            } catch let error as CKError where error.code == .serverRecordChanged && attempt < 2 {
                continue
            }
        }
        throw AnnaCloudSyncError.accountUnavailable
    }

    private func save(_ document: AnnaCloudConversation, to record: CKRecord) async throws {
        let temporaryURL = fileManager.temporaryDirectory
            .appendingPathComponent("anna-cloud-\(UUID().uuidString).json")
        try encoder.encode(document).write(to: temporaryURL, options: .atomic)
        defer { try? fileManager.removeItem(at: temporaryURL) }
        record["payload"] = CKAsset(fileURL: temporaryURL)
        record["updatedAt"] = document.updatedAt as CKRecordValue
        try await database.save(record)
    }

    private func saveFile(_ fileURL: URL, to record: CKRecord, field: String) async throws {
        record[field] = CKAsset(fileURL: fileURL)
        try await database.save(record)
    }

    private static func merge(local: AnnaCloudConversation, remote: AnnaCloudConversation) -> AnnaCloudConversation {
        var merged = local.updatedAt >= remote.updatedAt ? local : remote
        var messagesByID: [UUID: AnnaCloudMessage] = [:]
        for message in local.messages { messagesByID[message.id] = message }
        for message in remote.messages {
            if let existing = messagesByID[message.id] {
                let newest = local.updatedAt >= remote.updatedAt ? messageFor(message.id, in: local) : messageFor(message.id, in: remote)
                messagesByID[message.id] = newest ?? existing
            } else {
                messagesByID[message.id] = message
            }
        }
        merged.messages = messagesByID.values.sorted { $0.createdAt < $1.createdAt }
        merged.deletedMessageIDs = Array(Set((local.deletedMessageIDs ?? []) + (remote.deletedMessageIDs ?? [])))
        let deletedIDs = Set(merged.deletedMessageIDs ?? [])
        merged.messages.removeAll { deletedIDs.contains($0.id) }
        merged.createdAt = min(local.createdAt, remote.createdAt)
        merged.updatedAt = max(local.updatedAt, remote.updatedAt)
        merged.deletedAt = nil
        return merged
    }

    private static func messageFor(_ id: UUID, in conversation: AnnaCloudConversation) -> AnnaCloudMessage? {
        conversation.messages.first { $0.id == id }
    }

    private static func emptyConversation(id: String, date: Date) -> AnnaCloudConversation {
        AnnaCloudConversation(
            id: UUID(uuidString: id) ?? UUID(),
            title: "Deleted conversation",
            createdAt: date,
            updatedAt: date,
            providerIdentifier: "local",
            modelIdentifier: "",
            messages: [],
            deletedAt: date
        )
    }

    private static func isSafeAttachmentFilename(_ filename: String) -> Bool {
        filename == URL(fileURLWithPath: filename).lastPathComponent
            && !filename.contains("/")
            && !filename.contains("\\")
            && filename.lowercased().hasSuffix(".jpg")
    }
}
