import Foundation
import WidgetKit

struct AnnaWidgetSnapshot: Codable, Equatable {
    var mode: String
    var expression: String
    var quiet: Bool
    var updatedAt: Date
    var stepsToday: Int?
    var dailyStepTarget: Int?
    var sleepHours: Double?
    var workoutsThisWeek: Int?

    static let resting = AnnaWidgetSnapshot(
        mode: "Here",
        expression: "calm",
        quiet: false,
        updatedAt: .distantPast,
        stepsToday: nil,
        dailyStepTarget: nil,
        sleepHours: nil,
        workoutsThisWeek: nil
    )
}

enum AnnaWidgetStateStore {
    static let appGroupID = "group.com.example.annacharm.shared"
    private static let snapshotKey = "anna.widget.snapshot.v1"

    static func read() -> AnnaWidgetSnapshot {
        guard let defaults = UserDefaults(suiteName: appGroupID),
              let data = defaults.data(forKey: snapshotKey),
              let snapshot = try? JSONDecoder().decode(AnnaWidgetSnapshot.self, from: data) else {
            return .resting
        }
        return snapshot
    }

    static func write(
        mode: String,
        expression: String,
        quiet: Bool,
        stepsToday: Int? = nil,
        dailyStepTarget: Int? = nil,
        sleepHours: Double? = nil,
        workoutsThisWeek: Int? = nil
    ) {
        write(AnnaWidgetSnapshot(
            mode: mode,
            expression: expression,
            quiet: quiet,
            updatedAt: Date(),
            stepsToday: stepsToday,
            dailyStepTarget: dailyStepTarget,
            sleepHours: sleepHours,
            workoutsThisWeek: workoutsThisWeek
        ))
    }

    static func write(_ snapshot: AnnaWidgetSnapshot) {
        guard let defaults = UserDefaults(suiteName: appGroupID),
              let data = try? JSONEncoder().encode(snapshot) else { return }
        let previous = defaults.data(forKey: snapshotKey)
            .flatMap { try? JSONDecoder().decode(AnnaWidgetSnapshot.self, from: $0) }
        let needsReload = previous.map {
            $0.mode != snapshot.mode
                || $0.expression != snapshot.expression
                || $0.quiet != snapshot.quiet
                || $0.stepsToday != snapshot.stepsToday
                || $0.dailyStepTarget != snapshot.dailyStepTarget
                || $0.sleepHours != snapshot.sleepHours
                || $0.workoutsThisWeek != snapshot.workoutsThisWeek
        } ?? true
        defaults.set(data, forKey: snapshotKey)
        if needsReload {
            WidgetCenter.shared.reloadAllTimelines()
        }
    }
}
