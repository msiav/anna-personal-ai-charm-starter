import AppIntents
import EventKit
import Foundation
import UIKit
import UserNotifications

struct AnnaPlanningSummary {
    let events: [String]
    let reminders: [String]
    let updatedAt: Date

    var promptText: String {
        let eventText = events.isEmpty ? "No remaining calendar events were found today." : "Today’s calendar: \(events.joined(separator: "; "))."
        let reminderText = reminders.isEmpty ? "No incomplete reminders due today or overdue were found." : "Due or overdue reminders: \(reminders.joined(separator: "; "))."
        return "Read-only information from Apple Calendar and Reminders, refreshed \(updatedAt.formatted(date: .abbreviated, time: .shortened)): \(eventText) \(reminderText)"
    }
}

@MainActor
final class AnnaPlanningStore {
    private let store = EKEventStore()

    var readPermissionStatus: AnnaPermissionStatus {
        let events = EKEventStore.authorizationStatus(for: .event)
        let reminders = EKEventStore.authorizationStatus(for: .reminder)
        let eventAllowed: Bool
        let reminderAllowed: Bool
        let eventDenied: Bool
        let reminderDenied: Bool
        if #available(iOS 17.0, *) {
            eventAllowed = events == .fullAccess
            reminderAllowed = reminders == .fullAccess
            eventDenied = events == .denied || events == .restricted || events == .writeOnly
            reminderDenied = reminders == .denied || reminders == .restricted
        } else {
            eventAllowed = events == .authorized
            reminderAllowed = reminders == .authorized
            eventDenied = events == .denied || events == .restricted
            reminderDenied = reminders == .denied || reminders == .restricted
        }
        if eventAllowed && reminderAllowed { return .enabled }
        if eventDenied || reminderDenied { return .denied }
        if events == .notDetermined || reminders == .notDetermined { return .notRequested }
        return .unavailable
    }

    func requestReadAccess() async throws {
        let calendarAllowed: Bool
        let remindersAllowed: Bool
        if #available(iOS 17.0, *) {
            if EKEventStore.authorizationStatus(for: .event) == .fullAccess {
                calendarAllowed = true
            } else {
                calendarAllowed = try await store.requestFullAccessToEvents()
            }
            if EKEventStore.authorizationStatus(for: .reminder) == .fullAccess {
                remindersAllowed = true
            } else {
                remindersAllowed = try await store.requestFullAccessToReminders()
            }
        } else {
            if EKEventStore.authorizationStatus(for: .event) == .authorized {
                calendarAllowed = true
            } else {
                calendarAllowed = try await store.requestAccess(to: .event)
            }
            if EKEventStore.authorizationStatus(for: .reminder) == .authorized {
                remindersAllowed = true
            } else {
                remindersAllowed = try await store.requestAccess(to: .reminder)
            }
        }
        guard calendarAllowed && remindersAllowed else {
            throw NSError(domain: "AnnaPlanning", code: 1, userInfo: [NSLocalizedDescriptionKey: "Allow read access to Calendar and Reminders to use them in local briefings."])
        }
    }

    func readSummary(now: Date = Date()) async throws -> AnnaPlanningSummary {
        let start = now
        let end = Calendar.current.date(bySettingHour: 23, minute: 59, second: 59, of: now) ?? now
        let events = store.events(matching: store.predicateForEvents(withStart: start, end: end, calendars: nil))
            .sorted { $0.startDate < $1.startDate }
            .prefix(8)
            .map { "\($0.startDate.formatted(date: .omitted, time: .shortened)) \(String($0.title ?? "Untitled event").prefix(100))" }

        let reminderPredicate = store.predicateForIncompleteReminders(
            withDueDateStarting: nil,
            ending: end,
            calendars: nil
        )
        let reminders: [EKReminder] = await withCheckedContinuation { continuation in
            store.fetchReminders(matching: reminderPredicate) { values in
                continuation.resume(returning: values ?? [])
            }
        }
        let reminderLines = reminders
            .sorted { ($0.dueDateComponents?.date ?? .distantFuture) < ($1.dueDateComponents?.date ?? .distantFuture) }
            .prefix(8)
            .map { String(($0.title ?? "Untitled reminder").prefix(100)) }
        return AnnaPlanningSummary(events: Array(events), reminders: Array(reminderLines), updatedAt: now)
    }

    func deleteReminder(identifier: String) async throws {
        let authorized: Bool
        if #available(iOS 17.0, *) {
            let status = EKEventStore.authorizationStatus(for: .reminder)
            if status == .fullAccess {
                authorized = true
            } else if status == .notDetermined {
                authorized = try await store.requestFullAccessToReminders()
            } else {
                authorized = false
            }
        } else {
            let status = EKEventStore.authorizationStatus(for: .reminder)
            if status == .authorized {
                authorized = true
            } else if status == .notDetermined {
                authorized = try await store.requestAccess(to: .reminder)
            } else {
                authorized = false
            }
        }
        guard authorized else {
            throw NSError(domain: "AnnaPlanning", code: 2, userInfo: [NSLocalizedDescriptionKey: "Reminders access is unavailable, so Anna could not undo this change."])
        }
        guard let reminder = store.calendarItem(withIdentifier: identifier) as? EKReminder else {
            throw NSError(domain: "AnnaPlanning", code: 3, userInfo: [NSLocalizedDescriptionKey: "The reminder could not be found. It may already have been removed."])
        }
        try store.remove(reminder, commit: true)
    }
}

struct AnnaActionReceipt: Identifiable, Codable, Equatable {
    enum UndoAction: Codable, Equatable {
        case quietMode(previousValue: Bool)
        case proactive(previousValue: Bool)
        case spokenReplies(previousValue: Bool)
        case sounds(previousValue: Bool)
        case haptics(previousValue: Bool)
        case helpPreference(previousValue: AnnaHelpStyle?)
        case helpLearning(previousValue: AnnaHelpPreferences)
        case reminderCreated(calendarItemIdentifier: String, followUpNotificationIdentifier: String?)
    }

    let id: UUID
    let title: String
    let detail: String
    let createdAt: Date
    let undoAction: UndoAction?

    init(id: UUID = UUID(), title: String, detail: String, createdAt: Date = Date(), undoAction: UndoAction? = nil) {
        self.id = id
        self.title = title
        self.detail = detail
        self.createdAt = createdAt
        self.undoAction = undoAction
    }
}

enum AnnaShortcutSharedState {
    static let appGroupIdentifier = "group.com.example.annacharm.shared"
    static let pendingQuietModeKey = "anna.shortcuts.pendingQuietMode.v1"
    static let pendingSearchQueryKey = "anna.shortcuts.pendingSearchQuery.v1"
    static let pendingQuestionKey = "anna.shortcuts.pendingQuestion.v1"
    static let pendingBriefingKey = "anna.shortcuts.pendingBriefing.v1"
    static let pendingNewConversationKey = "anna.shortcuts.pendingNewConversation.v1"
    static let pendingMemoryKey = "anna.shortcuts.pendingMemory.v1"
    static let pendingShareKey = "anna.share.pending.v1"
    static let pendingNotificationReminderKey = "anna.notification.pendingReminder.v1"
    static let pendingActionReceiptKey = "anna.action.pendingReceipt.v1"

    static func storePendingActionReceipt(_ receipt: AnnaActionReceipt) {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              let data = try? JSONEncoder().encode(receipt) else { return }
        defaults.set(data, forKey: pendingActionReceiptKey)
    }

    static func takePendingActionReceipt() -> AnnaActionReceipt? {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              let data = defaults.data(forKey: pendingActionReceiptKey) else { return nil }
        defaults.removeObject(forKey: pendingActionReceiptKey)
        guard let receipt = try? JSONDecoder().decode(AnnaActionReceipt.self, from: data),
              Date().timeIntervalSince(receipt.createdAt) < 24 * 60 * 60 else { return nil }
        return receipt
    }

    static func takePendingQuietMode() -> Bool? {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              let value = defaults.object(forKey: pendingQuietModeKey) as? Bool else {
            return nil
        }
        defaults.removeObject(forKey: pendingQuietModeKey)
        return value
    }

    static func takePendingSearchQuery() -> String? {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              let query = defaults.string(forKey: pendingSearchQueryKey) else {
            return nil
        }
        defaults.removeObject(forKey: pendingSearchQueryKey)
        return query
    }

    static func takePendingValue(for key: String) -> String? {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              let value = defaults.string(forKey: key) else { return nil }
        defaults.removeObject(forKey: key)
        return value
    }

    static func takePendingFlag(for key: String) -> Bool {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              defaults.bool(forKey: key) else { return false }
        defaults.removeObject(forKey: key)
        return true
    }
}

enum AnnaNotificationAssets {
    static func annaOrbAttachment() -> UNNotificationAttachment? {
        guard let image = UIImage(named: "AnnaOrb"), let data = image.pngData() else { return nil }
        let fileURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("anna-notification-orb.png")
        do {
            if !FileManager.default.fileExists(atPath: fileURL.path) {
                try data.write(to: fileURL, options: .atomic)
            }
            return try UNNotificationAttachment(identifier: "anna-orb", url: fileURL)
        } catch {
            try? FileManager.default.removeItem(at: fileURL)
            return nil
        }
    }
}

extension Notification.Name {
    static let annaShortcutQuietModeRequested = Notification.Name("anna.shortcuts.quietModeRequested.v1")
    static let annaShortcutSearchRequested = Notification.Name("anna.shortcuts.searchRequested.v1")
    static let annaShortcutQuestionRequested = Notification.Name("anna.shortcuts.questionRequested.v1")
    static let annaShortcutBriefingRequested = Notification.Name("anna.shortcuts.briefingRequested.v1")
    static let annaShortcutNewConversationRequested = Notification.Name("anna.shortcuts.newConversationRequested.v1")
    static let annaShortcutMemoryRequested = Notification.Name("anna.shortcuts.memoryRequested.v1")
}

private enum AnnaActionError: LocalizedError {
    case emptySearch
    case emptyInput
    case cannotCreateReminder
    case cannotCreateCalendarEvent
    case permissionDenied(String)

    var errorDescription: String? {
        switch self {
        case .emptySearch:
            return "Add a search phrase and try again."
        case .emptyInput:
            return "Add something for Anna and try again."
        case .cannotCreateReminder:
            return "Anna couldn’t find a default Reminders list. Create one in Reminders, then try again."
        case .cannotCreateCalendarEvent:
            return "Anna couldn’t find a default calendar. Choose a default calendar in Settings, then try again."
        case .permissionDenied(let service):
            return "Anna doesn’t have permission to use \(service). You can allow it in iPhone Settings."
        }
    }
}

struct TalkToAnnaIntent: AppIntent {
    static var title: LocalizedStringResource = "Talk to Anna"
    static var description = IntentDescription("Open Anna so you can talk or type.")
    static var openAppWhenRun: Bool { true }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        .result(dialog: "Anna is ready. Tap Talk or type to begin.")
    }
}

struct AskAnnaIntent: AppIntent {
    static var title: LocalizedStringResource = "Ask Anna"
    static var description = IntentDescription("Open Anna with a question ready to send to her on-device model.")
    static var openAppWhenRun: Bool { true }

    @Parameter(title: "Question")
    var question: String

    static var parameterSummary: some ParameterSummary { Summary("Ask Anna \(\.$question)") }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let value = String(question.trimmingCharacters(in: .whitespacesAndNewlines).prefix(2_000))
        guard !value.isEmpty else { throw AnnaActionError.emptyInput }
        guard let defaults = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier) else {
            throw AnnaActionError.permissionDenied("Anna’s shared settings")
        }
        defaults.set(value, forKey: AnnaShortcutSharedState.pendingQuestionKey)
        NotificationCenter.default.post(name: .annaShortcutQuestionRequested, object: nil, userInfo: ["question": value])
        return .result(dialog: "I’ve opened Anna with your question ready. Review it and tap send; her reply is generated on your iPhone.")
    }
}

struct StartAnnaConversationIntent: AppIntent {
    static var title: LocalizedStringResource = "Start a New Anna Conversation"
    static var description = IntentDescription("Open Anna in a fresh conversation.")
    static var openAppWhenRun: Bool { true }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard let defaults = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier) else {
            throw AnnaActionError.permissionDenied("Anna’s shared settings")
        }
        defaults.set(true, forKey: AnnaShortcutSharedState.pendingNewConversationKey)
        NotificationCenter.default.post(name: .annaShortcutNewConversationRequested, object: nil)
        return .result(dialog: "Opening a fresh conversation with Anna.")
    }
}

struct BriefAnnaIntent: AppIntent {
    static var title: LocalizedStringResource = "Prepare an Anna Briefing"
    static var description = IntentDescription("Open Anna and prepare an on-device briefing draft.")
    static var openAppWhenRun: Bool { true }

    @Parameter(title: "Briefing", default: "morning")
    var briefing: String

    static var parameterSummary: some ParameterSummary { Summary("Prepare a \(\.$briefing) briefing with Anna") }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let kind = briefing.lowercased().contains("evening") ? "evening" : "morning"
        guard let defaults = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier) else {
            throw AnnaActionError.permissionDenied("Anna’s shared settings")
        }
        defaults.set(kind, forKey: AnnaShortcutSharedState.pendingBriefingKey)
        NotificationCenter.default.post(name: .annaShortcutBriefingRequested, object: nil, userInfo: ["kind": kind])
        return .result(dialog: "Opening Anna to prepare your \(kind) briefing using information already on this iPhone.")
    }
}

struct SaveAnnaMemoryIntent: AppIntent {
    static var title: LocalizedStringResource = "Remember with Anna"
    static var description = IntentDescription("Save a note for Anna to remember.")
    static var openAppWhenRun: Bool { true }

    @Parameter(title: "Remember")
    var note: String

    static var parameterSummary: some ParameterSummary { Summary("Ask Anna to remember \(\.$note)") }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let value = String(note.trimmingCharacters(in: .whitespacesAndNewlines).prefix(300))
        guard !value.isEmpty else { throw AnnaActionError.emptyInput }
        guard let defaults = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier) else {
            throw AnnaActionError.permissionDenied("Anna’s shared settings")
        }
        defaults.set(value, forKey: AnnaShortcutSharedState.pendingMemoryKey)
        NotificationCenter.default.post(name: .annaShortcutMemoryRequested, object: nil, userInfo: ["note": value])
        return .result(dialog: "I’ll save that note privately on this iPhone. You can review or delete it in Anna’s Settings.")
    }
}

struct SearchWebWithAnnaIntent: AppIntent {
    static var title: LocalizedStringResource = "Search the Web with Anna"
    static var description = IntentDescription("Open web search results for a phrase you choose.")
    static var openAppWhenRun: Bool { true }

    @Parameter(title: "Search for")
    var query: String

    static var parameterSummary: some ParameterSummary {
        Summary("Search the web for \(\.$query) with Anna")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let trimmedQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedQuery.isEmpty else { throw AnnaActionError.emptySearch }
        let safeQuery = String(trimmedQuery.prefix(500))
        guard let defaults = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier) else {
            throw AnnaActionError.permissionDenied("Anna’s shared settings")
        }
        defaults.set(safeQuery, forKey: AnnaShortcutSharedState.pendingSearchQueryKey)
        NotificationCenter.default.post(
            name: .annaShortcutSearchRequested,
            object: nil,
            userInfo: ["query": safeQuery]
        )
        return .result(dialog: "Opening DuckDuckGo results for \(safeQuery). The search terms will be sent to DuckDuckGo.")
    }
}

struct ReadAnnaHealthSummaryIntent: AppIntent {
    static var title: LocalizedStringResource = "Read Anna Health Summary"
    static var description = IntentDescription("Read your steps, recent sleep, and workouts.")
    static var openAppWhenRun: Bool { true }

    @MainActor
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let health = AnnaHealthStore()
        try await health.requestReadAccess()
        let summary = try await health.readSummary()
        let sleep = summary.sleepHoursLastNight.map { String(format: "%.1f hours", $0) } ?? "no recent sleep data"
        let spokenSummary = "Today you have \(summary.stepsToday.formatted()) steps, \(sleep), and \(summary.workoutsThisWeek) workouts this week. This summary was read on your iPhone from Apple Health."
        return .result(dialog: IntentDialog(stringLiteral: spokenSummary))
    }
}

struct SetAnnaQuietModeIntent: AppIntent {
    static var title: LocalizedStringResource = "Set Anna Quiet Mode"
    static var description = IntentDescription("Turn Anna’s spoken replies and sounds on or off.")
    static var openAppWhenRun: Bool { true }

    @Parameter(title: "Quiet mode on")
    var enabled: Bool

    static var parameterSummary: some ParameterSummary {
        Summary("Set Anna quiet mode to \(\.$enabled)")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard let defaults = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier) else {
            throw AnnaActionError.permissionDenied("Anna’s shared settings")
        }
        defaults.set(enabled, forKey: AnnaShortcutSharedState.pendingQuietModeKey)
        NotificationCenter.default.post(
            name: .annaShortcutQuietModeRequested,
            object: nil,
            userInfo: ["enabled": enabled]
        )
        return .result(dialog: enabled ? "Anna’s quiet mode is on." : "Anna’s quiet mode is off.")
    }
}

struct CreateAnnaReminderIntent: AppIntent {
    static var title: LocalizedStringResource = "Create Anna Reminder"
    static var description = IntentDescription("Add a reminder when you ask Anna.")

    @Parameter(title: "Remind me to")
    var reminderTitle: String

    @Parameter(title: "Due date")
    var dueDate: Date?

    @Parameter(title: "Follow up after it is due", default: false)
    var followUpAfterDue: Bool

    static var parameterSummary: some ParameterSummary {
        Summary("Remind me to \(\.$reminderTitle) with Anna")
    }

    @MainActor
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let title = reminderTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty else { throw AnnaActionError.cannotCreateReminder }

        let store = EKEventStore()
        let granted: Bool
        if #available(iOS 17.0, *) {
            let status = EKEventStore.authorizationStatus(for: .reminder)
            if status == .fullAccess {
                granted = true
            } else {
                granted = try await store.requestFullAccessToReminders()
            }
        } else {
            let status = EKEventStore.authorizationStatus(for: .reminder)
            if status == .authorized {
                granted = true
            } else {
                granted = try await store.requestAccess(to: .reminder)
            }
        }
        guard granted else { throw AnnaActionError.permissionDenied("Reminders") }
        guard let calendar = store.defaultCalendarForNewReminders() else {
            throw AnnaActionError.cannotCreateReminder
        }

        let reminder = EKReminder(eventStore: store)
        reminder.title = title
        reminder.calendar = calendar
        if let dueDate {
            reminder.dueDateComponents = Calendar.current.dateComponents(
                [.year, .month, .day, .hour, .minute],
                from: dueDate
            )
        }
        try store.save(reminder, commit: true)

        let sharedFollowUpEnabled = UserDefaults(suiteName: AnnaShortcutSharedState.appGroupIdentifier)?
            .bool(forKey: "anna.feature.reminderFollowUps.v1") ?? false
        let wantsFollowUp = followUpAfterDue || sharedFollowUpEnabled
        var followUpScheduled = false
        if wantsFollowUp, let dueDate, dueDate > Date() {
            let center = UNUserNotificationCenter.current()
            let settings = await center.notificationSettings()
            let authorized = settings.authorizationStatus == .authorized
                || settings.authorizationStatus == .provisional
                || settings.authorizationStatus == .ephemeral
            var granted = authorized
            if !granted, settings.authorizationStatus == .notDetermined {
                granted = (try? await center.requestAuthorization(options: [.alert, .sound])) ?? false
            }
            if granted {
                let content = UNMutableNotificationContent()
                content.title = "A gentle follow-up from Anna"
                content.body = "How did ‘\(title)’ go? Mark it done or snooze this check-in."
                content.categoryIdentifier = "ANNA_REMINDER_FOLLOW_UP"
                content.sound = .default
                content.attachments = AnnaNotificationAssets.annaOrbAttachment().map { [$0] } ?? []
                content.userInfo = [
                    "annaDestination": "reminder",
                    "reminderIdentifier": reminder.calendarItemIdentifier,
                    "reminderTitle": title
                ]
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(60, dueDate.timeIntervalSinceNow + 2 * 60 * 60), repeats: false)
                let request = UNNotificationRequest(
                    identifier: "anna.reminder.followup.\(reminder.calendarItemIdentifier)",
                    content: content,
                    trigger: trigger
                )
                do {
                    try await center.add(request)
                    followUpScheduled = true
                } catch { }
            }
        }

        var confirmation = dueDate.map { "I added ‘\(title)’ for \($0.formatted(date: .abbreviated, time: .shortened))." }
            ?? "I added ‘\(title)’ to Reminders."
        if wantsFollowUp {
            confirmation += followUpScheduled
                ? " I’ll send one local follow-up about two hours after it’s due, with Done and Snooze actions."
                : " I couldn’t schedule the local follow-up; check notification permissions and make sure the reminder has a future due time."
        }
        let followUpIdentifier = followUpScheduled ? "anna.reminder.followup.\(reminder.calendarItemIdentifier)" : nil
        AnnaShortcutSharedState.storePendingActionReceipt(
            AnnaActionReceipt(
                title: "Reminder created",
                detail: confirmation,
                undoAction: .reminderCreated(
                    calendarItemIdentifier: reminder.calendarItemIdentifier,
                    followUpNotificationIdentifier: followUpIdentifier
                )
            )
        )
        return .result(dialog: IntentDialog(stringLiteral: confirmation))
    }
}

struct CreateAnnaCalendarEventIntent: AppIntent {
    static var title: LocalizedStringResource = "Create Anna Calendar Event"
    static var description = IntentDescription("Add an event to your default calendar when you ask Anna.")

    @Parameter(title: "Event title")
    var eventTitle: String

    @Parameter(title: "Start time")
    var startDate: Date

    @Parameter(title: "Duration in minutes", default: 30)
    var durationMinutes: Int

    static var parameterSummary: some ParameterSummary {
        Summary("Add \(\.$eventTitle) to Calendar with Anna")
    }

    @MainActor
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let title = eventTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty else { throw AnnaActionError.cannotCreateCalendarEvent }

        let store = EKEventStore()
        let granted: Bool
        if #available(iOS 17.0, *) {
            let status = EKEventStore.authorizationStatus(for: .event)
            if status == .writeOnly || status == .fullAccess {
                granted = true
            } else {
                granted = try await store.requestWriteOnlyAccessToEvents()
            }
        } else {
            let status = EKEventStore.authorizationStatus(for: .event)
            if status == .authorized {
                granted = true
            } else {
                granted = try await store.requestAccess(to: .event)
            }
        }
        guard granted else { throw AnnaActionError.permissionDenied("Calendar") }
        guard let calendar = store.defaultCalendarForNewEvents else {
            throw AnnaActionError.cannotCreateCalendarEvent
        }

        let event = EKEvent(eventStore: store)
        event.title = title
        event.startDate = startDate
        event.endDate = startDate.addingTimeInterval(TimeInterval(min(max(durationMinutes, 5), 1_440) * 60))
        event.calendar = calendar
        try store.save(event, span: .thisEvent, commit: true)

        let confirmation = "I added ‘\(title)’ to your calendar for \(startDate.formatted(date: .abbreviated, time: .shortened))."
        return .result(dialog: IntentDialog(stringLiteral: confirmation))
    }
}

struct AnnaAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: TalkToAnnaIntent(),
            phrases: ["Talk to \(.applicationName)", "Open \(.applicationName)"],
            shortTitle: "Talk to Anna",
            systemImageName: "bubble.left.and.bubble.right"
        )
        AppShortcut(
            intent: AskAnnaIntent(),
            phrases: ["Ask \(.applicationName) a question"],
            shortTitle: "Ask Anna",
            systemImageName: "text.bubble"
        )
        AppShortcut(
            intent: StartAnnaConversationIntent(),
            phrases: ["Start a new conversation with \(.applicationName)"],
            shortTitle: "New Conversation",
            systemImageName: "plus.bubble"
        )
        AppShortcut(
            intent: BriefAnnaIntent(),
            phrases: ["Prepare a briefing with \(.applicationName)"],
            shortTitle: "Anna Briefing",
            systemImageName: "sun.horizon"
        )
        AppShortcut(
            intent: SaveAnnaMemoryIntent(),
            phrases: ["Remember this with \(.applicationName)"],
            shortTitle: "Remember with Anna",
            systemImageName: "brain"
        )
        AppShortcut(
            intent: SearchWebWithAnnaIntent(),
            phrases: ["Search the web with \(.applicationName)"],
            shortTitle: "Search the Web",
            systemImageName: "magnifyingglass"
        )
        AppShortcut(
            intent: ReadAnnaHealthSummaryIntent(),
            phrases: ["Read my Health summary with \(.applicationName)"],
            shortTitle: "Health Summary",
            systemImageName: "heart.text.square"
        )
        AppShortcut(
            intent: CreateAnnaReminderIntent(),
            phrases: ["Create a reminder with \(.applicationName)"],
            shortTitle: "Create Reminder",
            systemImageName: "checklist"
        )
        AppShortcut(
            intent: SetAnnaQuietModeIntent(),
            phrases: ["Set quiet mode in \(.applicationName)"],
            shortTitle: "Quiet Mode",
            systemImageName: "moon.zzz"
        )
    }
}
